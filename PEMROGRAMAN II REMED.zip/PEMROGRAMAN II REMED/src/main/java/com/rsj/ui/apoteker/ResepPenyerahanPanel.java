package com.rsj.ui.apoteker;

import com.rsj.model.DetailResep;
import com.rsj.model.Resep;
import com.rsj.service.ApotekService;
import com.rsj.util.PrintHelper;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ResepPenyerahanPanel extends JPanel {

    private final ApotekService apotekService = new ApotekService();

    private final JTable tblResep;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbStatus;
    private List<Resep> resepList;

    public ResepPenyerahanPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        txtSearch = new JTextField(14);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari no resep / pasien...");
        txtSearch.addActionListener(e -> reloadData());

        cmbStatus = new JComboBox<>(new String[]{"SEMUA", "MENUNGGU", "DIPROSES", "SELESAI", "DIAMBIL"});
        cmbStatus.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());

        left.add(new JLabel("Pencarian:"));
        left.add(txtSearch);
        left.add(new JLabel("Status:"));
        left.add(cmbStatus);
        left.add(btnSearch);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);

        JButton btnProses = UiUtils.createSecondaryButton("Telaah & Siapkan Resep");
        btnProses.addActionListener(e -> prosesResep());

        JButton btnSerah = UiUtils.createPrimaryButton("Serahkan Obat (Potong Stok)");
        btnSerah.addActionListener(e -> serahkanObat());

        JButton btnEtiket = UiUtils.createSecondaryButton("Cetak Etiket Obat");
        btnEtiket.addActionListener(e -> cetakEtiket());

        right.add(btnProses);
        right.add(btnSerah);
        right.add(btnEtiket);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "No. Resep", "Tanggal Resep", "No. RM", "Nama Pasien", "Dokter Pembuat", "Jumlah Obat", "Total Biaya", "Status Farmasi", "Catatan Dokter"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblResep = new JTable(model);
        UiUtils.styleTable(tblResep);
        cardTable.add(new JScrollPane(tblResep), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String st = (String) cmbStatus.getSelectedItem();

        resepList = apotekService.searchResep(kw, st);
        model.setRowCount(0);
        for (Resep r : resepList) {
            model.addRow(new Object[]{
                    r.getId(),
                    r.getNoResep(),
                    UiUtils.formatDate(r.getTanggalResep()),
                    r.getNoRekamMedis(),
                    r.getNamaPasien(),
                    r.getNamaDokter(),
                    r.getDetailList().size() + " Item Obat",
                    UiUtils.formatRupiah(r.getTotalBiaya()),
                    r.getStatus(),
                    r.getCatatan() != null ? r.getCatatan() : "-"
            });
        }
    }

    private Resep getSelectedResep() {
        int r = tblResep.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris resep terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return resepList.stream().filter(res -> res.getId() == id).findFirst().orElse(null);
    }

    private void prosesResep() {
        Resep r = getSelectedResep();
        if (r == null) return;
        try {
            apotekService.prosesResep(r.getId());
            UiUtils.showSuccess(this, "Resep " + r.getNoResep() + " telah ditelaah dan sedang disiapkan!");
            reloadData();
        } catch (Exception ex) {
            UiUtils.showError(this, ex.getMessage());
        }
    }

    private void serahkanObat() {
        Resep r = getSelectedResep();
        if (r == null) return;

        if ("SELESAI".equalsIgnoreCase(r.getStatus())) {
            UiUtils.showError(this, "Resep ini sudah pernah diselesaikan dan stok sudah dipotong!");
            return;
        }

        if (UiUtils.confirm(this, "Konfirmasi penyerahan obat resep " + r.getNoResep() + " kepada pasien " + r.getNamaPasien() + "? Stok obat akan otomatis dipotong.")) {
            try {
                apotekService.serahkanObat(r.getId());
                UiUtils.showSuccess(this, "Obat berhasil diserahkan dan stok farmasi otomatis berkurang!");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, "Gagal menyerahkan obat: " + ex.getMessage());
            }
        }
    }

    private void cetakEtiket() {
        Resep r = getSelectedResep();
        if (r == null) return;

        JPanel etiketPanel = new JPanel(new GridLayout(6 + r.getDetailList().size(), 1, 4, 4));
        etiketPanel.setBackground(java.awt.Color.WHITE);
        etiketPanel.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JLabel h1 = new JLabel("INSTALASI FARMASI RS JIWA SEHAT JIWA");
        h1.setFont(UiUtils.FONT_TITLE);
        h1.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel h2 = new JLabel("ETIKET ATURAN PAKAI OBAT PASIEN");
        h2.setFont(UiUtils.FONT_HEADER);
        h2.setForeground(UiUtils.COLOR_ACCENT);

        JLabel h3 = new JLabel("No. Resep: " + r.getNoResep() + " • Tanggal: " + UiUtils.formatDate(r.getTanggalResep()));
        JLabel h4 = new JLabel("Nama Pasien: " + r.getNamaPasien() + " (No. RM: " + r.getNoRekamMedis() + ")");
        JLabel h5 = new JLabel("Dokter Penulis Resep: " + r.getNamaDokter());

        etiketPanel.add(h1);
        etiketPanel.add(h2);
        etiketPanel.add(h3);
        etiketPanel.add(h4);
        etiketPanel.add(h5);

        for (DetailResep d : r.getDetailList()) {
            JLabel lItem = new JLabel("• " + d.getNamaObat() + " (" + d.getDosis() + ") : " + d.getJumlah() + " " + d.getBentuk() + " -> " + d.getAturanPakai() + " [" + d.getPetunjukKhusus() + "]");
            lItem.setFont(UiUtils.FONT_BOLD);
            etiketPanel.add(lItem);
        }

        JLabel hFooter = new JLabel("Pastikan diminum secara teratur sesuai petunjuk dokter. Jauhkan dari jangkauan anak.");
        hFooter.setFont(UiUtils.FONT_SMALL);
        hFooter.setForeground(UiUtils.COLOR_TEXT_MUTED);
        etiketPanel.add(hFooter);

        PrintHelper.printComponent(etiketPanel);
    }
}
