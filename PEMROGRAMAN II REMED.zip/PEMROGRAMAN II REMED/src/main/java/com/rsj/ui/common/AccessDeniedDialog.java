package com.rsj.ui.common;

import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class AccessDeniedDialog extends JDialog {

    public AccessDeniedDialog(Frame parent, String requiredRole) {
        super(parent, "Akses Ditolak", true);
        setSize(420, 220);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout());

        JPanel content = new JPanel(new BorderLayout(10, 14));
        content.setBackground(UiUtils.COLOR_SURFACE);
        content.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel lblTitle = new JLabel("Hak Akses Terbatas", SwingConstants.CENTER);
        lblTitle.setFont(UiUtils.FONT_TITLE);
        lblTitle.setForeground(UiUtils.COLOR_DANGER);

        JLabel lblDesc = new JLabel("<html><center style='color:#475569; font-size:12px;'>"
                + "Anda tidak memiliki izin untuk membuka modul atau melakukan aksi ini.<br>"
                + "Akses ini dikhususkan bagi role: <b>" + requiredRole + "</b>.<br>"
                + "Silakan hubungi Administrator jika ini merupakan sebuah kekeliruan.</center></html>", SwingConstants.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setOpaque(false);
        JButton btnOk = UiUtils.createPrimaryButton("Mengerti");
        btnOk.addActionListener(e -> dispose());
        btnPanel.add(btnOk);

        content.add(lblTitle, BorderLayout.NORTH);
        content.add(lblDesc, BorderLayout.CENTER);
        content.add(btnPanel, BorderLayout.SOUTH);

        add(content);
    }

    public static void show(Component parent, String requiredRole) {
        Frame f = JOptionPaneFrameHelper(parent);
        AccessDeniedDialog dlg = new AccessDeniedDialog(f, requiredRole);
        dlg.setVisible(true);
    }

    private static Frame JOptionPaneFrameHelper(Component parent) {
        if (parent instanceof Frame) return (Frame) parent;
        return null;
    }
}
