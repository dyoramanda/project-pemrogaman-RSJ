package com.rsj.ui.admin;

import com.rsj.model.Dokter;
import com.rsj.model.Perawat;
import com.rsj.service.MasterDataService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class DokterPerawatPanel extends JPanel {

    private final MasterDataService masterService = new MasterDataService();

    // Dokter Table
    private final JTable tblDokter;
    private final DefaultTableModel modelDokter;
    private final JTextField txtSearchDokter;
    private List<Dokter> dokterList;

    // Perawat Table
    private final JTable tblPerawat;
    private final DefaultTableModel modelPerawat;
    private final JTextField txtSearchPerawat;
    private List<Perawat> perawatList;

    public DokterPerawatPanel() {
        setLayout(new BorderLayout());
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(UiUtils.FONT_BOLD);

        // --- TAB 1: DOKTER ---
        JPanel panelDokter = new JPanel(new BorderLayout(0, 12));
        panelDokter.setBackground(UiUtils.COLOR_BG);

        JPanel topDokter = UiUtils.createCardPanel();
        topDokter.setLayout(new BorderLayout());
        JPanel leftDoc = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftDoc.setOpaque(false);
        txtSearchDokter = new JTextField(15);
        txtSearchDokter.putClientProperty("JTextField.placeholderText", "Cari dokter...");
        txtSearchDokter.addActionListener(e -> reloadDokter());
        JButton btnSearchDoc = UiUtils.createSecondaryButton("Cari");
        btnSearchDoc.addActionListener(e -> reloadDokter());
        leftDoc.add(new JLabel("Pencarian:"));
        leftDoc.add(txtSearchDokter);
        leftDoc.add(btnSearchDoc);

        JPanel rightDoc = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightDoc.setOpaque(false);
        JButton btnAddDoc = UiUtils.createPrimaryButton("+ Tambah Dokter");
        btnAddDoc.addActionListener(e -> showDokterForm(null));
        JButton btnEditDoc = UiUtils.createSecondaryButton("Ubah");
        btnEditDoc.addActionListener(e -> {
            Dokter d = getSelectedDokter();
            if (d != null) showDokterForm(d);
        });
        JButton btnDelDoc = UiUtils.createDangerButton("Hapus");
        btnDelDoc.addActionListener(e -> deleteDokter());
        rightDoc.add(btnAddDoc);
        rightDoc.add(btnEditDoc);
        rightDoc.add(btnDelDoc);
        topDokter.add(leftDoc, BorderLayout.WEST);
        topDokter.add(rightDoc, BorderLayout.EAST);

        JPanel cardDocTable = UiUtils.createCardPanel();
        cardDocTable.setLayout(new BorderLayout());
        modelDokter = new DefaultTableModel(new String[]{"ID", "NIP", "Nama Dokter", "Spesialisasi", "No. STR", "Telepon", "Tarif Konsultasi", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblDokter = new JTable(modelDokter);
        UiUtils.styleTable(tblDokter);
        cardDocTable.add(new JScrollPane(tblDokter), BorderLayout.CENTER);

        panelDokter.add(topDokter, BorderLayout.NORTH);
        panelDokter.add(cardDocTable, BorderLayout.CENTER);

        // --- TAB 2: PERAWAT ---
        JPanel panelPerawat = new JPanel(new BorderLayout(0, 12));
        panelPerawat.setBackground(UiUtils.COLOR_BG);

        JPanel topPerawat = UiUtils.createCardPanel();
        topPerawat.setLayout(new BorderLayout());
        JPanel leftNur = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftNur.setOpaque(false);
        txtSearchPerawat = new JTextField(15);
        txtSearchPerawat.putClientProperty("JTextField.placeholderText", "Cari perawat...");
        txtSearchPerawat.addActionListener(e -> reloadPerawat());
        JButton btnSearchNur = UiUtils.createSecondaryButton("Cari");
        btnSearchNur.addActionListener(e -> reloadPerawat());
        leftNur.add(new JLabel("Pencarian:"));
        leftNur.add(txtSearchPerawat);
        leftNur.add(btnSearchNur);

        JPanel rightNur = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightNur.setOpaque(false);
        JButton btnAddNur = UiUtils.createPrimaryButton("+ Tambah Perawat");
        btnAddNur.addActionListener(e -> showPerawatForm(null));
        JButton btnEditNur = UiUtils.createSecondaryButton("Ubah");
        btnEditNur.addActionListener(e -> {
            Perawat p = getSelectedPerawat();
            if (p != null) showPerawatForm(p);
        });
        JButton btnDelNur = UiUtils.createDangerButton("Hapus");
        btnDelNur.addActionListener(e -> deletePerawat());
        rightNur.add(btnAddNur);
        rightNur.add(btnEditNur);
        rightNur.add(btnDelNur);
        topPerawat.add(leftNur, BorderLayout.WEST);
        topPerawat.add(rightNur, BorderLayout.EAST);

        JPanel cardNurTable = UiUtils.createCardPanel();
        cardNurTable.setLayout(new BorderLayout());
        modelPerawat = new DefaultTableModel(new String[]{"ID", "NIP", "Nama Perawat", "No. STR", "Telepon", "Shift Utama", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblPerawat = new JTable(modelPerawat);
        UiUtils.styleTable(tblPerawat);
        cardNurTable.add(new JScrollPane(tblPerawat), BorderLayout.CENTER);

        panelPerawat.add(topPerawat, BorderLayout.NORTH);
        panelPerawat.add(cardNurTable, BorderLayout.CENTER);

        tabs.addTab("Dokter Spesialis Kedokteran Jiwa (Sp.KJ)", panelDokter);
        tabs.addTab("Tenaga Keperawatan Jiwa", panelPerawat);

        add(tabs, BorderLayout.CENTER);

        reloadDokter();
        reloadPerawat();
    }

    public void reloadData() {
        reloadDokter();
        reloadPerawat();
    }

    private void reloadDokter() {
        String kw = txtSearchDokter.getText().trim();
        dokterList = masterService.searchDokter(kw);
        modelDokter.setRowCount(0);
        for (Dokter d : dokterList) {
            modelDokter.addRow(new Object[]{
                    d.getId(),
                    d.getNip(),
                    d.getNamaLengkap(),
                    d.getSpesialisasi(),
                    d.getNoStr(),
                    d.getNoTelepon(),
                    UiUtils.formatRupiah(d.getTarifKonsultasi()),
                    d.isStatusAktif() ? "Aktif" : "Nonaktif"
            });
        }
    }

    private void reloadPerawat() {
        String kw = txtSearchPerawat.getText().trim();
        perawatList = masterService.searchPerawat(kw);
        modelPerawat.setRowCount(0);
        for (Perawat p : perawatList) {
            modelPerawat.addRow(new Object[]{
                    p.getId(),
                    p.getNip(),
                    p.getNamaLengkap(),
                    p.getNoStr(),
                    p.getNoTelepon(),
                    p.getShiftDefault(),
                    p.isStatusAktif() ? "Aktif" : "Nonaktif"
            });
        }
    }

    private Dokter getSelectedDokter() {
        int r = tblDokter.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Pilih baris dokter terlebih dahulu!");
            return null;
        }
        int id = (int) modelDokter.getValueAt(r, 0);
        return dokterList.stream().filter(d -> d.getId() == id).findFirst().orElse(null);
    }

    private Perawat getSelectedPerawat() {
        int r = tblPerawat.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Pilih baris perawat terlebih dahulu!");
            return null;
        }
        int id = (int) modelPerawat.getValueAt(r, 0);
        return perawatList.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    private void showDokterForm(Dokter d) {
        boolean isEdit = d != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Dokter" : "Tambah Dokter", true);
        dlg.setSize(440, 420);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UiUtils.COLOR_SURFACE);
        p.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JTextField txtNip = new JTextField(isEdit && d.getNip() != null ? d.getNip() : "");
        JTextField txtNama = new JTextField(isEdit ? d.getNamaLengkap() : "");
        JTextField txtSpec = new JTextField(isEdit ? d.getSpesialisasi() : "Spesialis Kedokteran Jiwa (Sp.KJ)");
        JTextField txtStr = new JTextField(isEdit && d.getNoStr() != null ? d.getNoStr() : "");
        JTextField txtTelp = new JTextField(isEdit && d.getNoTelepon() != null ? d.getNoTelepon() : "");
        JTextField txtTarif = new JTextField(isEdit && d.getTarifKonsultasi() != null ? d.getTarifKonsultasi().toString() : "200000");
        JCheckBox chkAktif = new JCheckBox("Status Dokter Aktif", isEdit ? d.isStatusAktif() : true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; p.add(new JLabel("NIP:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; p.add(txtNip, g);

        g.gridx = 0; g.gridy = 1; p.add(new JLabel("Nama Lengkap & Gelar:"), g);
        g.gridx = 1; g.gridy = 1; p.add(txtNama, g);

        g.gridx = 0; g.gridy = 2; p.add(new JLabel("Subspesialisasi / Bidang:"), g);
        g.gridx = 1; g.gridy = 2; p.add(txtSpec, g);

        g.gridx = 0; g.gridy = 3; p.add(new JLabel("Nomor STR:"), g);
        g.gridx = 1; g.gridy = 3; p.add(txtStr, g);

        g.gridx = 0; g.gridy = 4; p.add(new JLabel("No. Telepon:"), g);
        g.gridx = 1; g.gridy = 4; p.add(txtTelp, g);

        g.gridx = 0; g.gridy = 5; p.add(new JLabel("Tarif Konsultasi (Rp):"), g);
        g.gridx = 1; g.gridy = 5; p.add(txtTarif, g);

        g.gridx = 1; g.gridy = 6; p.add(chkAktif, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Dokter");
        btnSave.addActionListener(e -> {
            try {
                Dokter nd = isEdit ? d : new Dokter();
                nd.setNip(txtNip.getText().trim());
                nd.setNamaLengkap(txtNama.getText().trim());
                nd.setSpesialisasi(txtSpec.getText().trim());
                nd.setNoStr(txtStr.getText().trim());
                nd.setNoTelepon(txtTelp.getText().trim());
                nd.setTarifKonsultasi(new BigDecimal(txtTarif.getText().trim()));
                nd.setStatusAktif(chkAktif.isSelected());
                masterService.saveDokter(nd);
                UiUtils.showSuccess(this, "Data dokter berhasil disimpan!");
                dlg.dispose();
                reloadDokter();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 7; g.gridwidth = 2;
        g.insets = new Insets(12, 5, 5, 5);
        p.add(btnSave, g);

        dlg.add(p, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void showPerawatForm(Perawat p) {
        boolean isEdit = p != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Perawat" : "Tambah Perawat", true);
        dlg.setSize(440, 380);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JTextField txtNip = new JTextField(isEdit && p.getNip() != null ? p.getNip() : "");
        JTextField txtNama = new JTextField(isEdit ? p.getNamaLengkap() : "");
        JTextField txtStr = new JTextField(isEdit && p.getNoStr() != null ? p.getNoStr() : "");
        JTextField txtTelp = new JTextField(isEdit && p.getNoTelepon() != null ? p.getNoTelepon() : "");
        JComboBox<String> cmbShift = new JComboBox<>(new String[]{"PAGI", "SIANG", "MALAM"});
        if (isEdit) cmbShift.setSelectedItem(p.getShiftDefault());
        JCheckBox chkAktif = new JCheckBox("Status Perawat Aktif", isEdit ? p.isStatusAktif() : true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("NIP:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(txtNip, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Nama Lengkap:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(txtNama, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("No. STR Perawat:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(txtStr, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("No. Telepon:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(txtTelp, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Shift Kerja:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(cmbShift, g);

        g.gridx = 1; g.gridy = 5; pan.add(chkAktif, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Perawat");
        btnSave.addActionListener(e -> {
            try {
                Perawat np = isEdit ? p : new Perawat();
                np.setNip(txtNip.getText().trim());
                np.setNamaLengkap(txtNama.getText().trim());
                np.setNoStr(txtStr.getText().trim());
                np.setNoTelepon(txtTelp.getText().trim());
                np.setShiftDefault((String) cmbShift.getSelectedItem());
                np.setStatusAktif(chkAktif.isSelected());
                masterService.savePerawat(np);
                UiUtils.showSuccess(this, "Data perawat berhasil disimpan!");
                dlg.dispose();
                reloadPerawat();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 6; g.gridwidth = 2;
        g.insets = new Insets(12, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void deleteDokter() {
        Dokter d = getSelectedDokter();
        if (d == null) return;
        if (UiUtils.confirm(this, "Hapus data dokter " + d.getNamaLengkap() + "?")) {
            try {
                masterService.deleteDokter(d.getId());
                UiUtils.showSuccess(this, "Data dokter berhasil dihapus.");
                reloadDokter();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }

    private void deletePerawat() {
        Perawat p = getSelectedPerawat();
        if (p == null) return;
        if (UiUtils.confirm(this, "Hapus data perawat " + p.getNamaLengkap() + "?")) {
            try {
                masterService.deletePerawat(p.getId());
                UiUtils.showSuccess(this, "Data perawat berhasil dihapus.");
                reloadPerawat();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
