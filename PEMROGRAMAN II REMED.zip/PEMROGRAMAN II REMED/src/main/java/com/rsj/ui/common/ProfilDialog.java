package com.rsj.ui.common;

import com.rsj.model.User;
import com.rsj.service.AuthService;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class ProfilDialog extends JDialog {

    private final AuthService authService = new AuthService();
    private final Runnable onProfileUpdated;

    public ProfilDialog(Frame parent, Runnable onProfileUpdated) {
        super(parent, "Profil Pengguna & Keamanan", true);
        this.onProfileUpdated = onProfileUpdated;
        setSize(480, 420);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout());

        User user = SessionManager.getCurrentUser();
        if (user == null) {
            dispose();
            return;
        }

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(UiUtils.FONT_BOLD);
        tabs.addTab("Informasi Akun", createProfilePanel(user));
        tabs.addTab("Ganti Kata Sandi", createPasswordPanel(user));

        add(tabs, BorderLayout.CENTER);
    }

    private JPanel createProfilePanel(User user) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UiUtils.COLOR_SURFACE);
        p.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 6, 6, 6);

        JTextField txtUsername = new JTextField(user.getUsername());
        txtUsername.setEditable(false);
        JTextField txtRole = new JTextField(user.getRole());
        txtRole.setEditable(false);
        JTextField txtNama = new JTextField(user.getNamaLengkap());
        JTextField txtTelp = new JTextField(user.getNoTelp() != null ? user.getNoTelp() : "");
        JTextField txtEmail = new JTextField(user.getEmail() != null ? user.getEmail() : "");

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.3; p.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.7; p.add(txtUsername, gbc);

        gbc.gridx = 0; gbc.gridy = 1; p.add(new JLabel("Hak Akses (Role):"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; p.add(txtRole, gbc);

        gbc.gridx = 0; gbc.gridy = 2; p.add(new JLabel("Nama Lengkap:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; p.add(txtNama, gbc);

        gbc.gridx = 0; gbc.gridy = 3; p.add(new JLabel("No. Telepon:"), gbc);
        gbc.gridx = 1; gbc.gridy = 3; p.add(txtTelp, gbc);

        gbc.gridx = 0; gbc.gridy = 4; p.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; gbc.gridy = 4; p.add(txtEmail, gbc);

        JButton btnSimpan = UiUtils.createPrimaryButton("Simpan Perubahan");
        btnSimpan.addActionListener(e -> {
            try {
                user.setNamaLengkap(txtNama.getText().trim());
                user.setNoTelp(txtTelp.getText().trim());
                user.setEmail(txtEmail.getText().trim());
                authService.updateProfile(user);
                UiUtils.showSuccess(this, "Profil berhasil diperbarui!");
                if (onProfileUpdated != null) onProfileUpdated.run();
                dispose();
            } catch (Exception ex) {
                UiUtils.showError(this, "Gagal update profil: " + ex.getMessage());
            }
        });

        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        gbc.insets = new Insets(16, 6, 6, 6);
        p.add(btnSimpan, gbc);

        return p;
    }

    private JPanel createPasswordPanel(User user) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UiUtils.COLOR_SURFACE);
        p.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(6, 6, 6, 6);

        JPasswordField txtOld = new JPasswordField();
        JPasswordField txtNew = new JPasswordField();
        JPasswordField txtConfirm = new JPasswordField();

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.35; p.add(new JLabel("Kata Sandi Lama:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.65; p.add(txtOld, gbc);

        gbc.gridx = 0; gbc.gridy = 1; p.add(new JLabel("Kata Sandi Baru:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1; p.add(txtNew, gbc);

        gbc.gridx = 0; gbc.gridy = 2; p.add(new JLabel("Konfirmasi Sandi:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2; p.add(txtConfirm, gbc);

        JButton btnUbah = UiUtils.createPrimaryButton("Ubah Kata Sandi");
        btnUbah.addActionListener(e -> {
            String oldP = new String(txtOld.getPassword());
            String newP = new String(txtNew.getPassword());
            String confP = new String(txtConfirm.getPassword());

            if (!newP.equals(confP)) {
                UiUtils.showError(this, "Konfirmasi kata sandi tidak cocok!");
                return;
            }

            try {
                authService.changePassword(user.getId(), oldP, newP);
                UiUtils.showSuccess(this, "Kata sandi berhasil diperbarui! Silakan gunakan sandi baru pada login berikutnya.");
                dispose();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        });

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.insets = new Insets(16, 6, 6, 6);
        p.add(btnUbah, gbc);

        return p;
    }
}
