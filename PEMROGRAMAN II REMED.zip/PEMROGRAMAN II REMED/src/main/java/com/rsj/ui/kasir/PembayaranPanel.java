package com.rsj.ui.kasir;

import com.rsj.model.Pembayaran;
import com.rsj.model.Tagihan;
import com.rsj.service.KasirService;
import com.rsj.util.PrintHelper;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PembayaranPanel extends JPanel {

    private final KasirService kasirService = new KasirService();

    private final JTable tblBayar;
    private final DefaultTableModel model;
    private List<Pembayaran> pembayaranList;

    public PembayaranPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Transaksi Pembayaran & Kasir RS Jiwa");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);

        JButton btnBayar = UiUtils.createPrimaryButton("+ Proses Pembayaran Kasir");
        btnBayar.addActionListener(e -> showPembayaranForm());

        JButton btnCetak = UiUtils.createSecondaryButton("Cetak Struk Pembayaran");
        btnCetak.addActionListener(e -> printStruk());

        right.add(btnBayar);
        right.add(btnCetak);

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "No. Transaksi", "Waktu Pembayaran", "No. Tagihan", "Nama Pasien", "Metode Pembayaran", "Jumlah Bayar", "Kembalian", "Petugas Kasir", "Catatan"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblBayar = new JTable(model);
        UiUtils.styleTable(tblBayar);
        cardTable.add(new JScrollPane(tblBayar), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        pembayaranList = kasirService.getRiwayatPembayaran(0);
        // If 0, fetch all
        pembayaranList = new com.rsj.dao.PembayaranDao().findAll();
        model.setRowCount(0);
        for (Pembayaran p : pembayaranList) {
            model.addRow(new Object[]{
                    p.getId(),
                    p.getNoTransaksi(),
                    UiUtils.formatDateTime(p.getTanggalBayar()),
                    p.getNoTagihan(),
                    p.getNamaPasien(),
                    p.getMetodePembayaran(),
                    UiUtils.formatRupiah(p.getJumlahDibayar()),
                    UiUtils.formatRupiah(p.getKembalian()),
                    p.getNamaKasir(),
                    p.getCatatan() != null ? p.getCatatan() : "-"
            });
        }
    }

    private Pembayaran getSelectedPembayaran() {
        int r = tblBayar.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih transaksi pembayaran terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return pembayaranList.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    private void showPembayaranForm() {
        JDialog dlg = new JDialog((Frame) null, "Proses Pembayaran Tagihan", true);
        dlg.setSize(480, 460);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        List<Tagihan> tagihans = kasirService.searchTagihan("", "BELUM_LUNAS");
        JComboBox<Tagihan> cmbTagihan = new JComboBox<>(tagihans.toArray(new Tagihan[0]));

        JLabel lblSisa = new JLabel("Rp 0");
        lblSisa.setFont(UiUtils.FONT_HEADER);
        lblSisa.setForeground(UiUtils.COLOR_DANGER);

        JTextField txtBayar = new JTextField();
        JComboBox<String> cmbMetode = new JComboBox<>(new String[]{"TUNAI", "TRANSFER", "KARTU_DEBIT", "BPJS"});
        JTextField txtRef = new JTextField("-");
        JTextField txtCatatan = new JTextField("Lunas");

        cmbTagihan.addActionListener(e -> {
            Tagihan selT = (Tagihan) cmbTagihan.getSelectedItem();
            if (selT != null) {
                lblSisa.setText(UiUtils.formatRupiah(selT.getSisaTagihan()));
                txtBayar.setText(selT.getSisaTagihan().toString());
            }
        });
        if (!tagihans.isEmpty()) {
            cmbTagihan.setSelectedIndex(0);
        }

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Pilih Tagihan:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(cmbTagihan, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Sisa yang Harus Dibayar:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(lblSisa, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Nominal Bayar (Rp):"), g);
        g.gridx = 1; g.gridy = 2; pan.add(txtBayar, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Metode Pembayaran:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(cmbMetode, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("No. Referensi / Bukti:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtRef, g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Catatan Kasir:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(txtCatatan, g);

        JButton btnProses = UiUtils.createPrimaryButton("Konfirmasi Pembayaran");
        btnProses.addActionListener(e -> {
            try {
                Tagihan selT = (Tagihan) cmbTagihan.getSelectedItem();
                if (selT == null) throw new Exception("Tagihan belum dipilih!");

                BigDecimal bayar = new BigDecimal(txtBayar.getText().trim());
                String metode = (String) cmbMetode.getSelectedItem();
                String ref = txtRef.getText().trim();
                String cat = txtCatatan.getText().trim();

                Pembayaran res = kasirService.prosesPembayaran(selT.getId(), bayar, metode, ref, cat);
                UiUtils.showSuccess(this, "Pembayaran berhasil! No. Transaksi: " + res.getNoTransaksi()
                        + (res.getKembalian().compareTo(BigDecimal.ZERO) > 0 ? " (Kembalian: " + UiUtils.formatRupiah(res.getKembalian()) + ")" : ""));
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 6; g.gridwidth = 2;
        g.insets = new Insets(16, 5, 5, 5);
        pan.add(btnProses, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void printStruk() {
        Pembayaran p = getSelectedPembayaran();
        if (p == null) return;

        JPanel struk = new JPanel(new GridLayout(9, 1, 4, 4));
        struk.setBackground(java.awt.Color.WHITE);
        struk.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));

        JLabel l1 = new JLabel("RS JIWA SEHAT JIWA");
        l1.setFont(UiUtils.FONT_TITLE);
        l1.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel l2 = new JLabel("STRUK BUKTI PEMBAYARAN RESMI");
        l2.setFont(UiUtils.FONT_HEADER);
        l2.setForeground(UiUtils.COLOR_ACCENT);

        JLabel l3 = new JLabel("No. Transaksi : " + p.getNoTransaksi());
        JLabel l4 = new JLabel("No. Tagihan   : " + p.getNoTagihan() + " • Pasien: " + p.getNamaPasien());
        JLabel l5 = new JLabel("Waktu Bayar   : " + UiUtils.formatDateTime(p.getTanggalBayar()));
        JLabel l6 = new JLabel("Metode Bayar  : " + p.getMetodePembayaran());
        JLabel l7 = new JLabel("Jumlah Dibayar: " + UiUtils.formatRupiah(p.getJumlahDibayar()) + " (Kembalian: " + UiUtils.formatRupiah(p.getKembalian()) + ")");
        l7.setFont(UiUtils.FONT_BOLD);
        JLabel l8 = new JLabel("Kasir Penerima: " + p.getNamaKasir());
        JLabel l9 = new JLabel("Terima kasih atas kepercayaan Anda. Struk ini merupakan bukti sah pembayaran.");
        l9.setFont(UiUtils.FONT_SMALL);
        l9.setForeground(UiUtils.COLOR_TEXT_MUTED);

        struk.add(l1);
        struk.add(l2);
        struk.add(l3);
        struk.add(l4);
        struk.add(l5);
        struk.add(l6);
        struk.add(l7);
        struk.add(l8);
        struk.add(l9);

        PrintHelper.printComponent(struk);
    }
}
