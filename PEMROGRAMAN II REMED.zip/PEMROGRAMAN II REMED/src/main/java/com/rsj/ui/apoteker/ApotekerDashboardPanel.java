package com.rsj.ui.apoteker;

import com.rsj.dao.ObatDao;
import com.rsj.dao.ResepDao;
import com.rsj.model.Obat;
import com.rsj.model.Resep;
import com.rsj.ui.common.StatCard;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ApotekerDashboardPanel extends JPanel {

    private final ObatDao obatDao = new ObatDao();
    private final ResepDao resepDao = new ResepDao();

    private StatCard cardTotalObat;
    private StatCard cardStokMenipis;
    private StatCard cardResepMenunggu;
    private StatCard cardResepSelesai;

    private final JTable tblStokKritis;
    private final DefaultTableModel model;

    public ApotekerDashboardPanel() {
        setLayout(new BorderLayout(0, 16));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);

        // Stats Row
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 14, 14));
        statsRow.setOpaque(false);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));

        cardTotalObat = new StatCard("Total Jenis Obat", "0", "Katalog Farmasi", UiUtils.COLOR_PRIMARY);
        cardStokMenipis = new StatCard("Perlu Restock", "0", "Stok < 150 Unit", UiUtils.COLOR_WARNING);
        cardResepMenunggu = new StatCard("Resep Menunggu", "0", "Perlu Telaah Apotek", UiUtils.COLOR_DANGER);
        cardResepSelesai = new StatCard("Resep Selesai", "0", "Obat Diserahkan", UiUtils.COLOR_SUCCESS);

        statsRow.add(cardTotalObat);
        statsRow.add(cardStokMenipis);
        statsRow.add(cardResepMenunggu);
        statsRow.add(cardResepSelesai);

        // Critical Stock Alert Table Card
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 10));

        JPanel topT = new JPanel(new BorderLayout());
        topT.setOpaque(false);
        JLabel lblT = new JLabel("Peringatan Stok Obat Jiwa yang Perlu Pengadaan / Menipis");
        lblT.setFont(UiUtils.FONT_HEADER);
        lblT.setForeground(UiUtils.COLOR_PRIMARY);

        JButton btnRefresh = UiUtils.createSecondaryButton("Segarkan");
        btnRefresh.addActionListener(e -> refreshData());

        topT.add(lblT, BorderLayout.WEST);
        topT.add(btnRefresh, BorderLayout.EAST);

        model = new DefaultTableModel(new String[]{
                "Kode Obat", "Nama Obat Jiwa", "Kategori", "Bentuk", "Dosis", "Sisa Stok", "Satuan", "Harga Satuan", "Status Ketersediaan"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblStokKritis = new JTable(model);
        UiUtils.styleTable(tblStokKritis);
        JScrollPane sp = new JScrollPane(tblStokKritis);
        sp.setPreferredSize(new Dimension(900, 360));
        sp.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));

        cardTable.add(topT, BorderLayout.NORTH);
        cardTable.add(sp, BorderLayout.CENTER);

        main.add(statsRow);
        main.add(Box.createRigidArea(new Dimension(0, 16)));
        main.add(cardTable);

        JScrollPane scroll = new JScrollPane(main);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        refreshData();
    }

    public void refreshData() {
        List<Obat> obatList = obatDao.findAll();
        cardTotalObat.setValue(String.valueOf(obatList.size()) + " Jenis");

        long menipis = obatList.stream().filter(o -> o.getStok() < 200).count();
        cardStokMenipis.setValue(menipis + " Obat");

        List<Resep> resepList = resepDao.findAll();
        long menunggu = resepList.stream().filter(r -> "MENUNGGU".equalsIgnoreCase(r.getStatus()) || "DIPROSES".equalsIgnoreCase(r.getStatus())).count();
        long selesai = resepList.stream().filter(r -> "SELESAI".equalsIgnoreCase(r.getStatus()) || "DIAMBIL".equalsIgnoreCase(r.getStatus())).count();

        cardResepMenunggu.setValue(String.valueOf(menunggu));
        cardResepSelesai.setValue(String.valueOf(selesai));

        model.setRowCount(0);
        for (Obat o : obatList) {
            String stat = o.getStok() < 150 ? "PERLU RESTOCK" : (o.getStok() < 250 ? "MENIPIS" : "AMAN");
            model.addRow(new Object[]{
                    o.getKodeObat(),
                    o.getNamaObat(),
                    o.getKategori(),
                    o.getBentuk(),
                    o.getDosis(),
                    o.getStok(),
                    o.getSatuan(),
                    UiUtils.formatRupiah(o.getHargaSatuan()),
                    stat
            });
        }
    }
}
