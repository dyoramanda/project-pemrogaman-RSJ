package com.rsj.ui.dokter;

import com.rsj.dao.DokterDao;
import com.rsj.model.Dokter;
import com.rsj.model.JadwalDokter;
import com.rsj.service.MasterDataService;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Time;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class JadwalPraktikPanel extends JPanel {

    private final MasterDataService masterService = new MasterDataService();
    private final DokterDao dokterDao = new DokterDao();

    private final JTable tblJadwal;
    private final DefaultTableModel model;
    private List<JadwalDokter> jadwalList;

    public JadwalPraktikPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Jadwal Praktik Dokter Spesialis Jiwa");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnAdd = UiUtils.createPrimaryButton("+ Tambah Jadwal Praktik");
        btnAdd.addActionListener(e -> showJadwalForm(null));

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah");
        btnEdit.addActionListener(e -> {
            JadwalDokter j = getSelectedJadwal();
            if (j != null) showJadwalForm(j);
        });

        JButton btnDel = UiUtils.createDangerButton("Hapus");
        btnDel.addActionListener(e -> deleteJadwal());

        right.add(btnAdd);
        right.add(btnEdit);
        right.add(btnDel);

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "Nama Dokter", "Spesialisasi", "Hari Praktik", "Jam Mulai", "Jam Selesai", "Kuota Pasien", "Status"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblJadwal = new JTable(model);
        UiUtils.styleTable(tblJadwal);
        cardTable.add(new JScrollPane(tblJadwal), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        jadwalList = masterService.getAllJadwalDokter();
        model.setRowCount(0);
        for (JadwalDokter j : jadwalList) {
            model.addRow(new Object[]{
                    j.getId(),
                    j.getNamaDokter(),
                    j.getSpesialisasi(),
                    j.getHari(),
                    j.getJamMulai(),
                    j.getJamSelesai(),
                    j.getKuotaPasien() + " Pasien",
                    j.isStatusAktif() ? "Aktif" : "Nonaktif"
            });
        }
    }

    private JadwalDokter getSelectedJadwal() {
        int r = tblJadwal.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris jadwal terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return jadwalList.stream().filter(j -> j.getId() == id).findFirst().orElse(null);
    }

    private void showJadwalForm(JadwalDokter j) {
        boolean isEdit = j != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Jadwal" : "Tambah Jadwal Praktik", true);
        dlg.setSize(440, 380);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        List<Dokter> dokters = masterService.getAllDokter();
        JComboBox<Dokter> cmbDokter = new JComboBox<>(dokters.toArray(new Dokter[0]));
        if (isEdit) {
            for (Dokter d : dokters) {
                if (d.getId() == j.getIdDokter()) {
                    cmbDokter.setSelectedItem(d);
                    break;
                }
            }
        }

        JComboBox<String> cmbHari = new JComboBox<>(new String[]{"Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"});
        if (isEdit) cmbHari.setSelectedItem(j.getHari());

        JTextField txtMulai = new JTextField(isEdit && j.getJamMulai() != null ? j.getJamMulai().toString() : "08:00:00");
        JTextField txtSelesai = new JTextField(isEdit && j.getJamSelesai() != null ? j.getJamSelesai().toString() : "13:00:00");
        JTextField txtKuota = new JTextField(isEdit ? String.valueOf(j.getKuotaPasien()) : "20");
        JCheckBox chkAktif = new JCheckBox("Jadwal Praktik Aktif", isEdit ? j.isStatusAktif() : true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Pilih Dokter:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(cmbDokter, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Hari Praktik:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(cmbHari, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Jam Mulai (HH:mm:ss):"), g);
        g.gridx = 1; g.gridy = 2; pan.add(txtMulai, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Jam Selesai (HH:mm:ss):"), g);
        g.gridx = 1; g.gridy = 3; pan.add(txtSelesai, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Kuota Maksimal:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtKuota, g);

        g.gridx = 1; g.gridy = 5; pan.add(chkAktif, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Jadwal");
        btnSave.addActionListener(e -> {
            try {
                JadwalDokter nj = isEdit ? j : new JadwalDokter();
                Dokter selD = (Dokter) cmbDokter.getSelectedItem();
                if (selD == null) throw new Exception("Dokter wajib dipilih!");

                nj.setIdDokter(selD.getId());
                nj.setHari((String) cmbHari.getSelectedItem());
                nj.setJamMulai(Time.valueOf(txtMulai.getText().trim()));
                nj.setJamSelesai(Time.valueOf(txtSelesai.getText().trim()));
                nj.setKuotaPasien(Integer.parseInt(txtKuota.getText().trim()));
                nj.setStatusAktif(chkAktif.isSelected());

                masterService.saveJadwalDokter(nj);
                UiUtils.showSuccess(this, "Jadwal praktik berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 6; g.gridwidth = 2;
        g.insets = new Insets(12, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void deleteJadwal() {
        JadwalDokter j = getSelectedJadwal();
        if (j == null) return;
        if (UiUtils.confirm(this, "Hapus jadwal hari " + j.getHari() + " dokter " + j.getNamaDokter() + "?")) {
            try {
                masterService.deleteJadwalDokter(j.getId());
                UiUtils.showSuccess(this, "Jadwal berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
