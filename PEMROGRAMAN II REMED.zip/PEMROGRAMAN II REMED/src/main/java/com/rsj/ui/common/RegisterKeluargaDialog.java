package com.rsj.ui.common;

import com.rsj.model.PenanggungJawab;
import com.rsj.model.User;
import com.rsj.service.AuthService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class RegisterKeluargaDialog extends JDialog {

    private final AuthService authService = new AuthService();

    public RegisterKeluargaDialog(Frame parent) {
        super(parent, "Registrasi Akun Keluarga Pasien", true);
        setSize(520, 560);
        setLocationRelativeTo(parent);
        setResizable(false);
        setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UiUtils.COLOR_SURFACE);
        p.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel lblTitle = new JLabel("Formulir Pendaftaran Keluarga Pasien");
        lblTitle.setFont(UiUtils.FONT_TITLE);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JTextField txtNama = new JTextField();
        JComboBox<String> cmbHubungan = new JComboBox<>(new String[]{"Orang Tua", "Suami / Istri", "Anak Kandung", "Saudara Kandung", "Wali Hukum / Keluarga Lain"});
        JTextField txtNik = new JTextField();
        JTextField txtTelp = new JTextField();
        JTextField txtAlamat = new JTextField();
        JTextField txtPekerjaan = new JTextField();
        JTextField txtUsername = new JTextField();
        JPasswordField txtPassword = new JPasswordField();

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        p.add(lblTitle, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1; gbc.gridx = 0; p.add(new JLabel("Nama Lengkap Penanggung Jawab:"), gbc);
        gbc.gridx = 1; p.add(txtNama, gbc);

        gbc.gridy = 2; gbc.gridx = 0; p.add(new JLabel("Hubungan dengan Pasien:"), gbc);
        gbc.gridx = 1; p.add(cmbHubungan, gbc);

        gbc.gridy = 3; gbc.gridx = 0; p.add(new JLabel("Nomor KTP / Identitas:"), gbc);
        gbc.gridx = 1; p.add(txtNik, gbc);

        gbc.gridy = 4; gbc.gridx = 0; p.add(new JLabel("No. Telepon / WhatsApp:"), gbc);
        gbc.gridx = 1; p.add(txtTelp, gbc);

        gbc.gridy = 5; gbc.gridx = 0; p.add(new JLabel("Alamat Lengkap Rumah:"), gbc);
        gbc.gridx = 1; p.add(txtAlamat, gbc);

        gbc.gridy = 6; gbc.gridx = 0; p.add(new JLabel("Pekerjaan:"), gbc);
        gbc.gridx = 1; p.add(txtPekerjaan, gbc);

        gbc.gridy = 7; gbc.gridx = 0; p.add(new JLabel("Username Akun Baru:"), gbc);
        gbc.gridx = 1; p.add(txtUsername, gbc);

        gbc.gridy = 8; gbc.gridx = 0; p.add(new JLabel("Kata Sandi Akun:"), gbc);
        gbc.gridx = 1; p.add(txtPassword, gbc);

        JButton btnDaftar = UiUtils.createPrimaryButton("Daftarkan Akun Sekarang");
        btnDaftar.addActionListener(e -> {
            String nama = txtNama.getText().trim();
            String nik = txtNik.getText().trim();
            String telp = txtTelp.getText().trim();
            String user = txtUsername.getText().trim();
            String pass = new String(txtPassword.getPassword());

            if (nama.isEmpty() || nik.isEmpty() || telp.isEmpty() || user.isEmpty() || pass.isEmpty()) {
                UiUtils.showError(this, "Semua field bertanda wajib diisi!");
                return;
            }

            try {
                User u = new User();
                u.setUsername(user);
                u.setNamaLengkap(nama);
                u.setNoTelp(telp);

                PenanggungJawab pj = new PenanggungJawab();
                pj.setNamaLengkap(nama);
                pj.setHubungan((String) cmbHubungan.getSelectedItem());
                pj.setNoIdentitas(nik);
                pj.setNoTelepon(telp);
                pj.setAlamat(txtAlamat.getText().trim());
                pj.setPekerjaan(txtPekerjaan.getText().trim());

                authService.registerKeluarga(u, pj, pass);
                UiUtils.showSuccess(this, "Registrasi berhasil! Akun Anda telah dibuat. Silakan login menggunakan username dan password Anda.");
                dispose();
            } catch (Exception ex) {
                UiUtils.showError(this, "Gagal registrasi: " + ex.getMessage());
            }
        });

        gbc.gridy = 9; gbc.gridx = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(16, 5, 5, 5);
        p.add(btnDaftar, gbc);

        add(p, BorderLayout.CENTER);
    }
}
