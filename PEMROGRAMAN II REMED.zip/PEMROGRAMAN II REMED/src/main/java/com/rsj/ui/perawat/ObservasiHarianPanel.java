package com.rsj.ui.perawat;

import com.rsj.dao.PerawatDao;
import com.rsj.model.ObservasiHarian;
import com.rsj.model.Pasien;
import com.rsj.model.Perawat;
import com.rsj.service.KeperawatanService;
import com.rsj.service.PelayananService;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ObservasiHarianPanel extends JPanel {

    private final KeperawatanService keperawatanService = new KeperawatanService();
    private final PelayananService pelayananService = new PelayananService();
    private final PerawatDao perawatDao = new PerawatDao();

    private final JTable tblObs;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbKondisiFilter;
    private List<ObservasiHarian> obsList;

    public ObservasiHarianPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        txtSearch = new JTextField(15);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari pasien / no RM...");
        txtSearch.addActionListener(e -> reloadData());

        cmbKondisiFilter = new JComboBox<>(new String[]{"SEMUA", "TENANG", "GELISAH", "AGRESIF", "KOOPERATIF", "DEPRESIF"});
        cmbKondisiFilter.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());

        left.add(new JLabel("Pencarian:"));
        left.add(txtSearch);
        left.add(new JLabel("Kondisi:"));
        left.add(cmbKondisiFilter);
        left.add(btnSearch);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnAdd = UiUtils.createPrimaryButton("+ Input Observasi Baru");
        btnAdd.addActionListener(e -> showObsForm(null));

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah");
        btnEdit.addActionListener(e -> {
            ObservasiHarian o = getSelectedObs();
            if (o != null) showObsForm(o);
        });

        JButton btnDel = UiUtils.createDangerButton("Hapus");
        btnDel.addActionListener(e -> deleteObs());

        right.add(btnAdd);
        right.add(btnEdit);
        right.add(btnDel);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "Waktu Observasi", "No. RM", "Nama Pasien", "Bed", "Perawat", "Vital Sign (TD/N/S)", "Status Kondisi", "Mood", "Tidur", "Obat", "Catatan"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblObs = new JTable(model);
        UiUtils.styleTable(tblObs);
        cardTable.add(new JScrollPane(tblObs), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String knd = (String) cmbKondisiFilter.getSelectedItem();

        obsList = keperawatanService.searchObservasi(kw, knd);
        model.setRowCount(0);
        for (ObservasiHarian o : obsList) {
            String vital = (o.getTekananDarah() != null ? o.getTekananDarah() : "-") + " | "
                         + (o.getDenyutNadi() != null ? o.getDenyutNadi() + "bpm" : "-") + " | "
                         + (o.getSuhuTubuh() != null ? o.getSuhuTubuh() + "°C" : "-");

            model.addRow(new Object[]{
                    o.getId(),
                    UiUtils.formatDate(o.getTanggalObservasi()) + " " + UiUtils.formatTime(o.getWaktuObservasi()),
                    o.getNoRekamMedis(),
                    o.getNamaPasien(),
                    o.getNomorBed() != null ? o.getNomorBed() : "-",
                    o.getNamaPerawat(),
                    vital,
                    o.getStatusKondisi(),
                    o.getStatusMood(),
                    o.getKualitasTidur(),
                    o.getKepatuhanObat(),
                    o.getCatatanPerilaku()
            });
        }
    }

    private ObservasiHarian getSelectedObs() {
        int r = tblObs.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris observasi terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return obsList.stream().filter(o -> o.getId() == id).findFirst().orElse(null);
    }

    private void showObsForm(ObservasiHarian o) {
        boolean isEdit = o != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Observasi Pasien" : "Input Observasi Harian Pasien", true);
        dlg.setSize(540, 580);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        List<Pasien> pasienList = pelayananService.searchPasien("", "RAWAT_INAP");
        JComboBox<Pasien> cmbPasien = new JComboBox<>(pasienList.toArray(new Pasien[0]));
        if (isEdit) {
            for (Pasien p : pasienList) {
                if (p.getId() == o.getIdPasien()) {
                    cmbPasien.setSelectedItem(p);
                    break;
                }
            }
        }

        JTextField txtTD = new JTextField(isEdit && o.getTekananDarah() != null ? o.getTekananDarah() : "120/80");
        JTextField txtNadi = new JTextField(isEdit && o.getDenyutNadi() != null ? String.valueOf(o.getDenyutNadi()) : "78");
        JTextField txtSuhu = new JTextField(isEdit && o.getSuhuTubuh() != null ? o.getSuhuTubuh().toString() : "36.6");

        JComboBox<String> cmbKondisi = new JComboBox<>(new String[]{"TENANG", "KOOPERATIF", "GELISAH", "AGRESIF", "DEPRESIF"});
        if (isEdit) cmbKondisi.setSelectedItem(o.getStatusKondisi());

        JComboBox<String> cmbMood = new JComboBox<>(new String[]{"Eutimik (Stabil)", "Disforik / Murung", "Euforia", "Iritabel / Mudah Tersinggung", "Cemas / Ansietas"});
        if (isEdit && o.getStatusMood() != null) cmbMood.setSelectedItem(o.getStatusMood());

        JComboBox<String> cmbTidur = new JComboBox<>(new String[]{"NYENYAK", "KURANG", "SULIT_TIDUR", "TIDAK_TIDUR"});
        if (isEdit) cmbTidur.setSelectedItem(o.getKualitasTidur());

        JComboBox<String> cmbObat = new JComboBox<>(new String[]{"PATUH", "MENOLAK", "PERLU_PENDAMPINGAN", "DIBANTU"});
        if (isEdit) cmbObat.setSelectedItem(o.getKepatuhanObat());

        JComboBox<String> cmbMakan = new JComboBox<>(new String[]{"BAIK", "CUKUP", "MENURUN", "MENOLAK_MAKAN"});
        if (isEdit && o.getNafsuMakan() != null) cmbMakan.setSelectedItem(o.getNafsuMakan());

        JTextArea txtCatatan = new JTextArea(isEdit && o.getCatatanPerilaku() != null ? o.getCatatanPerilaku() : "Pasien berinteraksi dengan baik, kooperatif saat minum obat, mengikuti kegiatan terapi harian.", 3, 20);
        txtCatatan.setLineWrap(true);
        txtCatatan.setWrapStyleWord(true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Pilih Pasien Rawat Inap:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(cmbPasien, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Tekanan Darah (mmHg):"), g);
        g.gridx = 1; g.gridy = 1; pan.add(txtTD, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Denyut Nadi (bpm) & Suhu (°C):"), g);
        JPanel pVital = new JPanel(new GridLayout(1, 2, 8, 0));
        pVital.setOpaque(false);
        pVital.add(txtNadi);
        pVital.add(txtSuhu);
        g.gridx = 1; g.gridy = 2; pan.add(pVital, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Status Perilaku / Kondisi:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(cmbKondisi, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Afek / Status Mood:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(cmbMood, g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Kualitas Tidur Semalam:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(cmbTidur, g);

        g.gridx = 0; g.gridy = 6; pan.add(new JLabel("Kepatuhan Minum Obat:"), g);
        g.gridx = 1; g.gridy = 6; pan.add(cmbObat, g);

        g.gridx = 0; g.gridy = 7; pan.add(new JLabel("Nafsu Makan Pasien:"), g);
        g.gridx = 1; g.gridy = 7; pan.add(cmbMakan, g);

        g.gridx = 0; g.gridy = 8; pan.add(new JLabel("Catatan Perilaku Harian:"), g);
        g.gridx = 1; g.gridy = 8; pan.add(new JScrollPane(txtCatatan), g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Hasil Observasi");
        btnSave.addActionListener(e -> {
            try {
                Pasien selP = (Pasien) cmbPasien.getSelectedItem();
                if (selP == null) throw new Exception("Pasien belum dipilih!");

                int perawatId = 1;
                if (SessionManager.getCurrentUser() != null) {
                    Perawat pr = perawatDao.findByUserId(SessionManager.getCurrentUser().getId());
                    if (pr != null) perawatId = pr.getId();
                }

                ObservasiHarian no = isEdit ? o : new ObservasiHarian();
                no.setIdPasien(selP.getId());
                no.setIdPerawat(perawatId);
                no.setTanggalObservasi(Date.valueOf(LocalDate.now()));
                no.setWaktuObservasi(Time.valueOf(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
                no.setTekananDarah(txtTD.getText().trim());
                no.setDenyutNadi(Integer.parseInt(txtNadi.getText().trim()));
                no.setSuhuTubuh(new BigDecimal(txtSuhu.getText().trim()));
                no.setStatusKondisi((String) cmbKondisi.getSelectedItem());
                no.setStatusMood((String) cmbMood.getSelectedItem());
                no.setKualitasTidur((String) cmbTidur.getSelectedItem());
                no.setKepatuhanObat((String) cmbObat.getSelectedItem());
                no.setNafsuMakan((String) cmbMakan.getSelectedItem());
                no.setCatatanPerilaku(txtCatatan.getText().trim());

                keperawatanService.saveObservasi(no);
                UiUtils.showSuccess(this, "Observasi harian berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 9; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(new JScrollPane(pan), BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void deleteObs() {
        ObservasiHarian o = getSelectedObs();
        if (o == null) return;
        if (UiUtils.confirm(this, "Hapus catatan observasi tanggal " + UiUtils.formatDate(o.getTanggalObservasi()) + "?")) {
            try {
                keperawatanService.deleteObservasi(o.getId());
                UiUtils.showSuccess(this, "Data observasi berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
