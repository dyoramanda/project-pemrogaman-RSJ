package com.rsj.ui.pendaftaran;

import com.rsj.dao.LaporanDao;
import com.rsj.dao.PendaftaranDao;
import com.rsj.model.Pendaftaran;
import com.rsj.ui.common.StatCard;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class PendaftaranDashboardPanel extends JPanel {

    private final LaporanDao laporanDao = new LaporanDao();
    private final PendaftaranDao pendaftaranDao = new PendaftaranDao();

    private StatCard cardTotalPasien;
    private StatCard cardRawatInap;
    private StatCard cardRawatJalan;
    private StatCard cardBedTersedia;
    private JTable tblAntrean;
    private DefaultTableModel modelAntrean;

    public PendaftaranDashboardPanel() {
        setLayout(new BorderLayout(0, 16));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel main = new JPanel();
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setOpaque(false);

        // Stats Row
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 14, 14));
        statsRow.setOpaque(false);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));

        cardTotalPasien = new StatCard("Total Pasien Terdaftar", "0", "Data Master", UiUtils.COLOR_PRIMARY);
        cardRawatInap = new StatCard("Pasien Rawat Inap", "0", "Sedang Dirawat", UiUtils.COLOR_WARNING);
        cardRawatJalan = new StatCard("Pasien Rawat Jalan", "0", "Poliklinik Jiwa", UiUtils.COLOR_ACCENT);
        cardBedTersedia = new StatCard("Tempat Tidur Siap", "0", "Kamar Inap Kosong", UiUtils.COLOR_SUCCESS);

        statsRow.add(cardTotalPasien);
        statsRow.add(cardRawatInap);
        statsRow.add(cardRawatJalan);
        statsRow.add(cardBedTersedia);

        // Antrean Pendaftaran Hari Ini Table Card
        JPanel cardAntrean = UiUtils.createCardPanel();
        cardAntrean.setLayout(new BorderLayout(0, 10));

        JLabel lblTitle = new JLabel("Antrean Pendaftaran Kunjungan Pasien Hari Ini");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        modelAntrean = new DefaultTableModel(new String[]{"No. Registrasi", "No. RM", "Nama Pasien", "Layanan", "Dokter Dituju", "Bed Inap", "Status", "Keluhan Awal"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblAntrean = new JTable(modelAntrean);
        UiUtils.styleTable(tblAntrean);
        JScrollPane sp = new JScrollPane(tblAntrean);
        sp.setPreferredSize(new Dimension(900, 360));
        sp.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));

        cardAntrean.add(lblTitle, BorderLayout.NORTH);
        cardAntrean.add(sp, BorderLayout.CENTER);

        main.add(statsRow);
        main.add(Box.createRigidArea(new Dimension(0, 16)));
        main.add(cardAntrean);

        JScrollPane scroll = new JScrollPane(main);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        refreshData();
    }

    public void refreshData() {
        Map<String, Object> stats = laporanDao.getAdminDashboardStats();
        int total = (int) stats.getOrDefault("totalPasien", 0);
        int inap = (int) stats.getOrDefault("pasienRawatInap", 0);
        int jalan = (int) stats.getOrDefault("pasienRawatJalan", 0);
        int totalBed = (int) stats.getOrDefault("totalBed", 0);
        int terisiBed = (int) stats.getOrDefault("bedTerisi", 0);

        cardTotalPasien.setValue(String.valueOf(total));
        cardRawatInap.setValue(inap + " Orang");
        cardRawatJalan.setValue(jalan + " Orang");
        cardBedTersedia.setValue((totalBed - terisiBed) + " Bed");

        // Load registrations
        modelAntrean.setRowCount(0);
        List<Pendaftaran> list = pendaftaranDao.findAll();
        for (Pendaftaran p : list) {
            modelAntrean.addRow(new Object[]{
                    p.getNoPendaftaran(),
                    p.getNoRekamMedis(),
                    p.getNamaPasien(),
                    p.getJenisKunjungan(),
                    p.getNamaDokter() != null ? p.getNamaDokter() : "-",
                    p.getNomorBed() != null ? (p.getNamaRuangan() + " / " + p.getNomorBed()) : "-",
                    p.getStatusPendaftaran(),
                    p.getKeluhanUtama()
            });
        }
    }
}
