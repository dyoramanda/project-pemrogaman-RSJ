package com.rsj.ui.admin;

import com.rsj.model.Ruangan;
import com.rsj.model.TempatTidur;
import com.rsj.service.MasterDataService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class RuanganBedPanel extends JPanel {

    private final MasterDataService masterService = new MasterDataService();

    private final JTable tblRuangan;
    private final DefaultTableModel modelRuangan;
    private List<Ruangan> ruanganList;

    private final JTable tblBed;
    private final DefaultTableModel modelBed;
    private List<TempatTidur> bedList;

    private Ruangan selectedRuangan = null;

    public RuanganBedPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        // Ruangan Section
        JPanel panelRuangan = UiUtils.createCardPanel();
        panelRuangan.setLayout(new BorderLayout(0, 8));

        JPanel topRuangan = new JPanel(new BorderLayout());
        topRuangan.setOpaque(false);
        JLabel lblTR = new JLabel("Daftar Bangsal & Ruangan Perawatan");
        lblTR.setFont(UiUtils.FONT_HEADER);
        lblTR.setForeground(UiUtils.COLOR_PRIMARY);

        JPanel btnRowR = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        btnRowR.setOpaque(false);
        JButton btnAddR = UiUtils.createPrimaryButton("+ Tambah Ruangan");
        btnAddR.addActionListener(e -> showRuanganForm(null));
        JButton btnEditR = UiUtils.createSecondaryButton("Ubah");
        btnEditR.addActionListener(e -> {
            if (selectedRuangan != null) showRuanganForm(selectedRuangan);
            else UiUtils.showError(this, "Pilih ruangan terlebih dahulu!");
        });
        JButton btnDelR = UiUtils.createDangerButton("Hapus");
        btnDelR.addActionListener(e -> deleteRuangan());
        btnRowR.add(btnAddR);
        btnRowR.add(btnEditR);
        btnRowR.add(btnDelR);

        topRuangan.add(lblTR, BorderLayout.WEST);
        topRuangan.add(btnRowR, BorderLayout.EAST);

        modelRuangan = new DefaultTableModel(new String[]{"ID", "Kode", "Nama Ruangan", "Kategori", "Kapasitas", "Tarif/Hari", "Terisi", "Kosong", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblRuangan = new JTable(modelRuangan);
        UiUtils.styleTable(tblRuangan);
        tblRuangan.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = tblRuangan.getSelectedRow();
                if (row >= 0 && row < ruanganList.size()) {
                    selectedRuangan = ruanganList.get(row);
                    reloadBeds();
                }
            }
        });

        panelRuangan.add(topRuangan, BorderLayout.NORTH);
        panelRuangan.add(new JScrollPane(tblRuangan), BorderLayout.CENTER);

        // Bed Section
        JPanel panelBed = UiUtils.createCardPanel();
        panelBed.setLayout(new BorderLayout(0, 8));

        JPanel topBed = new JPanel(new BorderLayout());
        topBed.setOpaque(false);
        JLabel lblTB = new JLabel("Daftar Tempat Tidur (Bed)");
        lblTB.setFont(UiUtils.FONT_HEADER);
        lblTB.setForeground(UiUtils.COLOR_PRIMARY);

        JPanel btnRowB = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        btnRowB.setOpaque(false);
        JButton btnAddB = UiUtils.createPrimaryButton("+ Tambah Bed");
        btnAddB.addActionListener(e -> showBedForm(null));
        JButton btnEditB = UiUtils.createSecondaryButton("Ubah Bed");
        btnEditB.addActionListener(e -> {
            TempatTidur b = getSelectedBed();
            if (b != null) showBedForm(b);
        });
        JButton btnDelB = UiUtils.createDangerButton("Hapus Bed");
        btnDelB.addActionListener(e -> deleteBed());
        btnRowB.add(btnAddB);
        btnRowB.add(btnEditB);
        btnRowB.add(btnDelB);

        topBed.add(lblTB, BorderLayout.WEST);
        topBed.add(btnRowB, BorderLayout.EAST);

        modelBed = new DefaultTableModel(new String[]{"ID", "Ruangan", "Nomor Bed", "Status", "Pasien yang Menempati", "Catatan"}, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblBed = new JTable(modelBed);
        UiUtils.styleTable(tblBed);

        panelBed.add(topBed, BorderLayout.NORTH);
        panelBed.add(new JScrollPane(tblBed), BorderLayout.CENTER);

        // Split Pane (Top Ruangan, Bottom Beds)
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panelRuangan, panelBed);
        split.setDividerLocation(260);
        split.setResizeWeight(0.5);
        split.setBorder(null);

        add(split, BorderLayout.CENTER);

        reloadRuangan();
    }

    public void reloadRuangan() {
        ruanganList = masterService.getAllRuangan();
        modelRuangan.setRowCount(0);
        for (Ruangan r : ruanganList) {
            modelRuangan.addRow(new Object[]{
                    r.getId(),
                    r.getKodeRuangan(),
                    r.getNamaRuangan(),
                    r.getKategori(),
                    r.getKapasitas() + " Bed",
                    UiUtils.formatRupiah(r.getTarifPerHari()),
                    r.getJumlahBedTerisi(),
                    r.getJumlahBedKosong(),
                    r.isStatusAktif() ? "Aktif" : "Nonaktif"
            });
        }
        if (!ruanganList.isEmpty() && selectedRuangan == null) {
            tblRuangan.setRowSelectionInterval(0, 0);
            selectedRuangan = ruanganList.get(0);
        }
        reloadBeds();
    }

    private void reloadBeds() {
        if (selectedRuangan == null) {
            bedList = masterService.getAllTempatTidur();
        } else {
            bedList = masterService.getTempatTidurByRuangan(selectedRuangan.getId());
        }

        modelBed.setRowCount(0);
        for (TempatTidur b : bedList) {
            modelBed.addRow(new Object[]{
                    b.getId(),
                    b.getNamaRuangan(),
                    b.getNomorBed(),
                    b.getStatus(),
                    b.getNamaPasien() != null ? b.getNamaPasien() : "-",
                    b.getCatatan() != null ? b.getCatatan() : "-"
            });
        }
    }

    private TempatTidur getSelectedBed() {
        int r = tblBed.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Pilih baris tempat tidur terlebih dahulu!");
            return null;
        }
        int id = (int) modelBed.getValueAt(r, 0);
        return bedList.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
    }

    private void showRuanganForm(Ruangan r) {
        boolean isEdit = r != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Ruangan" : "Tambah Ruangan", true);
        dlg.setSize(440, 410);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UiUtils.COLOR_SURFACE);
        p.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JTextField txtKode = new JTextField(isEdit ? r.getKodeRuangan() : "");
        JTextField txtNama = new JTextField(isEdit ? r.getNamaRuangan() : "");
        JComboBox<String> cmbKat = new JComboBox<>(new String[]{"RAWAT_INAP_AKUT", "RAWAT_INAP_TENANG", "REHABILITASI", "ISOLASI", "VIP"});
        if (isEdit) cmbKat.setSelectedItem(r.getKategori());
        JTextField txtKap = new JTextField(isEdit ? String.valueOf(r.getKapasitas()) : "4");
        JTextField txtTarif = new JTextField(isEdit && r.getTarifPerHari() != null ? r.getTarifPerHari().toString() : "250000");
        JTextField txtFas = new JTextField(isEdit && r.getFasilitas() != null ? r.getFasilitas() : "AC, Kamar mandi dalam anti-cedera, CCTV");
        JCheckBox chkAktif = new JCheckBox("Ruangan Aktif", isEdit ? r.isStatusAktif() : true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; p.add(new JLabel("Kode Ruangan:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; p.add(txtKode, g);

        g.gridx = 0; g.gridy = 1; p.add(new JLabel("Nama Ruangan:"), g);
        g.gridx = 1; g.gridy = 1; p.add(txtNama, g);

        g.gridx = 0; g.gridy = 2; p.add(new JLabel("Kategori Perawatan:"), g);
        g.gridx = 1; g.gridy = 2; p.add(cmbKat, g);

        g.gridx = 0; g.gridy = 3; p.add(new JLabel("Kapasitas (Bed):"), g);
        g.gridx = 1; g.gridy = 3; p.add(txtKap, g);

        g.gridx = 0; g.gridy = 4; p.add(new JLabel("Tarif per Hari (Rp):"), g);
        g.gridx = 1; g.gridy = 4; p.add(txtTarif, g);

        g.gridx = 0; g.gridy = 5; p.add(new JLabel("Fasilitas:"), g);
        g.gridx = 1; g.gridy = 5; p.add(txtFas, g);

        g.gridx = 1; g.gridy = 6; p.add(chkAktif, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Ruangan");
        btnSave.addActionListener(e -> {
            try {
                Ruangan nr = isEdit ? r : new Ruangan();
                nr.setKodeRuangan(txtKode.getText().trim());
                nr.setNamaRuangan(txtNama.getText().trim());
                nr.setKategori((String) cmbKat.getSelectedItem());
                nr.setKapasitas(Integer.parseInt(txtKap.getText().trim()));
                nr.setTarifPerHari(new BigDecimal(txtTarif.getText().trim()));
                nr.setFasilitas(txtFas.getText().trim());
                nr.setStatusAktif(chkAktif.isSelected());
                masterService.saveRuangan(nr);
                UiUtils.showSuccess(this, "Data ruangan berhasil disimpan!");
                dlg.dispose();
                reloadRuangan();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 7; g.gridwidth = 2;
        g.insets = new Insets(12, 5, 5, 5);
        p.add(btnSave, g);

        dlg.add(p, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void showBedForm(TempatTidur b) {
        boolean isEdit = b != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Bed" : "Tambah Tempat Tidur", true);
        dlg.setSize(400, 320);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(UiUtils.COLOR_SURFACE);
        p.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JComboBox<Ruangan> cmbR = new JComboBox<>(ruanganList.toArray(new Ruangan[0]));
        if (selectedRuangan != null) cmbR.setSelectedItem(selectedRuangan);

        JTextField txtNo = new JTextField(isEdit ? b.getNomorBed() : "");
        JComboBox<String> cmbStat = new JComboBox<>(new String[]{"TERSEDIA", "TERISI", "DALAM_PERBAIKAN", "DIBERSIHKAN"});
        if (isEdit) cmbStat.setSelectedItem(b.getStatus());
        JTextField txtCat = new JTextField(isEdit && b.getCatatan() != null ? b.getCatatan() : "Siap pakai");

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; p.add(new JLabel("Pilih Ruangan:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; p.add(cmbR, g);

        g.gridx = 0; g.gridy = 1; p.add(new JLabel("Nomor / Kode Bed:"), g);
        g.gridx = 1; g.gridy = 1; p.add(txtNo, g);

        g.gridx = 0; g.gridy = 2; p.add(new JLabel("Status Bed:"), g);
        g.gridx = 1; g.gridy = 2; p.add(cmbStat, g);

        g.gridx = 0; g.gridy = 3; p.add(new JLabel("Catatan Khusus:"), g);
        g.gridx = 1; g.gridy = 3; p.add(txtCat, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Bed");
        btnSave.addActionListener(e -> {
            try {
                TempatTidur nb = isEdit ? b : new TempatTidur();
                Ruangan selR = (Ruangan) cmbR.getSelectedItem();
                if (selR == null) throw new Exception("Pilih ruangan terlebih dahulu!");
                nb.setIdRuangan(selR.getId());
                nb.setNomorBed(txtNo.getText().trim());
                nb.setStatus((String) cmbStat.getSelectedItem());
                nb.setCatatan(txtCat.getText().trim());
                masterService.saveTempatTidur(nb);
                UiUtils.showSuccess(this, "Data bed berhasil disimpan!");
                dlg.dispose();
                reloadBeds();
                reloadRuangan();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 4; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        p.add(btnSave, g);

        dlg.add(p, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void deleteRuangan() {
        if (selectedRuangan == null) return;
        if (UiUtils.confirm(this, "Hapus ruangan " + selectedRuangan.getNamaRuangan() + " beserta seluruh tempat tidurnya?")) {
            try {
                masterService.deleteRuangan(selectedRuangan.getId());
                selectedRuangan = null;
                UiUtils.showSuccess(this, "Ruangan berhasil dihapus.");
                reloadRuangan();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }

    private void deleteBed() {
        TempatTidur b = getSelectedBed();
        if (b == null) return;
        if (UiUtils.confirm(this, "Hapus bed " + b.getNomorBed() + "?")) {
            try {
                masterService.deleteTempatTidur(b.getId());
                UiUtils.showSuccess(this, "Bed berhasil dihapus.");
                reloadBeds();
                reloadRuangan();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
