package com.rsj.ui;

import com.rsj.config.DatabaseConfig;
import com.rsj.config.DatabaseInitializer;
import com.rsj.model.User;
import com.rsj.ui.admin.AdminDashboardPanel;
import com.rsj.ui.admin.DokterPerawatPanel;
import com.rsj.ui.admin.LaporanPanel;
import com.rsj.ui.admin.RuanganBedPanel;
import com.rsj.ui.admin.UserManagementPanel;
import com.rsj.ui.apoteker.ApotekerDashboardPanel;
import com.rsj.ui.apoteker.ObatStokPanel;
import com.rsj.ui.apoteker.ResepPenyerahanPanel;
import com.rsj.ui.common.AccessDeniedDialog;
import com.rsj.ui.common.LoginPanel;
import com.rsj.ui.common.SidebarPanel;
import com.rsj.ui.common.TopBarPanel;
import com.rsj.ui.common.WelcomePanel;
import com.rsj.ui.dokter.DiagnosisResepPanel;
import com.rsj.ui.dokter.DokterDashboardPanel;
import com.rsj.ui.dokter.JadwalPraktikPanel;
import com.rsj.ui.dokter.PemeriksaanRekamMedisPanel;
import com.rsj.ui.kasir.PembayaranPanel;
import com.rsj.ui.kasir.TagihanPanel;
import com.rsj.ui.keluarga.BookingKunjunganPanel;
import com.rsj.ui.keluarga.KeluargaDashboardPanel;
import com.rsj.ui.keluarga.PerkembanganPasienPanel;
import com.rsj.ui.keluarga.TagihanKeluargaPanel;
import com.rsj.ui.pendaftaran.PasienPanel;
import com.rsj.ui.pendaftaran.PendaftaranDashboardPanel;
import com.rsj.ui.pendaftaran.PenanggungJawabPanel;
import com.rsj.ui.pendaftaran.RegistrasiKunjunganPanel;
import com.rsj.ui.perawat.BedManagementPanel;
import com.rsj.ui.perawat.CatatanInsidenPanel;
import com.rsj.ui.perawat.ObservasiHarianPanel;
import com.rsj.ui.perawat.PerawatDashboardPanel;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MainFrame extends JFrame {

    private final CardLayout rootCardLayout = new CardLayout();
    private final JPanel rootPanel = new JPanel(rootCardLayout);

    private final WelcomePanel welcomePanel;
    private final LoginPanel loginPanel;

    private final JPanel appContainer = new JPanel(new BorderLayout());
    private final SidebarPanel sidebarPanel;
    private final TopBarPanel topBarPanel;

    private final CardLayout contentCardLayout = new CardLayout();
    private final JPanel contentContainer = new JPanel(contentCardLayout);

    // Module Panels
    private AdminDashboardPanel adminDashboardPanel;
    private UserManagementPanel userManagementPanel;
    private DokterPerawatPanel dokterPerawatPanel;
    private RuanganBedPanel ruanganBedPanel;
    private LaporanPanel laporanPanel;

    private PendaftaranDashboardPanel pendaftaranDashboardPanel;
    private PasienPanel pasienPanel;
    private PenanggungJawabPanel penanggungJawabPanel;
    private RegistrasiKunjunganPanel registrasiKunjunganPanel;

    private DokterDashboardPanel dokterDashboardPanel;
    private JadwalPraktikPanel jadwalPraktikPanel;
    private PemeriksaanRekamMedisPanel pemeriksaanRekamMedisPanel;
    private DiagnosisResepPanel diagnosisResepPanel;

    private PerawatDashboardPanel perawatDashboardPanel;
    private ObservasiHarianPanel observasiHarianPanel;
    private BedManagementPanel bedManagementPanel;
    private CatatanInsidenPanel catatanInsidenPanel;

    private ApotekerDashboardPanel apotekerDashboardPanel;
    private ObatStokPanel obatStokPanel;
    private ResepPenyerahanPanel resepPenyerahanPanel;

    private TagihanPanel tagihanPanel;
    private PembayaranPanel pembayaranPanel;

    private KeluargaDashboardPanel keluargaDashboardPanel;
    private PerkembanganPasienPanel perkembanganPasienPanel;
    private BookingKunjunganPanel bookingKunjunganPanel;
    private TagihanKeluargaPanel tagihanKeluargaPanel;

    public MainFrame() {
        setTitle("Sistem Informasi Manajemen Rumah Sakit Jiwa & ODGJ (RSJ Sehat Jiwa)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 800);
        setMinimumSize(new Dimension(1024, 700));
        setLocationRelativeTo(null);

        // Sidebar & TopBar
        sidebarPanel = new SidebarPanel(this::navigateToMenu);
        topBarPanel = new TopBarPanel(this, this::handleLogout);

        // Public Panels
        welcomePanel = new WelcomePanel(() -> rootCardLayout.show(rootPanel, "LOGIN"));
        loginPanel = new LoginPanel(this, this::handleLoginSuccess, () -> rootCardLayout.show(rootPanel, "WELCOME"));

        // Build Application Shell
        appContainer.add(sidebarPanel, BorderLayout.WEST);
        appContainer.add(topBarPanel, BorderLayout.NORTH);
        appContainer.add(contentContainer, BorderLayout.CENTER);

        initModulePanels();

        rootPanel.add(welcomePanel, "WELCOME");
        rootPanel.add(loginPanel, "LOGIN");
        rootPanel.add(appContainer, "APP");

        setContentPane(rootPanel);
        rootCardLayout.show(rootPanel, "WELCOME");
    }

    private void initModulePanels() {
        // Admin
        adminDashboardPanel = new AdminDashboardPanel();
        userManagementPanel = new UserManagementPanel();
        dokterPerawatPanel = new DokterPerawatPanel();
        ruanganBedPanel = new RuanganBedPanel();
        laporanPanel = new LaporanPanel();

        contentContainer.add(adminDashboardPanel, "ADMIN_DASHBOARD");
        contentContainer.add(userManagementPanel, "ADMIN_USER");
        contentContainer.add(dokterPerawatPanel, "ADMIN_DOKTER_PERAWAT");
        contentContainer.add(ruanganBedPanel, "ADMIN_RUANGAN_BED");
        contentContainer.add(laporanPanel, "ADMIN_LAPORAN");

        // Pendaftaran
        pendaftaranDashboardPanel = new PendaftaranDashboardPanel();
        pasienPanel = new PasienPanel();
        penanggungJawabPanel = new PenanggungJawabPanel();
        registrasiKunjunganPanel = new RegistrasiKunjunganPanel();

        contentContainer.add(pendaftaranDashboardPanel, "PENDAFTARAN_DASHBOARD");
        contentContainer.add(pasienPanel, "PENDAFTARAN_PASIEN");
        contentContainer.add(penanggungJawabPanel, "PENDAFTARAN_PJ");
        contentContainer.add(registrasiKunjunganPanel, "PENDAFTARAN_KUNJUNGAN");

        // Dokter
        dokterDashboardPanel = new DokterDashboardPanel();
        jadwalPraktikPanel = new JadwalPraktikPanel();
        pemeriksaanRekamMedisPanel = new PemeriksaanRekamMedisPanel();
        diagnosisResepPanel = new DiagnosisResepPanel();

        contentContainer.add(dokterDashboardPanel, "DOKTER_DASHBOARD");
        contentContainer.add(jadwalPraktikPanel, "DOKTER_JADWAL");
        contentContainer.add(pemeriksaanRekamMedisPanel, "DOKTER_REKAM_MEDIS");
        contentContainer.add(diagnosisResepPanel, "DOKTER_DIAGNOSIS_RESEP");

        // Perawat
        perawatDashboardPanel = new PerawatDashboardPanel();
        observasiHarianPanel = new ObservasiHarianPanel();
        bedManagementPanel = new BedManagementPanel();
        catatanInsidenPanel = new CatatanInsidenPanel();

        contentContainer.add(perawatDashboardPanel, "PERAWAT_DASHBOARD");
        contentContainer.add(observasiHarianPanel, "PERAWAT_OBSERVASI");
        contentContainer.add(bedManagementPanel, "PERAWAT_BED");
        contentContainer.add(catatanInsidenPanel, "PERAWAT_INSIDEN");

        // Apoteker
        apotekerDashboardPanel = new ApotekerDashboardPanel();
        obatStokPanel = new ObatStokPanel();
        resepPenyerahanPanel = new ResepPenyerahanPanel();

        contentContainer.add(apotekerDashboardPanel, "APOTEKER_DASHBOARD");
        contentContainer.add(obatStokPanel, "APOTEKER_OBAT");
        contentContainer.add(resepPenyerahanPanel, "APOTEKER_RESEP");

        // Kasir
        tagihanPanel = new TagihanPanel();
        pembayaranPanel = new PembayaranPanel();

        contentContainer.add(tagihanPanel, "KASIR_TAGIHAN");
        contentContainer.add(pembayaranPanel, "KASIR_PEMBAYARAN");

        // Keluarga
        keluargaDashboardPanel = new KeluargaDashboardPanel();
        perkembanganPasienPanel = new PerkembanganPasienPanel();
        bookingKunjunganPanel = new BookingKunjunganPanel();
        tagihanKeluargaPanel = new TagihanKeluargaPanel();

        contentContainer.add(keluargaDashboardPanel, "KELUARGA_DASHBOARD");
        contentContainer.add(perkembanganPasienPanel, "KELUARGA_PERKEMBANGAN");
        contentContainer.add(bookingKunjunganPanel, "KELUARGA_BOOKING");
        contentContainer.add(tagihanKeluargaPanel, "KELUARGA_TAGIHAN");
    }

    private void handleLoginSuccess(User user) {
        topBarPanel.updateUserData();
        sidebarPanel.rebuildMenuForCurrentUser();

        // Switch to appropriate landing panel based on role
        String defaultMenu = "ADMIN_DASHBOARD";
        switch (user.getRole()) {
            case "ADMIN": defaultMenu = "ADMIN_DASHBOARD"; break;
            case "PETUGAS_PENDAFTARAN": defaultMenu = "PENDAFTARAN_DASHBOARD"; break;
            case "DOKTER": defaultMenu = "DOKTER_DASHBOARD"; break;
            case "PERAWAT": defaultMenu = "PERAWAT_DASHBOARD"; break;
            case "APOTEKER": defaultMenu = "APOTEKER_DASHBOARD"; break;
            case "KASIR": defaultMenu = "KASIR_TAGIHAN"; break;
            case "KELUARGA_PASIEN": defaultMenu = "KELUARGA_DASHBOARD"; break;
        }

        navigateToMenu(defaultMenu);
        rootCardLayout.show(rootPanel, "APP");
    }

    private void handleLogout() {
        rootCardLayout.show(rootPanel, "WELCOME");
    }

    private void navigateToMenu(String menuId) {
        User u = SessionManager.getCurrentUser();
        if (u == null) {
            handleLogout();
            return;
        }

        // Role authorization check
        if (!isAuthorized(u.getRole(), menuId)) {
            AccessDeniedDialog.show(this, u.getRole());
            return;
        }

        // Refresh panel data
        refreshPanel(menuId);

        // Update TopBar title
        topBarPanel.setPageTitle(formatPageTitle(menuId));

        contentCardLayout.show(contentContainer, menuId);
    }

    private boolean isAuthorized(String role, String menuId) {
        if ("ADMIN".equals(role)) {
            return true;
        }
        if ("PETUGAS_PENDAFTARAN".equals(role) && menuId.startsWith("PENDAFTARAN_")) {
            return true;
        }
        if ("DOKTER".equals(role) && menuId.startsWith("DOKTER_")) {
            return true;
        }
        if ("PERAWAT".equals(role) && menuId.startsWith("PERAWAT_")) {
            return true;
        }
        if ("APOTEKER".equals(role) && menuId.startsWith("APOTEKER_")) {
            return true;
        }
        if ("KASIR".equals(role) && menuId.startsWith("KASIR_")) {
            return true;
        }
        if ("KELUARGA_PASIEN".equals(role) && menuId.startsWith("KELUARGA_")) {
            return true;
        }
        return false;
    }

    private void refreshPanel(String menuId) {
        switch (menuId) {
            case "ADMIN_DASHBOARD": adminDashboardPanel.refreshData(); break;
            case "ADMIN_USER": userManagementPanel.reloadData(); break;
            case "ADMIN_DOKTER_PERAWAT": dokterPerawatPanel.reloadData(); break;
            case "ADMIN_RUANGAN_BED": ruanganBedPanel.reloadRuangan(); break;
            case "PENDAFTARAN_DASHBOARD": pendaftaranDashboardPanel.refreshData(); break;
            case "PENDAFTARAN_PASIEN": pasienPanel.reloadData(); break;
            case "PENDAFTARAN_PJ": penanggungJawabPanel.reloadData(); break;
            case "PENDAFTARAN_KUNJUNGAN": registrasiKunjunganPanel.reloadData(); break;
            case "DOKTER_DASHBOARD": dokterDashboardPanel.refreshData(); break;
            case "DOKTER_JADWAL": jadwalPraktikPanel.reloadData(); break;
            case "DOKTER_REKAM_MEDIS": pemeriksaanRekamMedisPanel.reloadData(); break;
            case "DOKTER_DIAGNOSIS_RESEP": diagnosisResepPanel.reloadData(); break;
            case "PERAWAT_DASHBOARD": perawatDashboardPanel.refreshData(); break;
            case "PERAWAT_OBSERVASI": observasiHarianPanel.reloadData(); break;
            case "PERAWAT_BED": bedManagementPanel.reloadData(); break;
            case "PERAWAT_INSIDEN": catatanInsidenPanel.reloadData(); break;
            case "APOTEKER_DASHBOARD": apotekerDashboardPanel.refreshData(); break;
            case "APOTEKER_OBAT": obatStokPanel.reloadData(); break;
            case "APOTEKER_RESEP": resepPenyerahanPanel.reloadData(); break;
            case "KASIR_TAGIHAN": tagihanPanel.reloadData(); break;
            case "KASIR_PEMBAYARAN": pembayaranPanel.reloadData(); break;
            case "KELUARGA_DASHBOARD": keluargaDashboardPanel.refreshData(); break;
            case "KELUARGA_PERKEMBANGAN": perkembanganPasienPanel.reloadData(); break;
            case "KELUARGA_BOOKING": bookingKunjunganPanel.reloadData(); break;
            case "KELUARGA_TAGIHAN": tagihanKeluargaPanel.reloadData(); break;
        }
    }

    private String formatPageTitle(String menuId) {
        switch (menuId) {
            case "ADMIN_DASHBOARD": return "Dashboard Administrator";
            case "ADMIN_USER": return "Manajemen Pengguna & Hak Akses";
            case "ADMIN_DOKTER_PERAWAT": return "Kelola Data Dokter & Perawat";
            case "ADMIN_RUANGAN_BED": return "Manajemen Ruangan & Bed Perawatan";
            case "ADMIN_LAPORAN": return "Laporan & Cetak Rekapitulasi";
            case "PENDAFTARAN_DASHBOARD": return "Dashboard Loket Pendaftaran";
            case "PENDAFTARAN_PASIEN": return "Master Data Pasien Jiwa";
            case "PENDAFTARAN_PJ": return "Data Penanggung Jawab / Keluarga";
            case "PENDAFTARAN_KUNJUNGAN": return "Pendaftaran Kunjungan Pasien";
            case "DOKTER_DASHBOARD": return "Antrean Pasien Hari Ini";
            case "DOKTER_JADWAL": return "Kelola Jadwal Praktik";
            case "DOKTER_REKAM_MEDIS": return "Pemeriksaan & Rekam Medis";
            case "DOKTER_DIAGNOSIS_RESEP": return "Diagnosis & Resep Obat";
            case "PERAWAT_DASHBOARD": return "Dashboard Asuhan Keperawatan";
            case "PERAWAT_OBSERVASI": return "Catatan Observasi Harian Pasien";
            case "PERAWAT_BED": return "Manajemen Bed & Bangsal Rawat Inap";
            case "PERAWAT_INSIDEN": return "Catatan & Evaluasi Insiden";
            case "APOTEKER_DASHBOARD": return "Dashboard Farmasi & Obat";
            case "APOTEKER_OBAT": return "Katalog & Stok Obat Jiwa";
            case "APOTEKER_RESEP": return "Telaah & Penyerahan Resep";
            case "KASIR_TAGIHAN": return "Manajemen Tagihan Perawatan";
            case "KASIR_PEMBAYARAN": return "Kasir Pembayaran & Cetak Struk";
            case "KELUARGA_DASHBOARD": return "Portal Informasi Keluarga";
            case "KELUARGA_PERKEMBANGAN": return "Catatan Pemulihan Pasien";
            case "KELUARGA_BOOKING": return "Booking Jadwal Kunjungan (Bezuk)";
            case "KELUARGA_TAGIHAN": return "Informasi Tagihan Perawatan";
            default: return "Sistem Informasi RSJ";
        }
    }
}
