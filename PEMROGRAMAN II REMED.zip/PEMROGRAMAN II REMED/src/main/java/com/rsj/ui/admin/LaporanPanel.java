package com.rsj.ui.admin;

import com.rsj.dao.LaporanDao;
import com.rsj.util.PrintHelper;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class LaporanPanel extends JPanel {

    private final LaporanDao laporanDao = new LaporanDao();

    private final JComboBox<String> cmbJenisLaporan;
    private final JComboBox<String> cmbPeriode;
    private final JTable tblLaporan;
    private final DefaultTableModel modelLaporan;
    private final JLabel lblSummary;
    private final JPanel printPreviewCard;

    public LaporanPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        printPreviewCard = UiUtils.createCardPanel();
        printPreviewCard.setLayout(new BorderLayout(0, 10));

        // Filter Bar
        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);

        cmbJenisLaporan = new JComboBox<>(new String[]{
                "Laporan Kunjungan Pasien (Rawat Jalan & Inap)",
                "Laporan Pendapatan & Kasir",
                "Laporan Okupansi & Hunian Tempat Tidur"
        });
        cmbJenisLaporan.addActionListener(e -> generateReport());

        cmbPeriode = new JComboBox<>(new String[]{"Semua Periode", "Bulan Ini", "Hari Ini"});
        cmbPeriode.addActionListener(e -> generateReport());

        JButton btnFilter = UiUtils.createSecondaryButton("Tampilkan Laporan");
        btnFilter.addActionListener(e -> generateReport());

        left.add(new JLabel("Jenis Laporan:"));
        left.add(cmbJenisLaporan);
        left.add(new JLabel("Periode:"));
        left.add(cmbPeriode);
        left.add(btnFilter);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setOpaque(false);
        JButton btnCetak = UiUtils.createPrimaryButton("Cetak Dokumen Laporan");
        btnCetak.addActionListener(e -> {
            PrintHelper.printComponent(printPreviewCard);
        });
        right.add(btnCetak);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel repHeader = new JPanel(new GridLayout(2, 1, 2, 2));
        repHeader.setOpaque(false);
        JLabel lblRepTitle = new JLabel("RUMAH SAKIT JIWA SEHAT JIWA - DOKUMEN REKAPITULASI RESMI");
        lblRepTitle.setFont(UiUtils.FONT_HEADER);
        lblRepTitle.setForeground(UiUtils.COLOR_PRIMARY);

        lblSummary = new JLabel("Total Data: 0");
        lblSummary.setFont(UiUtils.FONT_REGULAR);
        lblSummary.setForeground(UiUtils.COLOR_TEXT_MUTED);

        repHeader.add(lblRepTitle);
        repHeader.add(lblSummary);

        modelLaporan = new DefaultTableModel();
        tblLaporan = new JTable(modelLaporan);
        UiUtils.styleTable(tblLaporan);
        JScrollPane sp = new JScrollPane(tblLaporan);
        sp.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));

        printPreviewCard.add(repHeader, BorderLayout.NORTH);
        printPreviewCard.add(sp, BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(printPreviewCard, BorderLayout.CENTER);

        generateReport();
    }

    private void generateReport() {
        int reportIdx = cmbJenisLaporan.getSelectedIndex();
        String periode = (String) cmbPeriode.getSelectedItem();

        Date tglMulai = null;
        Date tglSelesai = null;
        LocalDate now = LocalDate.now();

        if ("Hari Ini".equals(periode)) {
            tglMulai = Date.valueOf(now);
            tglSelesai = Date.valueOf(now);
        } else if ("Bulan Ini".equals(periode)) {
            tglMulai = Date.valueOf(now.withDayOfMonth(1));
            tglSelesai = Date.valueOf(now.withDayOfMonth(now.lengthOfMonth()));
        }

        if (reportIdx == 0) {
            // Laporan Kunjungan
            modelLaporan.setDataVector(new Object[][]{}, new Object[]{
                    "No. Registrasi", "Tanggal Daftar", "No. RM", "Nama Pasien", "Jenis Layanan", "Dokter Pemeriksa", "Status", "Keluhan Utama"
            });
            List<Map<String, Object>> data = laporanDao.getLaporanKunjungan(tglMulai, tglSelesai);
            for (Map<String, Object> m : data) {
                modelLaporan.addRow(new Object[]{
                        m.get("no_pendaftaran"),
                        UiUtils.formatDate((Date) m.get("tanggal_daftar")),
                        m.get("no_rekam_medis"),
                        m.get("nama_pasien"),
                        m.get("jenis_kunjungan"),
                        m.get("nama_dokter"),
                        m.get("status_pendaftaran"),
                        m.get("keluhan_utama")
                });
            }
            lblSummary.setText("Laporan Kunjungan Pasien • Total Kunjungan: " + data.size() + " Registrasi");
        } else if (reportIdx == 1) {
            // Laporan Pendapatan
            modelLaporan.setDataVector(new Object[][]{}, new Object[]{
                    "No. Transaksi", "Waktu Pembayaran", "No. Tagihan", "Nama Pasien", "Metode", "Kasir Penerima", "Jumlah Bayar (Rp)"
            });
            List<Map<String, Object>> data = laporanDao.getLaporanPendapatan(tglMulai, tglSelesai);
            BigDecimal totalUang = BigDecimal.ZERO;
            for (Map<String, Object> m : data) {
                BigDecimal bayar = (BigDecimal) m.get("jumlah_dibayar");
                if (bayar != null) totalUang = totalUang.add(bayar);
                modelLaporan.addRow(new Object[]{
                        m.get("no_transaksi"),
                        UiUtils.formatDateTime((java.sql.Timestamp) m.get("tanggal_bayar")),
                        m.get("no_tagihan"),
                        m.get("nama_pasien"),
                        m.get("metode_pembayaran"),
                        m.get("nama_kasir"),
                        UiUtils.formatRupiah(bayar)
                });
            }
            lblSummary.setText("Laporan Penerimaan Kasir • Total Transaksi: " + data.size() + " • Total Akumulasi: " + UiUtils.formatRupiah(totalUang));
        } else {
            // Laporan Hunian Bed
            modelLaporan.setDataVector(new Object[][]{}, new Object[]{
                    "Nama Ruangan", "Kategori Bangsal", "Nomor Bed", "Status Keterisian", "Nama Pasien Dirawat", "No. RM", "Tanggal Masuk Inap"
            });
            List<Map<String, Object>> data = laporanDao.getLaporanHunianBed();
            long terisi = data.stream().filter(m -> "TERISI".equalsIgnoreCase((String) m.get("status"))).count();
            for (Map<String, Object> m : data) {
                modelLaporan.addRow(new Object[]{
                        m.get("nama_ruangan"),
                        m.get("kategori"),
                        m.get("nomor_bed"),
                        m.get("status"),
                        m.get("nama_pasien"),
                        m.get("no_rm"),
                        UiUtils.formatDate((Date) m.get("tanggal_masuk"))
                });
            }
            lblSummary.setText("Laporan Hunian Tempat Tidur • Total Kapasitas: " + data.size() + " Bed • Terisi: " + terisi + " Bed (" + (data.isEmpty() ? 0 : Math.round(((double)terisi/data.size())*100)) + "%)");
        }
        UiUtils.styleTable(tblLaporan);
    }
}
