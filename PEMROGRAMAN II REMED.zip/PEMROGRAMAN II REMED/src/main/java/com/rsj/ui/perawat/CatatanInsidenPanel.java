package com.rsj.ui.perawat;

import com.rsj.model.CatatanInsiden;
import com.rsj.model.Pasien;
import com.rsj.service.KeperawatanService;
import com.rsj.service.PelayananService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CatatanInsidenPanel extends JPanel {

    private final KeperawatanService keperawatanService = new KeperawatanService();
    private final PelayananService pelayananService = new PelayananService();

    private final JTable tblInsiden;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbJenisFilter;
    private final JComboBox<String> cmbRisikoFilter;
    private List<CatatanInsiden> insidenList;

    public CatatanInsidenPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        txtSearch = new JTextField(12);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari pasien...");
        txtSearch.addActionListener(e -> reloadData());

        cmbJenisFilter = new JComboBox<>(new String[]{"SEMUA", "AGRESI_VERBAL", "AGRESI_FISIK", "PERCOBAAN_KABUR", "JATUH", "PENOLAKAN_MEDIKASI", "SELF_HARM", "LAINNYA"});
        cmbJenisFilter.addActionListener(e -> reloadData());

        cmbRisikoFilter = new JComboBox<>(new String[]{"SEMUA", "RENDAH", "SEDANG", "TINGGI", "KRITIS"});
        cmbRisikoFilter.addActionListener(e -> reloadData());

        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());

        left.add(new JLabel("Pencarian:"));
        left.add(txtSearch);
        left.add(new JLabel("Jenis:"));
        left.add(cmbJenisFilter);
        left.add(new JLabel("Risiko:"));
        left.add(cmbRisikoFilter);
        left.add(btnSearch);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnAdd = UiUtils.createPrimaryButton("+ Laporkan Insiden");
        btnAdd.addActionListener(e -> showInsidenForm(null));

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah / Evaluasi");
        btnEdit.addActionListener(e -> {
            CatatanInsiden ci = getSelectedInsiden();
            if (ci != null) showInsidenForm(ci);
        });

        JButton btnDel = UiUtils.createDangerButton("Hapus");
        btnDel.addActionListener(e -> deleteInsiden());

        right.add(btnAdd);
        right.add(btnEdit);
        right.add(btnDel);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "Waktu Insiden", "No. RM", "Nama Pasien", "Jenis Insiden", "Tingkat Risiko", "Deskripsi Kejadian", "Tindakan De-eskalasi", "Status", "Pelapor"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblInsiden = new JTable(model);
        UiUtils.styleTable(tblInsiden);
        cardTable.add(new JScrollPane(tblInsiden), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String jns = (String) cmbJenisFilter.getSelectedItem();
        String rsk = (String) cmbRisikoFilter.getSelectedItem();

        insidenList = keperawatanService.searchInsiden(kw, jns, rsk);
        model.setRowCount(0);
        for (CatatanInsiden ci : insidenList) {
            model.addRow(new Object[]{
                    ci.getId(),
                    UiUtils.formatDate(ci.getTanggalInsiden()) + " " + UiUtils.formatTime(ci.getWaktuInsiden()),
                    ci.getNoRekamMedis(),
                    ci.getNamaPasien(),
                    ci.getJenisInsiden(),
                    ci.getTingkatRisiko(),
                    ci.getDeskripsiKejadian(),
                    ci.getTindakanPenanganan(),
                    ci.getStatusPenyelesaian(),
                    ci.getNamaPelapor()
            });
        }
    }

    private CatatanInsiden getSelectedInsiden() {
        int r = tblInsiden.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris insiden terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return insidenList.stream().filter(ci -> ci.getId() == id).findFirst().orElse(null);
    }

    private void showInsidenForm(CatatanInsiden ci) {
        boolean isEdit = ci != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Evaluasi Insiden Pasien" : "Laporan Insiden Keselamatan Pasien", true);
        dlg.setSize(540, 520);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        List<Pasien> pasiens = pelayananService.getAllPasien();
        JComboBox<Pasien> cmbPasien = new JComboBox<>(pasiens.toArray(new Pasien[0]));
        if (isEdit) {
            for (Pasien p : pasiens) {
                if (p.getId() == ci.getIdPasien()) {
                    cmbPasien.setSelectedItem(p);
                    break;
                }
            }
        }

        JComboBox<String> cmbJenis = new JComboBox<>(new String[]{"AGRESI_VERBAL", "AGRESI_FISIK", "PERCOBAAN_KABUR", "JATUH", "PENOLAKAN_MEDIKASI", "SELF_HARM", "LAINNYA"});
        if (isEdit) cmbJenis.setSelectedItem(ci.getJenisInsiden());

        JComboBox<String> cmbRisiko = new JComboBox<>(new String[]{"RENDAH", "SEDANG", "TINGGI", "KRITIS"});
        if (isEdit) cmbRisiko.setSelectedItem(ci.getTingkatRisiko());

        JComboBox<String> cmbStatus = new JComboBox<>(new String[]{"DILAPORKAN", "DALAM_PENANGANAN", "SELESAI", "DIEVALUASI"});
        if (isEdit) cmbStatus.setSelectedItem(ci.getStatusPenyelesaian());

        JTextArea txtDeskripsi = new JTextArea(isEdit ? ci.getDeskripsiKejadian() : "", 3, 20);
        txtDeskripsi.setLineWrap(true);
        txtDeskripsi.setWrapStyleWord(true);

        JTextArea txtTindakan = new JTextArea(isEdit && ci.getTindakanPenanganan() != null ? ci.getTindakanPenanganan() : "De-eskalasi verbal, pemisahan lingkungan, medikasi darurat jika diinstruksikan dokter.", 3, 20);
        txtTindakan.setLineWrap(true);
        txtTindakan.setWrapStyleWord(true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Pasien Terkait:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(cmbPasien, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Jenis Insiden:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(cmbJenis, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Tingkat Risiko:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(cmbRisiko, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Status Penanganan:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(cmbStatus, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Kronologi Kejadian:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(new JScrollPane(txtDeskripsi), g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Tindakan De-eskalasi:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(new JScrollPane(txtTindakan), g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Laporan Insiden");
        btnSave.addActionListener(e -> {
            try {
                Pasien selP = (Pasien) cmbPasien.getSelectedItem();
                if (selP == null) throw new Exception("Pasien belum dipilih!");

                CatatanInsiden nci = isEdit ? ci : new CatatanInsiden();
                nci.setIdPasien(selP.getId());
                nci.setTanggalInsiden(Date.valueOf(LocalDate.now()));
                nci.setWaktuInsiden(Time.valueOf(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
                nci.setJenisInsiden((String) cmbJenis.getSelectedItem());
                nci.setTingkatRisiko((String) cmbRisiko.getSelectedItem());
                nci.setStatusPenyelesaian((String) cmbStatus.getSelectedItem());
                nci.setDeskripsiKejadian(txtDeskripsi.getText().trim());
                nci.setTindakanPenanganan(txtTindakan.getText().trim());

                keperawatanService.saveInsiden(nci);
                UiUtils.showSuccess(this, "Laporan insiden berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 6; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void deleteInsiden() {
        CatatanInsiden ci = getSelectedInsiden();
        if (ci == null) return;
        if (UiUtils.confirm(this, "Hapus laporan insiden ini?")) {
            try {
                keperawatanService.deleteInsiden(ci.getId());
                UiUtils.showSuccess(this, "Laporan insiden berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
