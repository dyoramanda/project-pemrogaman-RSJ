package com.rsj.ui.pendaftaran;

import com.rsj.model.Dokter;
import com.rsj.model.Pasien;
import com.rsj.model.Pendaftaran;
import com.rsj.model.PenanggungJawab;
import com.rsj.model.TempatTidur;
import com.rsj.service.MasterDataService;
import com.rsj.service.PelayananService;
import com.rsj.util.PrintHelper;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

public class RegistrasiKunjunganPanel extends JPanel {

    private final PelayananService pelayananService = new PelayananService();
    private final MasterDataService masterService = new MasterDataService();

    private final JTable tblDaftar;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private final JComboBox<String> cmbStatus;
    private final JComboBox<String> cmbJenis;
    private final JLabel lblCountInfo;
    private List<Pendaftaran> pendaftaranList;

    // Stat Summary Badges
    private final JLabel lblStatTotal;
    private final JLabel lblStatMenunggu;
    private final JLabel lblStatDiperiksa;
    private final JLabel lblStatRawatInap;

    public RegistrasiKunjunganPanel() {
        setLayout(new BorderLayout(0, 12));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));

        // ==========================================
        // 1. NORTH: KARTU HEADER & KARTU STATISTIK
        // ==========================================
        JPanel headerCard = UiUtils.createCardPanel();
        headerCard.setLayout(new GridBagLayout());
        headerCard.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        // Kiri: Judul dan Subjudul
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("Pendaftaran Kunjungan Pasien");
        lblTitle.setFont(UiUtils.FONT_TITLE);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblSub = new JLabel("Registrasi antrean rawat jalan (poliklinik) & rawat inap psikiatri");
        lblSub.setFont(UiUtils.FONT_SMALL);
        lblSub.setForeground(UiUtils.COLOR_TEXT_MUTED);

        textPanel.add(lblTitle);
        textPanel.add(Box.createRigidArea(new Dimension(0, 3)));
        textPanel.add(lblSub);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.35;
        gbc.insets = new Insets(0, 0, 0, 12);
        headerCard.add(textPanel, gbc);

        // Kanan: 4 Kartu Statistik Berukuran Sama (GridLayout 1x4)
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 8, 0));
        statsPanel.setOpaque(false);

        lblStatTotal = new JLabel("0", SwingConstants.CENTER);
        lblStatMenunggu = new JLabel("0", SwingConstants.CENTER);
        lblStatDiperiksa = new JLabel("0", SwingConstants.CENTER);
        lblStatRawatInap = new JLabel("0", SwingConstants.CENTER);

        statsPanel.add(createMiniStatCard("Total Kunjungan", lblStatTotal, UiUtils.COLOR_PRIMARY));
        statsPanel.add(createMiniStatCard("Menunggu", lblStatMenunggu, UiUtils.COLOR_WARNING));
        statsPanel.add(createMiniStatCard("Diperiksa", lblStatDiperiksa, UiUtils.COLOR_INFO));
        statsPanel.add(createMiniStatCard("Rawat Inap", lblStatRawatInap, new Color(0x7C, 0x3A, 0xED)));

        gbc.gridx = 1;
        gbc.weightx = 0.65;
        gbc.insets = new Insets(0, 0, 0, 0);
        headerCard.add(statsPanel, gbc);

        // ==========================================
        // 2. TOOLBAR CARD (PENCARIAN, FILTER, & AKSI)
        // ==========================================
        JPanel toolbarCard = UiUtils.createCardPanel();
        toolbarCard.setLayout(new BorderLayout(0, 8));
        toolbarCard.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        // Baris Atas: Form Pencarian & Filter
        JPanel rowFilter = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        rowFilter.setOpaque(false);

        txtSearch = new JTextField(15);
        txtSearch.putClientProperty("JTextField.placeholderText", "No Reg / No RM / Nama...");
        txtSearch.addActionListener(e -> reloadData());

        cmbStatus = new JComboBox<>(new String[]{"Semua Status", "MENUNGGU", "DIPERIKSA", "SELESAI", "DIBATALKAN"});
        cmbStatus.addActionListener(e -> reloadData());

        cmbJenis = new JComboBox<>(new String[]{"Semua Layanan", "RAWAT_JALAN", "RAWAT_INAP"});
        cmbJenis.addActionListener(e -> reloadData());

        JButton btnFilter = UiUtils.createSecondaryButton("Segarkan");
        btnFilter.addActionListener(e -> reloadData());

        rowFilter.add(new JLabel("Pencarian:"));
        rowFilter.add(txtSearch);
        rowFilter.add(new JLabel("Status:"));
        rowFilter.add(cmbStatus);
        rowFilter.add(new JLabel("Layanan:"));
        rowFilter.add(cmbJenis);
        rowFilter.add(btnFilter);

        // Baris Bawah: Info Data & Tombol-tombol Aksi
        JPanel rowActions = new JPanel(new BorderLayout(10, 0));
        rowActions.setOpaque(false);

        lblCountInfo = new JLabel("Menampilkan 0 kunjungan");
        lblCountInfo.setFont(UiUtils.FONT_SMALL);
        lblCountInfo.setForeground(UiUtils.COLOR_TEXT_MUTED);

        JPanel rightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        rightButtons.setOpaque(false);

        JButton btnBaru = UiUtils.createPrimaryButton("+ Pendaftaran Kunjungan Baru");
        btnBaru.setFont(UiUtils.FONT_BOLD);
        btnBaru.addActionListener(e -> showPendaftaranForm());

        JButton btnUbahStatus = UiUtils.createSecondaryButton("Ubah Status Antrean");
        btnUbahStatus.addActionListener(e -> showUbahStatusDialog());

        JButton btnBatal = UiUtils.createDangerButton("Batalkan Kunjungan");
        btnBatal.addActionListener(e -> batalkanPendaftaran());

        JButton btnCetak = UiUtils.createSecondaryButton("Cetak Bukti Antrean");
        btnCetak.addActionListener(e -> printTiket());

        rightButtons.add(btnBaru);
        rightButtons.add(btnUbahStatus);
        rightButtons.add(btnBatal);
        rightButtons.add(btnCetak);

        rowActions.add(lblCountInfo, BorderLayout.WEST);
        rowActions.add(rightButtons, BorderLayout.EAST);

        toolbarCard.add(rowFilter, BorderLayout.NORTH);
        toolbarCard.add(rowActions, BorderLayout.SOUTH);

        // Gabungkan Header & Toolbar dalam Top Section
        JPanel topSection = new JPanel();
        topSection.setLayout(new BoxLayout(topSection, BoxLayout.Y_AXIS));
        topSection.setOpaque(false);
        topSection.add(headerCard);
        topSection.add(Box.createRigidArea(new Dimension(0, 10)));
        topSection.add(toolbarCard);

        add(topSection, BorderLayout.NORTH);

        // ==========================================
        // 3. CENTER: TABEL DATA KUNJUNGAN
        // ==========================================
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout(0, 8));

        // Model JTable: Kolom 0 menyimpan ID tersembunyi
        model = new DefaultTableModel(new String[]{
                "ID_HIDDEN", "No. Registrasi", "Tanggal", "No. RM", "Nama Pasien", "Layanan", "Dokter Dituju", "Ruang & Bed", "Status", "Keluhan Utama"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        tblDaftar = new JTable(model);
        UiUtils.styleTable(tblDaftar);
        tblDaftar.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblDaftar.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // Sembunyikan kolom ID dari pandangan pengguna
        tblDaftar.removeColumn(tblDaftar.getColumnModel().getColumn(0));

        // Atur proporsi lebar kolom yang terlihat
        TableColumnModel cm = tblDaftar.getColumnModel();
        cm.getColumn(0).setPreferredWidth(125); // No. Registrasi
        cm.getColumn(1).setPreferredWidth(85);  // Tanggal
        cm.getColumn(2).setPreferredWidth(90);  // No. RM
        cm.getColumn(3).setPreferredWidth(140); // Nama Pasien
        cm.getColumn(4).setPreferredWidth(90);  // Layanan
        cm.getColumn(5).setPreferredWidth(130); // Dokter Dituju
        cm.getColumn(6).setPreferredWidth(115); // Ruang & Bed
        cm.getColumn(7).setPreferredWidth(95);  // Status
        cm.getColumn(8).setPreferredWidth(180); // Keluhan Utama

        // Custom Renderer Perataan Tengah
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        cm.getColumn(1).setCellRenderer(centerRenderer); // Tanggal
        cm.getColumn(2).setCellRenderer(centerRenderer); // No. RM

        // Custom Renderer Badge untuk Kolom Layanan
        cm.getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, val, isSel, hasFocus, r, c);
                lbl.setHorizontalAlignment(SwingConstants.CENTER);
                lbl.setFont(UiUtils.FONT_BOLD);
                String ly = val != null ? val.toString() : "";
                if (!isSel) {
                    if ("RAWAT_INAP".equalsIgnoreCase(ly)) {
                        lbl.setForeground(new Color(0x6D, 0x28, 0xD9)); // Purple
                    } else {
                        lbl.setForeground(new Color(0x0F, 0x76, 0x6E)); // Teal
                    }
                }
                return lbl;
            }
        });

        // Custom Renderer Badge Berwarna untuk Kolom Status
        cm.getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object val, boolean isSel, boolean hasFocus, int r, int c) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, val, isSel, hasFocus, r, c);
                lbl.setHorizontalAlignment(SwingConstants.CENTER);
                lbl.setFont(UiUtils.FONT_BOLD);
                String st = val != null ? val.toString() : "";
                if (!isSel) {
                    if ("MENUNGGU".equalsIgnoreCase(st)) {
                        lbl.setForeground(new Color(0xD9, 0x77, 0x06)); // Amber
                    } else if ("DIPERIKSA".equalsIgnoreCase(st)) {
                        lbl.setForeground(new Color(0x02, 0x84, 0xC7)); // Sky Blue
                    } else if ("SELESAI".equalsIgnoreCase(st)) {
                        lbl.setForeground(new Color(0x16, 0xA3, 0x4A)); // Green
                    } else if ("DIBATALKAN".equalsIgnoreCase(st)) {
                        lbl.setForeground(new Color(0xDC, 0x26, 0x26)); // Red
                    }
                }
                return lbl;
            }
        });

        // Double click shortcut: Cetak tiket antrean langsung
        tblDaftar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblDaftar.getSelectedRow() >= 0) {
                    printTiket();
                }
            }
        });

        JScrollPane scrollTable = new JScrollPane(tblDaftar);
        scrollTable.setBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER));
        cardTable.add(scrollTable, BorderLayout.CENTER);

        // Status Bar Bawah: Legend & Petunjuk
        JPanel footerBar = new JPanel(new BorderLayout(10, 0));
        footerBar.setOpaque(false);
        footerBar.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        JLabel lblLegend = new JLabel("Status:  🟡 MENUNGGU   🔵 DIPERIKSA   🟢 SELESAI   🔴 DIBATALKAN");
        lblLegend.setFont(UiUtils.FONT_SMALL);
        lblLegend.setForeground(UiUtils.COLOR_TEXT_MUTED);

        JLabel lblHint = new JLabel("Klik ganda baris untuk cetak bukti antrean");
        lblHint.setFont(UiUtils.FONT_SMALL);
        lblHint.setForeground(UiUtils.COLOR_TEXT_MUTED);

        footerBar.add(lblLegend, BorderLayout.WEST);
        footerBar.add(lblHint, BorderLayout.EAST);
        cardTable.add(footerBar, BorderLayout.SOUTH);

        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    private JPanel createMiniStatCard(String title, JLabel valueLabel, Color accentColor) {
        JPanel p = new JPanel(new BorderLayout(2, 2));
        p.setBackground(new Color(0xF8, 0xFA, 0xFC));
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 3, 0, 0, accentColor),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));

        JLabel lblT = new JLabel(title);
        lblT.setFont(UiUtils.FONT_SMALL);
        lblT.setForeground(UiUtils.COLOR_TEXT_MUTED);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        valueLabel.setForeground(UiUtils.COLOR_TEXT_MAIN);

        p.add(lblT, BorderLayout.NORTH);
        p.add(valueLabel, BorderLayout.CENTER);
        return p;
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        String st = (String) cmbStatus.getSelectedItem();
        if ("Semua Status".equalsIgnoreCase(st)) st = "SEMUA";
        String jn = (String) cmbJenis.getSelectedItem();
        if ("Semua Layanan".equalsIgnoreCase(jn)) jn = "SEMUA";

        pendaftaranList = pelayananService.searchPendaftaran(kw, st, jn);
        model.setRowCount(0);

        int totalToday = 0;
        int menunggu = 0;
        int diperiksa = 0;
        int rawatInap = 0;

        Date today = Date.valueOf(LocalDate.now());

        for (Pendaftaran p : pendaftaranList) {
            if (p.getTanggalDaftar() != null && p.getTanggalDaftar().toString().equals(today.toString())) {
                totalToday++;
            }
            if ("MENUNGGU".equalsIgnoreCase(p.getStatusPendaftaran())) menunggu++;
            else if ("DIPERIKSA".equalsIgnoreCase(p.getStatusPendaftaran())) diperiksa++;
            if ("RAWAT_INAP".equalsIgnoreCase(p.getJenisKunjungan())) rawatInap++;

            String bed = "-";
            if (p.getNamaRuangan() != null && p.getNomorBed() != null) {
                bed = p.getNamaRuangan() + " (" + p.getNomorBed() + ")";
            }

            model.addRow(new Object[]{
                    p.getId(), // Disimpan di model indeks 0 (tersembunyi)
                    p.getNoPendaftaran(),
                    UiUtils.formatDate(p.getTanggalDaftar()),
                    p.getNoRekamMedis(),
                    p.getNamaPasien(),
                    p.getJenisKunjungan(),
                    p.getNamaDokter() != null ? p.getNamaDokter() : "-",
                    bed,
                    p.getStatusPendaftaran(),
                    p.getKeluhanUtama() != null ? p.getKeluhanUtama() : "-"
            });
        }

        lblStatTotal.setText(totalToday + " Pasien");
        lblStatMenunggu.setText(menunggu + " Org");
        lblStatDiperiksa.setText(diperiksa + " Org");
        lblStatRawatInap.setText(rawatInap + " Inap");

        lblCountInfo.setText("Menampilkan " + pendaftaranList.size() + " data kunjungan");
    }

    private Pendaftaran getSelectedPendaftaran() {
        int r = tblDaftar.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih salah satu data pendaftaran pada tabel!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return pendaftaranList.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    /**
     * DIALOG MODAL LENGKAP PENDAFTARAN KUNJUNGAN:
     * Tab 1: Pasien Baru (Registrasi identitas + PJ + kunjungan dalam 1 alur)
     * Tab 2: Pasien Lama (Cari no RM/Nama + pilih layanan langsung)
     */
    private void showPendaftaranForm() {
        JDialog dlg = new JDialog((Frame) null, "Pendaftaran Kunjungan Pasien RS Jiwa", true);
        dlg.setSize(860, 680);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UiUtils.FONT_BOLD);

        tabbedPane.addTab("👤 Registrasi Pasien Baru", createPasienBaruForm(dlg));
        tabbedPane.addTab("🔍 Pendaftaran Pasien Lama", createPasienLamaForm(dlg));

        dlg.add(tabbedPane, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private JPanel createPasienBaruForm(JDialog dlg) {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UiUtils.COLOR_SURFACE);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UiUtils.COLOR_SURFACE);
        content.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));

        // Section 1: Identitas Pasien Baru
        JPanel cardPasien = UiUtils.createCardPanel();
        cardPasien.setLayout(new GridBagLayout());
        cardPasien.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER), " 1. Identitas Pasien Baru ", 0, 0, UiUtils.FONT_BOLD, UiUtils.COLOR_PRIMARY),
                BorderFactory.createEmptyBorder(8, 10, 10, 10)
        ));

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(4, 6, 4, 6);

        JTextField txtNik = new JTextField(16);
        JTextField txtNama = new JTextField(20);
        JComboBox<String> cmbGender = new JComboBox<>(new String[]{"Laki-laki (L)", "Perempuan (P)"});
        JTextField txtTglLahir = new JTextField(LocalDate.now().minusYears(30).toString());
        JTextField txtTelepon = new JTextField(14);
        JTextField txtAlamat = new JTextField(20);
        JComboBox<String> cmbNikah = new JComboBox<>(new String[]{"Belum Menikah", "Menikah", "Cerai Hidup", "Cerai Mati"});
        JComboBox<String> cmbAgama = new JComboBox<>(new String[]{"Islam", "Kristen", "Katolik", "Hindu", "Buddha", "Konghucu", "Lainnya"});
        JComboBox<String> cmbGolDarah = new JComboBox<>(new String[]{"A", "B", "AB", "O", "Tidak Tahu"});

        g.gridx = 0; g.gridy = 0; g.weightx = 0.15; cardPasien.add(new JLabel("NIK (16 Digit):*"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.35; cardPasien.add(txtNik, g);
        g.gridx = 2; g.gridy = 0; g.weightx = 0.15; cardPasien.add(new JLabel("Nama Lengkap:*"), g);
        g.gridx = 3; g.gridy = 0; g.weightx = 0.35; cardPasien.add(txtNama, g);

        g.gridx = 0; g.gridy = 1; cardPasien.add(new JLabel("Jenis Kelamin:*"), g);
        g.gridx = 1; g.gridy = 1; cardPasien.add(cmbGender, g);
        g.gridx = 2; g.gridy = 1; cardPasien.add(new JLabel("Tgl Lahir (YYYY-MM-DD):*"), g);
        g.gridx = 3; g.gridy = 1; cardPasien.add(txtTglLahir, g);

        g.gridx = 0; g.gridy = 2; cardPasien.add(new JLabel("No. Telepon/HP:"), g);
        g.gridx = 1; g.gridy = 2; cardPasien.add(txtTelepon, g);
        g.gridx = 2; g.gridy = 2; cardPasien.add(new JLabel("Alamat Lengkap:*"), g);
        g.gridx = 3; g.gridy = 2; cardPasien.add(txtAlamat, g);

        g.gridx = 0; g.gridy = 3; cardPasien.add(new JLabel("Status Nikah:"), g);
        g.gridx = 1; g.gridy = 3; cardPasien.add(cmbNikah, g);
        g.gridx = 2; g.gridy = 3; cardPasien.add(new JLabel("Agama & Gol. Darah:"), g);

        JPanel pAgamaDarah = new JPanel(new GridLayout(1, 2, 4, 0));
        pAgamaDarah.setOpaque(false);
        pAgamaDarah.add(cmbAgama);
        pAgamaDarah.add(cmbGolDarah);
        g.gridx = 3; g.gridy = 3; cardPasien.add(pAgamaDarah, g);

        // Section 2: Penanggung Jawab / Keluarga Pengantar
        JPanel cardPJ = UiUtils.createCardPanel();
        cardPJ.setLayout(new GridBagLayout());
        cardPJ.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER), " 2. Penanggung Jawab / Keluarga Pengantar ", 0, 0, UiUtils.FONT_BOLD, UiUtils.COLOR_PRIMARY),
                BorderFactory.createEmptyBorder(8, 10, 10, 10)
        ));

        JCheckBox chkPjBaru = new JCheckBox("Input Penanggung Jawab Baru (Bukan dari daftar yang ada)", true);
        chkPjBaru.setFont(UiUtils.FONT_SMALL);

        List<PenanggungJawab> listPj = pelayananService.getAllPenanggungJawab();
        JComboBox<PenanggungJawab> cmbPjExist = new JComboBox<>(listPj.toArray(new PenanggungJawab[0]));
        cmbPjExist.setEnabled(false);

        JTextField txtNamaPj = new JTextField(18);
        JComboBox<String> cmbHubPj = new JComboBox<>(new String[]{"Orang Tua", "Suami / Istri", "Anak", "Saudara Kandung", "Wali / Kerabat", "Dinas Sosial / Satpol PP"});
        JTextField txtTelpPj = new JTextField(14);
        JTextField txtAlamatPj = new JTextField(18);

        chkPjBaru.addActionListener(e -> {
            boolean isNew = chkPjBaru.isSelected();
            cmbPjExist.setEnabled(!isNew);
            txtNamaPj.setEnabled(isNew);
            cmbHubPj.setEnabled(isNew);
            txtTelpPj.setEnabled(isNew);
            txtAlamatPj.setEnabled(isNew);
        });

        g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(3, 6, 3, 6);

        g.gridx = 0; g.gridy = 0; g.gridwidth = 4; cardPJ.add(chkPjBaru, g);
        g.gridwidth = 1;

        g.gridx = 0; g.gridy = 1; g.weightx = 0.15; cardPJ.add(new JLabel("Pilih PJ Terdaftar:"), g);
        g.gridx = 1; g.gridy = 1; g.gridwidth = 3; g.weightx = 0.85; cardPJ.add(cmbPjExist, g);
        g.gridwidth = 1;

        g.gridx = 0; g.gridy = 2; g.weightx = 0.15; cardPJ.add(new JLabel("Nama Lengkap PJ:*"), g);
        g.gridx = 1; g.gridy = 2; g.weightx = 0.35; cardPJ.add(txtNamaPj, g);
        g.gridx = 2; g.gridy = 2; g.weightx = 0.15; cardPJ.add(new JLabel("Hubungan dgn Pasien:*"), g);
        g.gridx = 3; g.gridy = 2; g.weightx = 0.35; cardPJ.add(cmbHubPj, g);

        g.gridx = 0; g.gridy = 3; cardPJ.add(new JLabel("No. Telp / HP PJ:"), g);
        g.gridx = 1; g.gridy = 3; cardPJ.add(txtTelpPj, g);
        g.gridx = 2; g.gridy = 3; cardPJ.add(new JLabel("Alamat Lengkap PJ:"), g);
        g.gridx = 3; g.gridy = 3; cardPJ.add(txtAlamatPj, g);

        // Section 3: Data Pelayanan Kunjungan
        JPanel cardLayanan = UiUtils.createCardPanel();
        cardLayanan.setLayout(new GridBagLayout());
        cardLayanan.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER), " 3. Informasi Layanan & Dokter Psikiater ", 0, 0, UiUtils.FONT_BOLD, UiUtils.COLOR_PRIMARY),
                BorderFactory.createEmptyBorder(8, 10, 10, 10)
        ));

        JComboBox<String> cmbJenisKunjungan = new JComboBox<>(new String[]{"RAWAT_JALAN", "RAWAT_INAP"});
        List<Dokter> dokters = masterService.getAllDokter();
        JComboBox<Dokter> cmbDokter = new JComboBox<>(dokters.toArray(new Dokter[0]));

        List<TempatTidur> beds = masterService.getAvailableBeds();
        JComboBox<TempatTidur> cmbBed = new JComboBox<>(beds.toArray(new TempatTidur[0]));
        cmbBed.setEnabled(false);

        cmbJenisKunjungan.addActionListener(e -> {
            boolean isInap = "RAWAT_INAP".equals(cmbJenisKunjungan.getSelectedItem());
            cmbBed.setEnabled(isInap);
        });

        JTextField txtTglDaftar = new JTextField(LocalDate.now().toString());
        JTextArea txtKeluhan = new JTextArea(3, 20);
        txtKeluhan.setLineWrap(true);
        txtKeluhan.setWrapStyleWord(true);
        JScrollPane spKeluhan = new JScrollPane(txtKeluhan);

        g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(3, 6, 3, 6);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.15; cardLayanan.add(new JLabel("Jenis Layanan:*"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.35; cardLayanan.add(cmbJenisKunjungan, g);
        g.gridx = 2; g.gridy = 0; g.weightx = 0.15; cardLayanan.add(new JLabel("Dokter Dituju:*"), g);
        g.gridx = 3; g.gridy = 0; g.weightx = 0.35; cardLayanan.add(cmbDokter, g);

        g.gridx = 0; g.gridy = 1; cardLayanan.add(new JLabel("Pilih Bed Rawat Inap:"), g);
        g.gridx = 1; g.gridy = 1; cardLayanan.add(cmbBed, g);
        g.gridx = 2; g.gridy = 1; cardLayanan.add(new JLabel("Tanggal Daftar:*"), g);
        g.gridx = 3; g.gridy = 1; cardLayanan.add(txtTglDaftar, g);

        g.gridx = 0; g.gridy = 2; cardLayanan.add(new JLabel("Keluhan / Gejala Awal:*"), g);
        g.gridx = 1; g.gridy = 2; g.gridwidth = 3; cardLayanan.add(spKeluhan, g);

        content.add(cardPasien);
        content.add(Box.createRigidArea(new Dimension(0, 10)));
        content.add(cardPJ);
        content.add(Box.createRigidArea(new Dimension(0, 10)));
        content.add(cardLayanan);

        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        root.add(scroll, BorderLayout.CENTER);

        // Bottom Action Bar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        bottomBar.setBackground(UiUtils.COLOR_SURFACE);
        bottomBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UiUtils.COLOR_BORDER));

        JButton btnBatal = UiUtils.createSecondaryButton("Batal");
        btnBatal.addActionListener(e -> dlg.dispose());

        JButton btnSimpan = UiUtils.createPrimaryButton("💾 Simpan Pasien Baru & Daftarkan Kunjungan");
        btnSimpan.addActionListener(e -> {
            try {
                String nik = txtNik.getText().trim();
                String nama = txtNama.getText().trim();
                if (nik.isEmpty() || nama.isEmpty()) {
                    throw new Exception("NIK dan Nama Lengkap Pasien wajib diisi!");
                }
                if (txtAlamat.getText().trim().isEmpty()) {
                    throw new Exception("Alamat Pasien wajib diisi!");
                }

                // 1. Data Pasien
                Pasien p = new Pasien();
                p.setNik(nik);
                p.setNamaLengkap(nama);
                p.setJenisKelamin(cmbGender.getSelectedIndex() == 0 ? "L" : "P");
                p.setTanggalLahir(Date.valueOf(txtTglLahir.getText().trim()));
                p.setNoTelepon(txtTelepon.getText().trim());
                p.setAlamat(txtAlamat.getText().trim());
                p.setStatusPernikahan((String) cmbNikah.getSelectedItem());
                p.setAgama((String) cmbAgama.getSelectedItem());
                p.setGolonganDarah((String) cmbGolDarah.getSelectedItem());

                // 2. Data PJ
                PenanggungJawab pj = null;
                if (chkPjBaru.isSelected()) {
                    String namaPj = txtNamaPj.getText().trim();
                    if (namaPj.isEmpty()) throw new Exception("Nama Penanggung Jawab wajib diisi!");
                    pj = new PenanggungJawab();
                    pj.setNamaLengkap(namaPj);
                    pj.setHubungan((String) cmbHubPj.getSelectedItem());
                    pj.setNoTelepon(txtTelpPj.getText().trim());
                    pj.setAlamat(txtAlamatPj.getText().trim());
                } else {
                    pj = (PenanggungJawab) cmbPjExist.getSelectedItem();
                }

                // 3. Data Pendaftaran
                Pendaftaran pd = new Pendaftaran();
                pd.setJenisKunjungan((String) cmbJenisKunjungan.getSelectedItem());
                Dokter selD = (Dokter) cmbDokter.getSelectedItem();
                if (selD != null) pd.setIdDokter(selD.getId());

                if ("RAWAT_INAP".equals(pd.getJenisKunjungan())) {
                    TempatTidur selB = (TempatTidur) cmbBed.getSelectedItem();
                    if (selB == null) throw new Exception("Tempat tidur rawat inap wajib dipilih!");
                    pd.setIdTempatTidur(selB.getId());
                }

                pd.setTanggalDaftar(Date.valueOf(txtTglDaftar.getText().trim()));
                String keluhan = txtKeluhan.getText().trim();
                if (keluhan.isEmpty()) throw new Exception("Keluhan / alasan kunjungan wajib diisi!");
                pd.setKeluhanUtama(keluhan);

                pelayananService.daftarPasienBaruDanKunjungan(p, pj, pd);

                UiUtils.showSuccess(this,
                        "Pasien Baru Berhasil Terdaftar!\n" +
                        "No. Rekam Medis (RM) : " + p.getNoRekamMedis() + "\n" +
                        "No. Registrasi Kunjungan: " + pd.getNoPendaftaran() + "\n" +
                        "Layanan: " + pd.getJenisKunjungan() + " (Status: MENUNGGU)");

                dlg.dispose();
                reloadData();

                if (UiUtils.confirm(this, "Apakah Anda ingin mencetak bukti/tiket antrean kunjungan ini sekarang?")) {
                    tblDaftar.setRowSelectionInterval(0, 0);
                    printTiket();
                }

            } catch (Exception ex) {
                UiUtils.showError(dlg, "Validasi Gagal: " + ex.getMessage());
            }
        });

        bottomBar.add(btnBatal);
        bottomBar.add(btnSimpan);
        root.add(bottomBar, BorderLayout.SOUTH);

        return root;
    }

    private JPanel createPasienLamaForm(JDialog dlg) {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UiUtils.COLOR_SURFACE);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(UiUtils.COLOR_SURFACE);
        content.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));

        // Section 1: Cari Pasien Lama
        JPanel cardCari = UiUtils.createCardPanel();
        cardCari.setLayout(new BorderLayout(8, 8));
        cardCari.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER), " 1. Pencarian Data Pasien Lama ", 0, 0, UiUtils.FONT_BOLD, UiUtils.COLOR_PRIMARY),
                BorderFactory.createEmptyBorder(8, 10, 10, 10)
        ));

        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        searchRow.setOpaque(false);
        JTextField txtSearchPasien = new JTextField(22);
        txtSearchPasien.putClientProperty("JTextField.placeholderText", "Ketik No RM / NIK / Nama Pasien...");
        JButton btnCariPasien = UiUtils.createSecondaryButton("Cari Pasien");
        searchRow.add(new JLabel("Cari Pasien:"));
        searchRow.add(txtSearchPasien);
        searchRow.add(btnCariPasien);

        DefaultTableModel modelP = new DefaultTableModel(new String[]{"ID", "No. RM", "NIK", "Nama Lengkap", "L/P", "Status Rawat", "Penanggung Jawab"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tblP = new JTable(modelP);
        UiUtils.styleTable(tblP);
        tblP.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane spTblP = new JScrollPane(tblP);
        spTblP.setPreferredSize(new Dimension(800, 130));

        JPanel infoPreview = new JPanel(new GridLayout(2, 2, 8, 4));
        infoPreview.setBackground(new Color(0xF1, 0xF5, 0xF9));
        infoPreview.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));

        JLabel lblSelRM = new JLabel("No. RM: -");
        JLabel lblSelNama = new JLabel("Nama Pasien: -");
        JLabel lblSelNik = new JLabel("NIK: -");
        JLabel lblSelStatus = new JLabel("Status Rawat Terakhir: -");

        infoPreview.add(lblSelRM);
        infoPreview.add(lblSelNama);
        infoPreview.add(lblSelNik);
        infoPreview.add(lblSelStatus);

        final Pasien[] selectedPasienHolder = new Pasien[1];

        Runnable loadPasienTable = () -> {
            String kw = txtSearchPasien.getText().trim();
            List<Pasien> list = pelayananService.searchPasien(kw, "SEMUA");
            modelP.setRowCount(0);
            for (Pasien p : list) {
                modelP.addRow(new Object[]{
                        p.getId(), p.getNoRekamMedis(), p.getNik(), p.getNamaLengkap(), p.getJenisKelamin(), p.getStatusRawat(),
                        p.getNamaPenanggungJawab() != null ? p.getNamaPenanggungJawab() : "-"
                });
            }
        };

        btnCariPasien.addActionListener(e -> loadPasienTable.run());
        txtSearchPasien.addActionListener(e -> loadPasienTable.run());
        loadPasienTable.run();

        tblP.getSelectionModel().addListSelectionListener(e -> {
            int r = tblP.getSelectedRow();
            if (r >= 0) {
                int pid = (int) modelP.getValueAt(r, 0);
                Pasien p = pelayananService.getPasienById(pid);
                selectedPasienHolder[0] = p;
                if (p != null) {
                    lblSelRM.setText("No. RM: " + p.getNoRekamMedis());
                    lblSelNama.setText("Nama: " + p.getNamaLengkap() + " (" + p.getJenisKelamin() + ")");
                    lblSelNik.setText("NIK: " + p.getNik() + " | Telp: " + (p.getNoTelepon() != null ? p.getNoTelepon() : "-"));
                    lblSelStatus.setText("Status Terakhir: " + p.getStatusRawat());
                }
            }
        });

        cardCari.add(searchRow, BorderLayout.NORTH);
        cardCari.add(spTblP, BorderLayout.CENTER);
        cardCari.add(infoPreview, BorderLayout.SOUTH);

        // Section 2: Data Pelayanan Kunjungan
        JPanel cardLayanan = UiUtils.createCardPanel();
        cardLayanan.setLayout(new GridBagLayout());
        cardLayanan.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createLineBorder(UiUtils.COLOR_BORDER), " 2. Informasi Layanan & Dokter Psikiater ", 0, 0, UiUtils.FONT_BOLD, UiUtils.COLOR_PRIMARY),
                BorderFactory.createEmptyBorder(8, 10, 10, 10)
        ));

        JComboBox<String> cmbJenisKunjungan = new JComboBox<>(new String[]{"RAWAT_JALAN", "RAWAT_INAP"});
        List<Dokter> dokters = masterService.getAllDokter();
        JComboBox<Dokter> cmbDokter = new JComboBox<>(dokters.toArray(new Dokter[0]));

        List<TempatTidur> beds = masterService.getAvailableBeds();
        JComboBox<TempatTidur> cmbBed = new JComboBox<>(beds.toArray(new TempatTidur[0]));
        cmbBed.setEnabled(false);

        cmbJenisKunjungan.addActionListener(e -> {
            boolean isInap = "RAWAT_INAP".equals(cmbJenisKunjungan.getSelectedItem());
            cmbBed.setEnabled(isInap);
        });

        JTextField txtTglDaftar = new JTextField(LocalDate.now().toString());
        JTextArea txtKeluhan = new JTextArea(3, 20);
        txtKeluhan.setLineWrap(true);
        txtKeluhan.setWrapStyleWord(true);
        JScrollPane spKeluhan = new JScrollPane(txtKeluhan);

        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(3, 6, 3, 6);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.15; cardLayanan.add(new JLabel("Jenis Layanan:*"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.35; cardLayanan.add(cmbJenisKunjungan, g);
        g.gridx = 2; g.gridy = 0; g.weightx = 0.15; cardLayanan.add(new JLabel("Dokter Dituju:*"), g);
        g.gridx = 3; g.gridy = 0; g.weightx = 0.35; cardLayanan.add(cmbDokter, g);

        g.gridx = 0; g.gridy = 1; cardLayanan.add(new JLabel("Pilih Bed Rawat Inap:"), g);
        g.gridx = 1; g.gridy = 1; cardLayanan.add(cmbBed, g);
        g.gridx = 2; g.gridy = 1; cardLayanan.add(new JLabel("Tanggal Daftar:*"), g);
        g.gridx = 3; g.gridy = 1; cardLayanan.add(txtTglDaftar, g);

        g.gridx = 0; g.gridy = 2; cardLayanan.add(new JLabel("Keluhan / Gejala Awal:*"), g);
        g.gridx = 1; g.gridy = 2; g.gridwidth = 3; cardLayanan.add(spKeluhan, g);

        content.add(cardCari);
        content.add(Box.createRigidArea(new Dimension(0, 10)));
        content.add(cardLayanan);

        root.add(content, BorderLayout.CENTER);

        // Bottom Action Bar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        bottomBar.setBackground(UiUtils.COLOR_SURFACE);
        bottomBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UiUtils.COLOR_BORDER));

        JButton btnBatal = UiUtils.createSecondaryButton("Batal");
        btnBatal.addActionListener(e -> dlg.dispose());

        JButton btnSimpan = UiUtils.createPrimaryButton("💾 Simpan Pendaftaran Kunjungan");
        btnSimpan.addActionListener(e -> {
            try {
                Pasien selP = selectedPasienHolder[0];
                if (selP == null) throw new Exception("Silakan pilih salah satu pasien lama pada tabel di atas!");

                Pendaftaran pd = new Pendaftaran();
                pd.setIdPasien(selP.getId());
                pd.setJenisKunjungan((String) cmbJenisKunjungan.getSelectedItem());

                Dokter selD = (Dokter) cmbDokter.getSelectedItem();
                if (selD != null) pd.setIdDokter(selD.getId());

                if ("RAWAT_INAP".equals(pd.getJenisKunjungan())) {
                    TempatTidur selB = (TempatTidur) cmbBed.getSelectedItem();
                    if (selB == null) throw new Exception("Tempat tidur rawat inap wajib dipilih!");
                    pd.setIdTempatTidur(selB.getId());
                }

                pd.setTanggalDaftar(Date.valueOf(txtTglDaftar.getText().trim()));
                String keluhan = txtKeluhan.getText().trim();
                if (keluhan.isEmpty()) throw new Exception("Keluhan / alasan kunjungan wajib diisi!");
                pd.setKeluhanUtama(keluhan);

                pelayananService.daftarKunjungan(pd);

                UiUtils.showSuccess(this,
                        "Pendaftaran Berhasil Disimpan!\n" +
                        "No. Registrasi: " + pd.getNoPendaftaran() + "\n" +
                        "Pasien: " + selP.getNamaLengkap() + " (" + selP.getNoRekamMedis() + ")");

                dlg.dispose();
                reloadData();

                if (UiUtils.confirm(this, "Apakah Anda ingin mencetak bukti antrean sekarang?")) {
                    tblDaftar.setRowSelectionInterval(0, 0);
                    printTiket();
                }

            } catch (Exception ex) {
                UiUtils.showError(dlg, "Validasi Gagal: " + ex.getMessage());
            }
        });

        bottomBar.add(btnBatal);
        bottomBar.add(btnSimpan);
        root.add(bottomBar, BorderLayout.SOUTH);

        return root;
    }

    private void showUbahStatusDialog() {
        Pendaftaran p = getSelectedPendaftaran();
        if (p == null) return;

        String[] statuses = new String[]{"MENUNGGU", "DIPERIKSA", "SELESAI", "DIBATALKAN"};
        String current = p.getStatusPendaftaran();

        String selected = (String) JOptionPane.showInputDialog(
                this,
                "Pilih status baru untuk pendaftaran:\n" + p.getNoPendaftaran() + " - " + p.getNamaPasien(),
                "Ubah Status Antrean",
                JOptionPane.QUESTION_MESSAGE,
                null,
                statuses,
                current
        );

        if (selected != null && !selected.equals(current)) {
            try {
                pelayananService.updatePendaftaranStatus(p.getId(), selected);
                UiUtils.showSuccess(this, "Status pendaftaran berhasil diubah menjadi: " + selected);
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, "Gagal mengubah status: " + ex.getMessage());
            }
        }
    }

    private void batalkanPendaftaran() {
        Pendaftaran p = getSelectedPendaftaran();
        if (p == null) return;

        if ("DIBATALKAN".equalsIgnoreCase(p.getStatusPendaftaran())) {
            UiUtils.showError(this, "Pendaftaran ini sudah berstatus DIBATALKAN.");
            return;
        }

        if (UiUtils.confirm(this, "Apakah Anda yakin ingin membatalkan kunjungan " + p.getNoPendaftaran() + " (" + p.getNamaPasien() + ")?\nJika rawat inap, alokasi bed akan otomatis dibebaskan kembali.")) {
            try {
                pelayananService.batalkanPendaftaran(p.getId());
                UiUtils.showSuccess(this, "Pendaftaran berhasil dibatalkan!");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, "Gagal membatalkan: " + ex.getMessage());
            }
        }
    }

    private void printTiket() {
        Pendaftaran p = getSelectedPendaftaran();
        if (p == null) return;

        JPanel printCard = new JPanel();
        printCard.setLayout(new BoxLayout(printCard, BoxLayout.Y_AXIS));
        printCard.setBackground(Color.WHITE);
        printCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0x0F, 0x9D, 0x9A), 2),
                BorderFactory.createEmptyBorder(18, 22, 18, 22)
        ));
        printCard.setPreferredSize(new Dimension(360, 440));

        JLabel lKop = new JLabel("RUMAH SAKIT JIWA SEHAT JIWA");
        lKop.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lKop.setForeground(UiUtils.COLOR_PRIMARY);
        lKop.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lSubKop = new JLabel("Jl. Sehat Jiwa No. 1 • Telp (021) 7891011");
        lSubKop.setFont(UiUtils.FONT_SMALL);
        lSubKop.setForeground(Color.GRAY);
        lSubKop.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lDiv = new JLabel("========================================");
        lDiv.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lTiketTitle = new JLabel("BUKTI REGISTRASI & ANTREAN");
        lTiketTitle.setFont(UiUtils.FONT_HEADER);
        lTiketTitle.setForeground(UiUtils.COLOR_ACCENT);
        lTiketTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lNoReg = new JLabel(p.getNoPendaftaran());
        lNoReg.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lNoReg.setForeground(UiUtils.COLOR_PRIMARY);
        lNoReg.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lTanggal = new JLabel("Tgl: " + UiUtils.formatDate(p.getTanggalDaftar()) + " | Status: " + p.getStatusPendaftaran());
        lTanggal.setFont(UiUtils.FONT_SMALL);
        lTanggal.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel infoGrid = new JPanel(new GridLayout(5, 1, 3, 3));
        infoGrid.setOpaque(false);
        infoGrid.setBorder(BorderFactory.createEmptyBorder(10, 4, 10, 4));

        JLabel lRM = new JLabel("• No. Rekam Medis: " + p.getNoRekamMedis());
        lRM.setFont(UiUtils.FONT_BOLD);
        JLabel lNama = new JLabel("• Nama Pasien: " + p.getNamaPasien());
        lNama.setFont(UiUtils.FONT_BOLD);
        JLabel lLayanan = new JLabel("• Jenis Layanan: " + p.getJenisKunjungan());
        JLabel lDokter = new JLabel("• Dokter Psikiater: " + (p.getNamaDokter() != null ? p.getNamaDokter() : "Dokter Jaga Poli"));
        String tempat = p.getNomorBed() != null ? (p.getNamaRuangan() + " (Bed: " + p.getNomorBed() + ")") : "Poliklinik Psikiatri Rawat Jalan";
        JLabel lTempat = new JLabel("• Lokasi / Ruangan: " + tempat);

        infoGrid.add(lRM);
        infoGrid.add(lNama);
        infoGrid.add(lLayanan);
        infoGrid.add(lDokter);
        infoGrid.add(lTempat);

        JLabel lFooter = new JLabel("Harap simpan bukti antrean ini sampai dipanggil oleh petugas.");
        lFooter.setFont(UiUtils.FONT_SMALL);
        lFooter.setForeground(Color.GRAY);
        lFooter.setAlignmentX(Component.CENTER_ALIGNMENT);

        printCard.add(lKop);
        printCard.add(lSubKop);
        printCard.add(Box.createRigidArea(new Dimension(0, 4)));
        printCard.add(lDiv);
        printCard.add(Box.createRigidArea(new Dimension(0, 6)));
        printCard.add(lTiketTitle);
        printCard.add(lNoReg);
        printCard.add(lTanggal);
        printCard.add(Box.createRigidArea(new Dimension(0, 8)));
        printCard.add(infoGrid);
        printCard.add(Box.createRigidArea(new Dimension(0, 6)));
        printCard.add(lFooter);

        PrintHelper.printComponent(printCard);
    }
}
