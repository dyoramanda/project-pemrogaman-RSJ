package com.rsj.ui.common;

import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class WelcomePanel extends JPanel {

    private final Runnable onGoToLogin;

    public WelcomePanel(Runnable onGoToLogin) {
        this.onGoToLogin = onGoToLogin;
        setLayout(new BorderLayout());
        setBackground(UiUtils.COLOR_BG);

        JPanel mainContent = new JPanel();
        mainContent.setLayout(new BoxLayout(mainContent, BoxLayout.Y_AXIS));
        mainContent.setBackground(UiUtils.COLOR_BG);

        // 1. Top Navigation Bar
        mainContent.add(createNavbar());

        // 2. Hero Section
        mainContent.add(createHeroSection());

        // 3. Layanan Unggulan Cards Section
        mainContent.add(createServicesSection());

        // 4. Tim Dokter & Psikiater Section
        mainContent.add(createDoctorsSection());

        // 5. Prinsip Pelayanan Holistik
        mainContent.add(createValuesSection());

        // 6. Footer Section
        mainContent.add(createFooterSection());

        JScrollPane scrollPane = new JScrollPane(mainContent);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createNavbar() {
        JPanel nav = new JPanel(new BorderLayout());
        nav.setBackground(UiUtils.COLOR_PRIMARY);
        nav.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        nav.setPreferredSize(new Dimension(1000, 70));
        nav.setBorder(BorderFactory.createEmptyBorder(12, 36, 12, 36));

        // Brand
        JPanel brand = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        brand.setOpaque(false);
        JLabel lblLogo = new JLabel("RSJ SEHAT JIWA");
        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblLogo.setForeground(Color.WHITE);
        JLabel lblSub = new JLabel("• Pusat Layanan Psikiatri & Rehabilitasi Jiwa");
        lblSub.setFont(UiUtils.FONT_REGULAR);
        lblSub.setForeground(new Color(0x94, 0xA3, 0xB8));
        brand.add(lblLogo);
        brand.add(lblSub);

        // Right CTA
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        right.setOpaque(false);

        JButton btnLogin = UiUtils.createPrimaryButton("Masuk ke Sistem");
        btnLogin.setBackground(UiUtils.COLOR_ACCENT);
        btnLogin.addActionListener(e -> {
            if (onGoToLogin != null) onGoToLogin.run();
        });
        right.add(btnLogin);

        nav.add(brand, BorderLayout.WEST);
        nav.add(right, BorderLayout.EAST);
        return nav;
    }

    private JPanel createHeroSection() {
        JPanel hero = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0x0F, 0x9D, 0x9A, 25));
                g2.fillOval(getWidth() - 250, -50, 400, 400);
                g2.dispose();
            }
        };
        hero.setLayout(new BoxLayout(hero, BoxLayout.Y_AXIS));
        hero.setBackground(UiUtils.COLOR_SURFACE);
        hero.setMaximumSize(new Dimension(Integer.MAX_VALUE, 320));
        hero.setPreferredSize(new Dimension(1000, 320));
        hero.setBorder(BorderFactory.createEmptyBorder(45, 60, 45, 60));

        JLabel lblBadge = UiUtils.createBadge("PELAYANAN KESEHATAN MENTAL TERPADU & INKLUSIF", new Color(0xCC, 0xFB, 0xF1), UiUtils.COLOR_ACCENT);
        lblBadge.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblTitle = new JLabel("<html><span style='color:#0B4F6C;'>Pulih Bersama Kami,</span><br><span style='color:#0F9D9A;'>Dengan Empati dan Perawatan Medis Terbaik</span></html>");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 30));
        lblTitle.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblDesc = new JLabel("<html><p style='width: 600px; color:#64748B; font-size:13px; line-height: 1.5;'>"
                + "Rumah Sakit Jiwa Sehat Jiwa berdedikasi mendampingi setiap individu menuju pemulihan kesehatan mental "
                + "yang bermartabat, bebas stigma, dan berkelanjutan. Didukung oleh tim psikiater spesialis, dokter ahli, perawat jiwa, "
                + "serta sistem informasi terintegrasi untuk keluarga pasien.</p></html>");
        lblDesc.setAlignmentX(LEFT_ALIGNMENT);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        btnRow.setOpaque(false);
        btnRow.setAlignmentX(LEFT_ALIGNMENT);

        JButton btnPortal = UiUtils.createPrimaryButton("Masuk Portal Sistem (SIM-RSJ)");
        btnPortal.setPreferredSize(new Dimension(240, 42));
        btnPortal.addActionListener(e -> {
            if (onGoToLogin != null) onGoToLogin.run();
        });

        JButton btnHotline = UiUtils.createSecondaryButton("Layanan Krisis Jiwa 24 Jam: 119 ext. 8");
        btnHotline.setPreferredSize(new Dimension(260, 42));

        btnRow.add(btnPortal);
        btnRow.add(btnHotline);

        hero.add(lblBadge);
        hero.add(Box.createRigidArea(new Dimension(0, 14)));
        hero.add(lblTitle);
        hero.add(Box.createRigidArea(new Dimension(0, 12)));
        hero.add(lblDesc);
        hero.add(Box.createRigidArea(new Dimension(0, 20)));
        hero.add(btnRow);

        return hero;
    }

    private JPanel createServicesSection() {
        JPanel section = new JPanel(new BorderLayout(0, 16));
        section.setBackground(UiUtils.COLOR_BG);
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 260));
        section.setPreferredSize(new Dimension(1000, 260));
        section.setBorder(BorderFactory.createEmptyBorder(28, 60, 28, 60));

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel lblSecTitle = new JLabel("Layanan Unggulan Rumah Sakit");
        lblSecTitle.setFont(UiUtils.FONT_TITLE);
        lblSecTitle.setForeground(UiUtils.COLOR_PRIMARY);
        JLabel lblSecSub = new JLabel("Perawatan menyeluruh dari penanganan krisis akut hingga rehabilitasi kemandirian sosial");
        lblSecSub.setFont(UiUtils.FONT_REGULAR);
        lblSecSub.setForeground(UiUtils.COLOR_TEXT_MUTED);
        header.add(lblSecTitle, BorderLayout.NORTH);
        header.add(lblSecSub, BorderLayout.SOUTH);

        JPanel cards = new JPanel(new GridLayout(1, 4, 16, 16));
        cards.setOpaque(false);

        cards.add(createServiceCard("Rawat Inap Akut & Sub-Akut", "Pengawasan 24 jam dengan kamar khusus anti-cedera, perawat jiwa siaga, dan psikofarmaka terpantau.", "Ruang Sakura & Melati"));
        cards.add(createServiceCard("Poliklinik Psikiatri Rawat Jalan", "Konsultasi spesialis jiwa dewasa, psikoterapi, evaluasi gangguan mood, kecemasan, dan skizofrenia.", "Poli Psikiatri"));
        cards.add(createServiceCard("Rehabilitasi & Terapi Seni", "Pelatihan keterampilan harian, terapi musik, berkebun, dan pemulihan kemandirian pasien stabil.", "Ruang Teratai"));
        cards.add(createServiceCard("Pendampingan Keluarga (Family Care)", "Transparansi perkembangan pasien, booking bezuk online, dan edukasi stigma bagi pihak keluarga.", "Portal Keluarga"));

        section.add(header, BorderLayout.NORTH);
        section.add(cards, BorderLayout.CENTER);
        return section;
    }

    private JPanel createServiceCard(String title, String desc, String badge) {
        JPanel c = UiUtils.createCardPanel();
        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));

        JLabel lblBadge = UiUtils.createBadge(badge, new Color(0xF1, 0xF5, 0xF9), UiUtils.COLOR_PRIMARY);
        lblBadge.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblT = new JLabel("<html><b>" + title + "</b></html>");
        lblT.setFont(UiUtils.FONT_HEADER);
        lblT.setForeground(UiUtils.COLOR_PRIMARY);
        lblT.setAlignmentX(LEFT_ALIGNMENT);

        JLabel lblD = new JLabel("<html><p style='color:#64748B; font-size:11px;'>" + desc + "</p></html>");
        lblD.setAlignmentX(LEFT_ALIGNMENT);

        c.add(lblBadge);
        c.add(Box.createRigidArea(new Dimension(0, 8)));
        c.add(lblT);
        c.add(Box.createRigidArea(new Dimension(0, 6)));
        c.add(lblD);
        return c;
    }

    private JPanel createDoctorsSection() {
        JPanel section = new JPanel(new BorderLayout(0, 16));
        section.setBackground(UiUtils.COLOR_SURFACE);
        section.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));
        section.setPreferredSize(new Dimension(1000, 220));
        section.setBorder(BorderFactory.createEmptyBorder(24, 60, 24, 60));

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel lblT = new JLabel("Dokter Spesialis Kedokteran Jiwa (Sp.KJ)");
        lblT.setFont(UiUtils.FONT_TITLE);
        lblT.setForeground(UiUtils.COLOR_PRIMARY);
        header.add(lblT, BorderLayout.WEST);

        JPanel docCards = new JPanel(new GridLayout(1, 3, 16, 16));
        docCards.setOpaque(false);

        docCards.add(createDocCard("dr. Budi Santoso, Sp.KJ", "Psikiater Dewasa & Gangguan Afektif", "Praktik: Senin, Rabu, Jumat"));
        docCards.add(createDocCard("dr. Amanda Putri, Sp.KJ(K)", "Konsultan Psikiatri Anak & Remaja", "Praktik: Selasa & Kamis"));
        docCards.add(createDocCard("Ns. Ratna Dewi, S.Kep", "Kepala Ruang Rawat Inap & Keperawatan Jiwa", "Shift Pelayanan Siaga"));

        section.add(header, BorderLayout.NORTH);
        section.add(docCards, BorderLayout.CENTER);
        return section;
    }

    private JPanel createDocCard(String name, String spec, String sched) {
        JPanel p = UiUtils.createCardPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        JLabel lblN = new JLabel(name);
        lblN.setFont(UiUtils.FONT_HEADER);
        lblN.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblS = new JLabel(spec);
        lblS.setFont(UiUtils.FONT_SMALL);
        lblS.setForeground(UiUtils.COLOR_ACCENT);

        JLabel lblSc = new JLabel(sched);
        lblSc.setFont(UiUtils.FONT_SMALL);
        lblSc.setForeground(UiUtils.COLOR_TEXT_MUTED);

        p.add(lblN);
        p.add(Box.createRigidArea(new Dimension(0, 4)));
        p.add(lblS);
        p.add(Box.createRigidArea(new Dimension(0, 6)));
        p.add(lblSc);
        return p;
    }

    private JPanel createValuesSection() {
        JPanel sec = new JPanel(new GridLayout(1, 3, 20, 10));
        sec.setBackground(UiUtils.COLOR_BG);
        sec.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
        sec.setPreferredSize(new Dimension(1000, 120));
        sec.setBorder(BorderFactory.createEmptyBorder(18, 60, 18, 60));

        sec.add(createValueItem("Pendekatan Nirkekerasan (De-eskalasi)", "Mengutamakan komunikasi terapeutik ramah sebelum tindakan pembatasan fisik."));
        sec.add(createValueItem("Privasi & Kerahasiaan Medis", "Seluruh riwayat rekam medis psikiatri tersimpan aman dan terenkripsi."));
        sec.add(createValueItem("Keterlibatan Aktif Keluarga", "Keluarga mendapatkan update kondisi harian serta kemudahan jadwal kunjungan."));

        return sec;
    }

    private JPanel createValueItem(String title, String desc) {
        JPanel p = new JPanel(new BorderLayout(4, 4));
        p.setOpaque(false);
        JLabel lblT = new JLabel("✔  " + title);
        lblT.setFont(UiUtils.FONT_BOLD);
        lblT.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel lblD = new JLabel("<html><p style='color:#64748B; font-size:11px;'>" + desc + "</p></html>");
        p.add(lblT, BorderLayout.NORTH);
        p.add(lblD, BorderLayout.CENTER);
        return p;
    }

    private JPanel createFooterSection() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UiUtils.COLOR_PRIMARY_DARK);
        footer.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        footer.setPreferredSize(new Dimension(1000, 70));
        footer.setBorder(BorderFactory.createEmptyBorder(16, 60, 16, 60));

        JLabel lblCopy = new JLabel("© 2026 RS Jiwa Sehat Jiwa • SIMRS Jiwa & ODGJ Terpadu • Seluruh Hak Cipta Dilindungi.");
        lblCopy.setFont(UiUtils.FONT_SMALL);
        lblCopy.setForeground(new Color(0x94, 0xA3, 0xB8));

        JLabel lblAddr = new JLabel("Jl. Kesehatan Jiwa No. 108 • Call Center: (021) 7788-9900");
        lblAddr.setFont(UiUtils.FONT_SMALL);
        lblAddr.setForeground(new Color(0x94, 0xA3, 0xB8));

        footer.add(lblCopy, BorderLayout.WEST);
        footer.add(lblAddr, BorderLayout.EAST);
        return footer;
    }
}
