package com.rsj.ui.pendaftaran;

import com.rsj.model.PenanggungJawab;
import com.rsj.model.User;
import com.rsj.service.MasterDataService;
import com.rsj.service.PelayananService;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PenanggungJawabPanel extends JPanel {

    private final PelayananService pelayananService = new PelayananService();
    private final MasterDataService masterService = new MasterDataService();

    private final JTable tblPJ;
    private final DefaultTableModel model;
    private final JTextField txtSearch;
    private List<PenanggungJawab> pjList;

    public PenanggungJawabPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        // Top Filter & Actions
        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        txtSearch = new JTextField(15);
        txtSearch.putClientProperty("JTextField.placeholderText", "Cari nama / no identitas...");
        txtSearch.addActionListener(e -> reloadData());
        JButton btnSearch = UiUtils.createSecondaryButton("Cari");
        btnSearch.addActionListener(e -> reloadData());
        left.add(new JLabel("Pencarian:"));
        left.add(txtSearch);
        left.add(btnSearch);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnAdd = UiUtils.createPrimaryButton("+ Tambah Penanggung Jawab");
        btnAdd.addActionListener(e -> showPJForm(null));

        JButton btnEdit = UiUtils.createSecondaryButton("Ubah Data");
        btnEdit.addActionListener(e -> {
            PenanggungJawab pj = getSelectedPJ();
            if (pj != null) showPJForm(pj);
        });

        JButton btnDel = UiUtils.createDangerButton("Hapus");
        btnDel.addActionListener(e -> deletePJ());

        right.add(btnAdd);
        right.add(btnEdit);
        right.add(btnDel);

        topBar.add(left, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        // Table Card
        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "Nama Penanggung Jawab", "Hubungan", "No. Identitas (KTP)", "No. Telepon / WA", "Alamat", "Pekerjaan", "Akun User Keluarga"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblPJ = new JTable(model);
        UiUtils.styleTable(tblPJ);
        cardTable.add(new JScrollPane(tblPJ), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        String kw = txtSearch.getText().trim();
        pjList = pelayananService.searchPenanggungJawab(kw);

        model.setRowCount(0);
        for (PenanggungJawab pj : pjList) {
            model.addRow(new Object[]{
                    pj.getId(),
                    pj.getNamaLengkap(),
                    pj.getHubungan(),
                    pj.getNoIdentitas(),
                    pj.getNoTelepon(),
                    pj.getAlamat() != null ? pj.getAlamat() : "-",
                    pj.getPekerjaan() != null ? pj.getPekerjaan() : "-",
                    pj.getUsernameKeluarga() != null ? pj.getUsernameKeluarga() : "(Belum terhubung akun)"
            });
        }
    }

    private PenanggungJawab getSelectedPJ() {
        int r = tblPJ.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris penanggung jawab terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return pjList.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    private void showPJForm(PenanggungJawab pj) {
        boolean isEdit = pj != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Ubah Penanggung Jawab" : "Tambah Penanggung Jawab", true);
        dlg.setSize(480, 430);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        JTextField txtNama = new JTextField(isEdit ? pj.getNamaLengkap() : "");
        JComboBox<String> cmbHub = new JComboBox<>(new String[]{"Orang Tua", "Ayah Kandung", "Ibu Kandung", "Suami", "Istri", "Anak Kandung", "Saudara Kandung", "Wali Hukum"});
        if (isEdit) cmbHub.setSelectedItem(pj.getHubungan());

        JTextField txtIden = new JTextField(isEdit ? pj.getNoIdentitas() : "");
        JTextField txtTelp = new JTextField(isEdit ? pj.getNoTelepon() : "");
        JTextField txtAlamat = new JTextField(isEdit && pj.getAlamat() != null ? pj.getAlamat() : "");
        JTextField txtKerja = new JTextField(isEdit && pj.getPekerjaan() != null ? pj.getPekerjaan() : "");

        // Link User Account selector
        List<User> users = masterService.searchUsers("", "KELUARGA_PASIEN");
        JComboBox<Object> cmbUser = new JComboBox<>();
        cmbUser.addItem("-- Tidak terhubung ke akun user --");
        User matchedUser = null;
        for (User u : users) {
            cmbUser.addItem(u);
            if (isEdit && pj.getIdUser() != null && u.getId() == pj.getIdUser()) {
                matchedUser = u;
            }
        }
        if (matchedUser != null) cmbUser.setSelectedItem(matchedUser);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.35; pan.add(new JLabel("Nama Lengkap:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.65; pan.add(txtNama, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Hubungan Keluarga:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(cmbHub, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("No. KTP / Identitas:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(txtIden, g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("No. Telepon:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(txtTelp, g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Alamat Lengkap:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(txtAlamat, g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Pekerjaan:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(txtKerja, g);

        g.gridx = 0; g.gridy = 6; pan.add(new JLabel("Hubungkan Akun:"), g);
        g.gridx = 1; g.gridy = 6; pan.add(cmbUser, g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Penanggung Jawab");
        btnSave.addActionListener(e -> {
            try {
                PenanggungJawab npj = isEdit ? pj : new PenanggungJawab();
                npj.setNamaLengkap(txtNama.getText().trim());
                npj.setHubungan((String) cmbHub.getSelectedItem());
                npj.setNoIdentitas(txtIden.getText().trim());
                npj.setNoTelepon(txtTelp.getText().trim());
                npj.setAlamat(txtAlamat.getText().trim());
                npj.setPekerjaan(txtKerja.getText().trim());

                Object selObj = cmbUser.getSelectedItem();
                if (selObj instanceof User) {
                    npj.setIdUser(((User) selObj).getId());
                } else {
                    npj.setIdUser(null);
                }

                pelayananService.savePenanggungJawab(npj);
                UiUtils.showSuccess(this, "Data penanggung jawab berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 7; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(pan, BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void deletePJ() {
        PenanggungJawab pj = getSelectedPJ();
        if (pj == null) return;
        if (UiUtils.confirm(this, "Hapus data penanggung jawab " + pj.getNamaLengkap() + "?")) {
            try {
                pelayananService.deletePenanggungJawab(pj.getId());
                UiUtils.showSuccess(this, "Data penanggung jawab berhasil dihapus.");
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(this, ex.getMessage());
            }
        }
    }
}
