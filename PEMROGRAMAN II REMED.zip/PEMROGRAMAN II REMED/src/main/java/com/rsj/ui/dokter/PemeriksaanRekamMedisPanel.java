package com.rsj.ui.dokter;

import com.rsj.dao.DokterDao;
import com.rsj.model.Dokter;
import com.rsj.model.Pendaftaran;
import com.rsj.model.RekamMedis;
import com.rsj.service.PelayananService;
import com.rsj.util.PrintHelper;
import com.rsj.util.SessionManager;
import com.rsj.util.UiUtils;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class PemeriksaanRekamMedisPanel extends JPanel {

    private final PelayananService pelayananService = new PelayananService();
    private final DokterDao dokterDao = new DokterDao();

    private final JTable tblRM;
    private final DefaultTableModel model;
    private List<RekamMedis> rmList;

    public PemeriksaanRekamMedisPanel() {
        setLayout(new BorderLayout(0, 14));
        setBackground(UiUtils.COLOR_BG);
        setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JPanel topBar = UiUtils.createCardPanel();
        topBar.setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Pemeriksaan Klinis & Rekam Medis Psikiatri");
        lblTitle.setFont(UiUtils.FONT_HEADER);
        lblTitle.setForeground(UiUtils.COLOR_PRIMARY);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);

        JButton btnBaru = UiUtils.createPrimaryButton("+ Input Hasil Pemeriksaan");
        btnBaru.addActionListener(e -> showPemeriksaanForm(null));

        JButton btnDetail = UiUtils.createSecondaryButton("Lihat / Edit");
        btnDetail.addActionListener(e -> {
            RekamMedis rm = getSelectedRM();
            if (rm != null) showPemeriksaanForm(rm);
        });

        JButton btnCetak = UiUtils.createSecondaryButton("Cetak Lembar Rekam Medis");
        btnCetak.addActionListener(e -> printRekamMedis());

        right.add(btnBaru);
        right.add(btnDetail);
        right.add(btnCetak);

        topBar.add(lblTitle, BorderLayout.WEST);
        topBar.add(right, BorderLayout.EAST);

        JPanel cardTable = UiUtils.createCardPanel();
        cardTable.setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{
                "ID", "No. RM Visit", "Tanggal Periksa", "No. RM Pasien", "Nama Pasien", "Dokter Pemeriksa", "Anamnesis Ringkas", "Status Mental"
        }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblRM = new JTable(model);
        UiUtils.styleTable(tblRM);
        cardTable.add(new JScrollPane(tblRM), BorderLayout.CENTER);

        add(topBar, BorderLayout.NORTH);
        add(cardTable, BorderLayout.CENTER);

        reloadData();
    }

    public void reloadData() {
        rmList = pelayananService.getAllRekamMedis();
        model.setRowCount(0);
        for (RekamMedis r : rmList) {
            model.addRow(new Object[]{
                    r.getId(),
                    r.getNoRekamMedisVisit(),
                    UiUtils.formatDate(r.getTanggalPeriksa()),
                    r.getNoRekamMedisPasien(),
                    r.getNamaPasien(),
                    r.getNamaDokter(),
                    r.getAnamnesis() != null && r.getAnamnesis().length() > 50 ? r.getAnamnesis().substring(0, 50) + "..." : r.getAnamnesis(),
                    r.getStatusMental() != null && r.getStatusMental().length() > 50 ? r.getStatusMental().substring(0, 50) + "..." : r.getStatusMental()
            });
        }
    }

    private RekamMedis getSelectedRM() {
        int r = tblRM.getSelectedRow();
        if (r < 0) {
            UiUtils.showError(this, "Silakan pilih baris rekam medis terlebih dahulu!");
            return null;
        }
        int id = (int) model.getValueAt(r, 0);
        return rmList.stream().filter(rm -> rm.getId() == id).findFirst().orElse(null);
    }

    private void showPemeriksaanForm(RekamMedis rm) {
        boolean isEdit = rm != null;
        JDialog dlg = new JDialog((Frame) null, isEdit ? "Detail Rekam Medis" : "Formulir Pemeriksaan Psikiatri Baru", true);
        dlg.setSize(620, 640);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());

        JPanel pan = new JPanel(new GridBagLayout());
        pan.setBackground(UiUtils.COLOR_SURFACE);
        pan.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 5, 5, 5);

        List<Pendaftaran> pendaftaranList = pelayananService.getAllPendaftaran();
        JComboBox<Pendaftaran> cmbPendaftaran = new JComboBox<>(pendaftaranList.toArray(new Pendaftaran[0]));
        if (isEdit) {
            for (Pendaftaran p : pendaftaranList) {
                if (p.getId() == rm.getIdPendaftaran()) {
                    cmbPendaftaran.setSelectedItem(p);
                    break;
                }
            }
            cmbPendaftaran.setEnabled(false);
        }

        JTextField txtTgl = new JTextField(isEdit && rm.getTanggalPeriksa() != null ? rm.getTanggalPeriksa().toString() : LocalDate.now().toString());

        JTextArea txtAnamnesis = new JTextArea(isEdit && rm.getAnamnesis() != null ? rm.getAnamnesis() : "Keluhan utama: \nRiwayat gangguan sekarang: \nRiwayat gangguan dahulu: ", 3, 20);
        txtAnamnesis.setLineWrap(true);
        txtAnamnesis.setWrapStyleWord(true);

        JTextArea txtFisik = new JTextArea(isEdit && rm.getPemeriksaanFisik() != null ? rm.getPemeriksaanFisik() : "TD: 120/80 mmHg, Nadi: 80 bpm, Suhu: 36.5 C, RR: 18 x/m. Status fisik dalam batas normal.", 2, 20);
        txtFisik.setLineWrap(true);
        txtFisik.setWrapStyleWord(true);

        JTextArea txtMental = new JTextArea(isEdit && rm.getStatusMental() != null ? rm.getStatusMental() : "Kontak mata: Baik. Afek/Mood: Eutimik/Stabil. Persepsi: Tidak ada halusinasi aktif. Arus pikir: Koheren. Tilikan: Derajat 4.", 3, 20);
        txtMental.setLineWrap(true);
        txtMental.setWrapStyleWord(true);

        JTextArea txtCatatan = new JTextArea(isEdit && rm.getCatatanPsikiatri() != null ? rm.getCatatanPsikiatri() : "Rencana terapi: Lanjutkan medikasi antipsikotik dosis maintenance dan konseling suportif.", 2, 20);
        txtCatatan.setLineWrap(true);
        txtCatatan.setWrapStyleWord(true);

        g.gridx = 0; g.gridy = 0; g.weightx = 0.3; pan.add(new JLabel("Pendaftaran Pasien:"), g);
        g.gridx = 1; g.gridy = 0; g.weightx = 0.7; pan.add(cmbPendaftaran, g);

        g.gridx = 0; g.gridy = 1; pan.add(new JLabel("Tanggal Pemeriksaan:"), g);
        g.gridx = 1; g.gridy = 1; pan.add(txtTgl, g);

        g.gridx = 0; g.gridy = 2; pan.add(new JLabel("Anamnesis Psikiatri:"), g);
        g.gridx = 1; g.gridy = 2; pan.add(new JScrollPane(txtAnamnesis), g);

        g.gridx = 0; g.gridy = 3; pan.add(new JLabel("Pemeriksaan Fisik:"), g);
        g.gridx = 1; g.gridy = 3; pan.add(new JScrollPane(txtFisik), g);

        g.gridx = 0; g.gridy = 4; pan.add(new JLabel("Status Mental Jiwa:"), g);
        g.gridx = 1; g.gridy = 4; pan.add(new JScrollPane(txtMental), g);

        g.gridx = 0; g.gridy = 5; pan.add(new JLabel("Catatan & Terapi:"), g);
        g.gridx = 1; g.gridy = 5; pan.add(new JScrollPane(txtCatatan), g);

        JButton btnSave = UiUtils.createPrimaryButton("Simpan Rekam Medis");
        btnSave.addActionListener(e -> {
            try {
                Pendaftaran selPd = (Pendaftaran) cmbPendaftaran.getSelectedItem();
                if (selPd == null) throw new Exception("Pendaftaran pasien wajib dipilih!");

                int dokterId = 1;
                if (SessionManager.getCurrentUser() != null) {
                    Dokter d = dokterDao.findByUserId(SessionManager.getCurrentUser().getId());
                    if (d != null) dokterId = d.getId();
                    else if (selPd.getIdDokter() != null) dokterId = selPd.getIdDokter();
                }

                RekamMedis nrm = isEdit ? rm : new RekamMedis();
                nrm.setIdPendaftaran(selPd.getId());
                nrm.setIdPasien(selPd.getIdPasien());
                nrm.setIdDokter(dokterId);
                nrm.setTanggalPeriksa(Date.valueOf(txtTgl.getText().trim()));
                nrm.setAnamnesis(txtAnamnesis.getText().trim());
                nrm.setPemeriksaanFisik(txtFisik.getText().trim());
                nrm.setStatusMental(txtMental.getText().trim());
                nrm.setCatatanPsikiatri(txtCatatan.getText().trim());

                pelayananService.simpanPemeriksaan(nrm, null);
                UiUtils.showSuccess(this, "Rekam medis berhasil disimpan!");
                dlg.dispose();
                reloadData();
            } catch (Exception ex) {
                UiUtils.showError(dlg, "Error: " + ex.getMessage());
            }
        });

        g.gridx = 0; g.gridy = 6; g.gridwidth = 2;
        g.insets = new Insets(14, 5, 5, 5);
        pan.add(btnSave, g);

        dlg.add(new JScrollPane(pan), BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void printRekamMedis() {
        RekamMedis rm = getSelectedRM();
        if (rm == null) return;

        JPanel printCard = new JPanel(new GridLayout(10, 1, 6, 6));
        printCard.setBackground(java.awt.Color.WHITE);
        printCard.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        JLabel l1 = new JLabel("RS JIWA SEHAT JIWA - LEMBAR REKAM MEDIS RESMI");
        l1.setFont(UiUtils.FONT_TITLE);
        l1.setForeground(UiUtils.COLOR_PRIMARY);

        JLabel l2 = new JLabel("No. Visit: " + rm.getNoRekamMedisVisit() + " • Tanggal: " + UiUtils.formatDate(rm.getTanggalPeriksa()));
        l2.setFont(UiUtils.FONT_HEADER);
        l2.setForeground(UiUtils.COLOR_ACCENT);

        JLabel l3 = new JLabel("Nama Pasien: " + rm.getNamaPasien() + " (RM: " + rm.getNoRekamMedisPasien() + ")");
        JLabel l4 = new JLabel("Dokter Pemeriksa: " + rm.getNamaDokter());
        JLabel l5 = new JLabel("<html><b>Anamnesis:</b> " + rm.getAnamnesis() + "</html>");
        JLabel l6 = new JLabel("<html><b>Pemeriksaan Fisik:</b> " + rm.getPemeriksaanFisik() + "</html>");
        JLabel l7 = new JLabel("<html><b>Status Mental:</b> " + rm.getStatusMental() + "</html>");
        JLabel l8 = new JLabel("<html><b>Catatan Psikiatri:</b> " + rm.getCatatanPsikiatri() + "</html>");
        JLabel l9 = new JLabel("Dokumen medis ini bersifat rahasia dan dilindungi oleh undang-undang.");
        l9.setFont(UiUtils.FONT_SMALL);
        l9.setForeground(UiUtils.COLOR_TEXT_MUTED);

        printCard.add(l1);
        printCard.add(l2);
        printCard.add(l3);
        printCard.add(l4);
        printCard.add(l5);
        printCard.add(l6);
        printCard.add(l7);
        printCard.add(l8);
        printCard.add(l9);

        PrintHelper.printComponent(printCard);
    }
}
