package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.PenanggungJawab;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PenanggungJawabDao {

    public List<PenanggungJawab> findAll() {
        List<PenanggungJawab> list = new ArrayList<>();
        String sql = "SELECT pj.*, u.username as username_keluarga FROM penanggung_jawab pj LEFT JOIN users u ON pj.id_user = u.id ORDER BY pj.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[PenanggungJawabDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<PenanggungJawab> search(String keyword) {
        List<PenanggungJawab> list = new ArrayList<>();
        String sql = "SELECT pj.*, u.username as username_keluarga FROM penanggung_jawab pj LEFT JOIN users u ON pj.id_user = u.id "
                   + "WHERE pj.nama_lengkap LIKE ? OR pj.no_identitas LIKE ? OR pj.no_telepon LIKE ? ORDER BY pj.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[PenanggungJawabDao] search error: " + e.getMessage());
        }
        return list;
    }

    public PenanggungJawab findById(int id) {
        String sql = "SELECT pj.*, u.username as username_keluarga FROM penanggung_jawab pj LEFT JOIN users u ON pj.id_user = u.id WHERE pj.id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[PenanggungJawabDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public PenanggungJawab findByUserId(int userId) {
        String sql = "SELECT pj.*, u.username as username_keluarga FROM penanggung_jawab pj LEFT JOIN users u ON pj.id_user = u.id WHERE pj.id_user = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[PenanggungJawabDao] findByUserId error: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(PenanggungJawab pj) throws SQLException {
        String sql = "INSERT INTO penanggung_jawab (nama_lengkap, hubungan, no_identitas, no_telepon, alamat, pekerjaan, id_user) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, pj.getNamaLengkap());
            ps.setString(2, pj.getHubungan());
            ps.setString(3, pj.getNoIdentitas());
            ps.setString(4, pj.getNoTelepon());
            ps.setString(5, pj.getAlamat());
            ps.setString(6, pj.getPekerjaan());
            if (pj.getIdUser() != null) ps.setInt(7, pj.getIdUser()); else ps.setNull(7, java.sql.Types.INTEGER);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) pj.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(PenanggungJawab pj) throws SQLException {
        String sql = "UPDATE penanggung_jawab SET nama_lengkap = ?, hubungan = ?, no_identitas = ?, no_telepon = ?, alamat = ?, pekerjaan = ?, id_user = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, pj.getNamaLengkap());
            ps.setString(2, pj.getHubungan());
            ps.setString(3, pj.getNoIdentitas());
            ps.setString(4, pj.getNoTelepon());
            ps.setString(5, pj.getAlamat());
            ps.setString(6, pj.getPekerjaan());
            if (pj.getIdUser() != null) ps.setInt(7, pj.getIdUser()); else ps.setNull(7, java.sql.Types.INTEGER);
            ps.setInt(8, pj.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM penanggung_jawab WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private PenanggungJawab mapResultSet(ResultSet rs) throws SQLException {
        PenanggungJawab pj = new PenanggungJawab();
        pj.setId(rs.getInt("id"));
        pj.setNamaLengkap(rs.getString("nama_lengkap"));
        pj.setHubungan(rs.getString("hubungan"));
        pj.setNoIdentitas(rs.getString("no_identitas"));
        pj.setNoTelepon(rs.getString("no_telepon"));
        pj.setAlamat(rs.getString("alamat"));
        pj.setPekerjaan(rs.getString("pekerjaan"));
        pj.setIdUser((Integer) rs.getObject("id_user"));
        pj.setCreatedAt(rs.getTimestamp("created_at"));
        pj.setUsernameKeluarga(rs.getString("username_keluarga"));
        return pj;
    }
}
