package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Ruangan;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RuanganDao {

    public List<Ruangan> findAll() {
        List<Ruangan> list = new ArrayList<>();
        String sql = "SELECT r.*, "
                   + "(SELECT COUNT(*) FROM tempat_tidur b WHERE b.id_ruangan = r.id AND b.status = 'TERISI') as terisi, "
                   + "(SELECT COUNT(*) FROM tempat_tidur b WHERE b.id_ruangan = r.id AND b.status = 'TERSEDIA') as kosong "
                   + "FROM ruangan r ORDER BY r.id ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[RuanganDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public Ruangan findById(int id) {
        String sql = "SELECT r.*, "
                   + "(SELECT COUNT(*) FROM tempat_tidur b WHERE b.id_ruangan = r.id AND b.status = 'TERISI') as terisi, "
                   + "(SELECT COUNT(*) FROM tempat_tidur b WHERE b.id_ruangan = r.id AND b.status = 'TERSEDIA') as kosong "
                   + "FROM ruangan r WHERE r.id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[RuanganDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(Ruangan r) throws SQLException {
        String sql = "INSERT INTO ruangan (kode_ruangan, nama_ruangan, kategori, kapasitas, tarif_per_hari, fasilitas, status_aktif) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, r.getKodeRuangan());
            ps.setString(2, r.getNamaRuangan());
            ps.setString(3, r.getKategori());
            ps.setInt(4, r.getKapasitas());
            ps.setBigDecimal(5, r.getTarifPerHari());
            ps.setString(6, r.getFasilitas());
            ps.setBoolean(7, r.isStatusAktif());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) r.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(Ruangan r) throws SQLException {
        String sql = "UPDATE ruangan SET kode_ruangan = ?, nama_ruangan = ?, kategori = ?, kapasitas = ?, tarif_per_hari = ?, fasilitas = ?, status_aktif = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, r.getKodeRuangan());
            ps.setString(2, r.getNamaRuangan());
            ps.setString(3, r.getKategori());
            ps.setInt(4, r.getKapasitas());
            ps.setBigDecimal(5, r.getTarifPerHari());
            ps.setString(6, r.getFasilitas());
            ps.setBoolean(7, r.isStatusAktif());
            ps.setInt(8, r.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM ruangan WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Ruangan mapResultSet(ResultSet rs) throws SQLException {
        Ruangan r = new Ruangan();
        r.setId(rs.getInt("id"));
        r.setKodeRuangan(rs.getString("kode_ruangan"));
        r.setNamaRuangan(rs.getString("nama_ruangan"));
        r.setKategori(rs.getString("kategori"));
        r.setKapasitas(rs.getInt("kapasitas"));
        r.setTarifPerHari(rs.getBigDecimal("tarif_per_hari"));
        r.setFasilitas(rs.getString("fasilitas"));
        r.setStatusAktif(rs.getBoolean("status_aktif"));
        r.setJumlahBedTerisi(rs.getInt("terisi"));
        r.setJumlahBedKosong(rs.getInt("kosong"));
        return r;
    }
}
