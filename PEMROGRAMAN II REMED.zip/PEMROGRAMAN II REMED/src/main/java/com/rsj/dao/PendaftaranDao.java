package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Pendaftaran;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PendaftaranDao {

    public List<Pendaftaran> findAll() {
        List<Pendaftaran> list = new ArrayList<>();
        String sql = "SELECT pd.*, p.no_rekam_medis, p.nama_lengkap as nama_pasien, "
                   + "d.nama_lengkap as nama_dokter, b.nomor_bed, r.nama_ruangan "
                   + "FROM pendaftaran pd "
                   + "JOIN pasien p ON pd.id_pasien = p.id "
                   + "LEFT JOIN dokter d ON pd.id_dokter = d.id "
                   + "LEFT JOIN tempat_tidur b ON pd.id_tempat_tidur = b.id "
                   + "LEFT JOIN ruangan r ON b.id_ruangan = r.id "
                   + "ORDER BY pd.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[PendaftaranDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Pendaftaran> search(String keyword, String statusFilter, String jenisFilter) {
        List<Pendaftaran> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT pd.*, p.no_rekam_medis, p.nama_lengkap as nama_pasien, "
              + "d.nama_lengkap as nama_dokter, b.nomor_bed, r.nama_ruangan "
              + "FROM pendaftaran pd "
              + "JOIN pasien p ON pd.id_pasien = p.id "
              + "LEFT JOIN dokter d ON pd.id_dokter = d.id "
              + "LEFT JOIN tempat_tidur b ON pd.id_tempat_tidur = b.id "
              + "LEFT JOIN ruangan r ON b.id_ruangan = r.id "
              + "WHERE (pd.no_pendaftaran LIKE ? OR p.nama_lengkap LIKE ? OR p.no_rekam_medis LIKE ?)"
        );
        if (statusFilter != null && !statusFilter.isEmpty() && !statusFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND pd.status_pendaftaran = '").append(statusFilter).append("'");
        }
        if (jenisFilter != null && !jenisFilter.isEmpty() && !jenisFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND pd.jenis_kunjungan = '").append(jenisFilter).append("'");
        }
        sql.append(" ORDER BY pd.id DESC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[PendaftaranDao] search error: " + e.getMessage());
        }
        return list;
    }

    public List<Pendaftaran> findByDokterId(int dokterId, Date tanggal, String status) {
        List<Pendaftaran> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT pd.*, p.no_rekam_medis, p.nama_lengkap as nama_pasien, "
              + "d.nama_lengkap as nama_dokter, b.nomor_bed, r.nama_ruangan "
              + "FROM pendaftaran pd "
              + "JOIN pasien p ON pd.id_pasien = p.id "
              + "JOIN dokter d ON pd.id_dokter = d.id "
              + "LEFT JOIN tempat_tidur b ON pd.id_tempat_tidur = b.id "
              + "LEFT JOIN ruangan r ON b.id_ruangan = r.id "
              + "WHERE pd.id_dokter = ?"
        );
        if (tanggal != null) {
            sql.append(" AND pd.tanggal_daftar = ?");
        }
        if (status != null && !status.isEmpty() && !status.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND pd.status_pendaftaran = ?");
        }
        sql.append(" ORDER BY pd.id ASC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            int idx = 1;
            ps.setInt(idx++, dokterId);
            if (tanggal != null) {
                ps.setDate(idx++, tanggal);
            }
            if (status != null && !status.isEmpty() && !status.equalsIgnoreCase("SEMUA")) {
                ps.setString(idx++, status);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[PendaftaranDao] findByDokterId error: " + e.getMessage());
        }
        return list;
    }

    public Pendaftaran findById(int id) {
        String sql = "SELECT pd.*, p.no_rekam_medis, p.nama_lengkap as nama_pasien, "
                   + "d.nama_lengkap as nama_dokter, b.nomor_bed, r.nama_ruangan "
                   + "FROM pendaftaran pd "
                   + "JOIN pasien p ON pd.id_pasien = p.id "
                   + "LEFT JOIN dokter d ON pd.id_dokter = d.id "
                   + "LEFT JOIN tempat_tidur b ON pd.id_tempat_tidur = b.id "
                   + "LEFT JOIN ruangan r ON b.id_ruangan = r.id "
                   + "WHERE pd.id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[PendaftaranDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(Pendaftaran p) throws SQLException {
        String sql = "INSERT INTO pendaftaran (no_pendaftaran, id_pasien, id_dokter, jenis_kunjungan, tanggal_daftar, keluhan_utama, status_pendaftaran, id_tempat_tidur, created_by) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNoPendaftaran());
            ps.setInt(2, p.getIdPasien());
            if (p.getIdDokter() != null) ps.setInt(3, p.getIdDokter()); else ps.setNull(3, java.sql.Types.INTEGER);
            ps.setString(4, p.getJenisKunjungan());
            ps.setDate(5, p.getTanggalDaftar());
            ps.setString(6, p.getKeluhanUtama());
            ps.setString(7, p.getStatusPendaftaran());
            if (p.getIdTempatTidur() != null) ps.setInt(8, p.getIdTempatTidur()); else ps.setNull(8, java.sql.Types.INTEGER);
            if (p.getCreatedBy() != null) ps.setInt(9, p.getCreatedBy()); else ps.setNull(9, java.sql.Types.INTEGER);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) p.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(Pendaftaran p) throws SQLException {
        String sql = "UPDATE pendaftaran SET id_pasien = ?, id_dokter = ?, jenis_kunjungan = ?, tanggal_daftar = ?, keluhan_utama = ?, status_pendaftaran = ?, id_tempat_tidur = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, p.getIdPasien());
            if (p.getIdDokter() != null) ps.setInt(2, p.getIdDokter()); else ps.setNull(2, java.sql.Types.INTEGER);
            ps.setString(3, p.getJenisKunjungan());
            ps.setDate(4, p.getTanggalDaftar());
            ps.setString(5, p.getKeluhanUtama());
            ps.setString(6, p.getStatusPendaftaran());
            if (p.getIdTempatTidur() != null) ps.setInt(7, p.getIdTempatTidur()); else ps.setNull(7, java.sql.Types.INTEGER);
            ps.setInt(8, p.getId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM pendaftaran WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateStatus(int id, String newStatus) throws SQLException {
        String sql = "UPDATE pendaftaran SET status_pendaftaran = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newStatus);
            ps.setInt(2, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextNoPendaftaran() {
        String today = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String sql = "SELECT COUNT(*) FROM pendaftaran WHERE tanggal_daftar = CURRENT_DATE";
        int count = 1;
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) count = rs.getInt(1) + 1;
        } catch (SQLException ignored) {}
        return String.format("REG-%s-%03d", today, count);
    }

    private Pendaftaran mapResultSet(ResultSet rs) throws SQLException {
        Pendaftaran p = new Pendaftaran();
        p.setId(rs.getInt("id"));
        p.setNoPendaftaran(rs.getString("no_pendaftaran"));
        p.setIdPasien(rs.getInt("id_pasien"));
        p.setIdDokter((Integer) rs.getObject("id_dokter"));
        p.setJenisKunjungan(rs.getString("jenis_kunjungan"));
        p.setTanggalDaftar(rs.getDate("tanggal_daftar"));
        p.setKeluhanUtama(rs.getString("keluhan_utama"));
        p.setStatusPendaftaran(rs.getString("status_pendaftaran"));
        p.setIdTempatTidur((Integer) rs.getObject("id_tempat_tidur"));
        p.setCreatedBy((Integer) rs.getObject("created_by"));
        p.setCreatedAt(rs.getTimestamp("created_at"));

        p.setNoRekamMedis(rs.getString("no_rekam_medis"));
        p.setNamaPasien(rs.getString("nama_pasien"));
        p.setNamaDokter(rs.getString("nama_dokter"));
        p.setNomorBed(rs.getString("nomor_bed"));
        p.setNamaRuangan(rs.getString("nama_ruangan"));
        return p;
    }
}
