package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Diagnosis;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DiagnosisDao {

    public List<Diagnosis> findByRekamMedisId(int rmId) {
        List<Diagnosis> list = new ArrayList<>();
        String sql = "SELECT * FROM diagnosis WHERE id_rekam_medis = ? ORDER BY id ASC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, rmId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSet(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[DiagnosisDao] findByRekamMedisId error: " + e.getMessage());
        }
        return list;
    }

    public boolean insert(Diagnosis d) throws SQLException {
        String sql = "INSERT INTO diagnosis (id_rekam_medis, kode_icd, nama_diagnosis, jenis_diagnosis, deskripsi) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, d.getIdRekamMedis());
            ps.setString(2, d.getKodeIcd());
            ps.setString(3, d.getNamaDiagnosis());
            ps.setString(4, d.getJenisDiagnosis());
            ps.setString(5, d.getDeskripsi());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) d.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM diagnosis WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private Diagnosis mapResultSet(ResultSet rs) throws SQLException {
        Diagnosis d = new Diagnosis();
        d.setId(rs.getInt("id"));
        d.setIdRekamMedis(rs.getInt("id_rekam_medis"));
        d.setKodeIcd(rs.getString("kode_icd"));
        d.setNamaDiagnosis(rs.getString("nama_diagnosis"));
        d.setJenisDiagnosis(rs.getString("jenis_diagnosis"));
        d.setDeskripsi(rs.getString("deskripsi"));
        return d;
    }
}
