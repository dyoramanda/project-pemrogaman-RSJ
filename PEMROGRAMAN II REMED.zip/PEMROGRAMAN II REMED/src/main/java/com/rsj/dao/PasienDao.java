package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.Pasien;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class PasienDao {

    public List<Pasien> findAll() {
        List<Pasien> list = new ArrayList<>();
        String sql = "SELECT p.*, pj.nama_lengkap as nama_pj, r.nama_ruangan, b.nomor_bed "
                   + "FROM pasien p "
                   + "LEFT JOIN penanggung_jawab pj ON p.id_penanggung_jawab = pj.id "
                   + "LEFT JOIN ruangan r ON p.id_ruangan = r.id "
                   + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
                   + "ORDER BY p.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(mapResultSetToPasien(rs));
            }
        } catch (SQLException e) {
            System.err.println("[PasienDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<Pasien> search(String keyword, String statusRawatFilter) {
        List<Pasien> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT p.*, pj.nama_lengkap as nama_pj, r.nama_ruangan, b.nomor_bed "
              + "FROM pasien p "
              + "LEFT JOIN penanggung_jawab pj ON p.id_penanggung_jawab = pj.id "
              + "LEFT JOIN ruangan r ON p.id_ruangan = r.id "
              + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
              + "WHERE (p.nama_lengkap LIKE ? OR p.no_rekam_medis LIKE ? OR p.nik LIKE ?)"
        );
        if (statusRawatFilter != null && !statusRawatFilter.isEmpty() && !statusRawatFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND p.status_rawat = ?");
        }
        sql.append(" ORDER BY p.id DESC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            if (statusRawatFilter != null && !statusRawatFilter.isEmpty() && !statusRawatFilter.equalsIgnoreCase("SEMUA")) {
                ps.setString(4, statusRawatFilter);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToPasien(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[PasienDao] search error: " + e.getMessage());
        }
        return list;
    }

    public Pasien findById(int id) {
        String sql = "SELECT p.*, pj.nama_lengkap as nama_pj, r.nama_ruangan, b.nomor_bed "
                   + "FROM pasien p "
                   + "LEFT JOIN penanggung_jawab pj ON p.id_penanggung_jawab = pj.id "
                   + "LEFT JOIN ruangan r ON p.id_ruangan = r.id "
                   + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
                   + "WHERE p.id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToPasien(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("[PasienDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public Pasien findByNoRekamMedis(String noRm) {
        String sql = "SELECT p.*, pj.nama_lengkap as nama_pj, r.nama_ruangan, b.nomor_bed "
                   + "FROM pasien p "
                   + "LEFT JOIN penanggung_jawab pj ON p.id_penanggung_jawab = pj.id "
                   + "LEFT JOIN ruangan r ON p.id_ruangan = r.id "
                   + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
                   + "WHERE p.no_rekam_medis = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, noRm);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToPasien(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("[PasienDao] findByNoRekamMedis error: " + e.getMessage());
        }
        return null;
    }

    public List<Pasien> findByUserIdKeluarga(int userId) {
        List<Pasien> list = new ArrayList<>();
        String sql = "SELECT p.*, pj.nama_lengkap as nama_pj, r.nama_ruangan, b.nomor_bed "
                   + "FROM pasien p "
                   + "JOIN penanggung_jawab pj ON p.id_penanggung_jawab = pj.id "
                   + "LEFT JOIN ruangan r ON p.id_ruangan = r.id "
                   + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
                   + "WHERE pj.id_user = ? "
                   + "ORDER BY p.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToPasien(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[PasienDao] findByUserIdKeluarga error: " + e.getMessage());
        }
        return list;
    }

    public boolean insert(Pasien p) throws SQLException {
        String sql = "INSERT INTO pasien (no_rekam_medis, nik, nama_lengkap, jenis_kelamin, tanggal_lahir, alamat, no_telepon, status_pernikahan, agama, golongan_darah, status_rawat, tanggal_masuk, id_penanggung_jawab, id_ruangan, id_tempat_tidur) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNoRekamMedis());
            ps.setString(2, p.getNik());
            ps.setString(3, p.getNamaLengkap());
            ps.setString(4, p.getJenisKelamin());
            ps.setDate(5, p.getTanggalLahir());
            ps.setString(6, p.getAlamat());
            ps.setString(7, p.getNoTelepon());
            ps.setString(8, p.getStatusPernikahan());
            ps.setString(9, p.getAgama());
            ps.setString(10, p.getGolonganDarah());
            ps.setString(11, p.getStatusRawat());
            ps.setDate(12, p.getTanggalMasuk());
            if (p.getIdPenanggungJawab() != null) ps.setInt(13, p.getIdPenanggungJawab()); else ps.setNull(13, java.sql.Types.INTEGER);
            if (p.getIdRuangan() != null) ps.setInt(14, p.getIdRuangan()); else ps.setNull(14, java.sql.Types.INTEGER);
            if (p.getIdTempatTidur() != null) ps.setInt(15, p.getIdTempatTidur()); else ps.setNull(15, java.sql.Types.INTEGER);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) p.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(Pasien p) throws SQLException {
        String sql = "UPDATE pasien SET nik = ?, nama_lengkap = ?, jenis_kelamin = ?, tanggal_lahir = ?, alamat = ?, no_telepon = ?, "
                   + "status_pernikahan = ?, agama = ?, golongan_darah = ?, status_rawat = ?, tanggal_masuk = ?, tanggal_keluar = ?, "
                   + "id_penanggung_jawab = ?, id_ruangan = ?, id_tempat_tidur = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getNik());
            ps.setString(2, p.getNamaLengkap());
            ps.setString(3, p.getJenisKelamin());
            ps.setDate(4, p.getTanggalLahir());
            ps.setString(5, p.getAlamat());
            ps.setString(6, p.getNoTelepon());
            ps.setString(7, p.getStatusPernikahan());
            ps.setString(8, p.getAgama());
            ps.setString(9, p.getGolonganDarah());
            ps.setString(10, p.getStatusRawat());
            ps.setDate(11, p.getTanggalMasuk());
            ps.setDate(12, p.getTanggalKeluar());
            if (p.getIdPenanggungJawab() != null) ps.setInt(13, p.getIdPenanggungJawab()); else ps.setNull(13, java.sql.Types.INTEGER);
            if (p.getIdRuangan() != null) ps.setInt(14, p.getIdRuangan()); else ps.setNull(14, java.sql.Types.INTEGER);
            if (p.getIdTempatTidur() != null) ps.setInt(15, p.getIdTempatTidur()); else ps.setNull(15, java.sql.Types.INTEGER);
            ps.setInt(16, p.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM pasien WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextNoRM() {
        String sql = "SELECT COUNT(*) FROM pasien";
        int count = 1;
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                count = rs.getInt(1) + 1;
            }
        } catch (SQLException ignored) {}
        int year = java.time.Year.now().getValue();
        return String.format("RM-%d-%04d", year, count);
    }

    private Pasien mapResultSetToPasien(ResultSet rs) throws SQLException {
        Pasien p = new Pasien();
        p.setId(rs.getInt("id"));
        p.setNoRekamMedis(rs.getString("no_rekam_medis"));
        p.setNik(rs.getString("nik"));
        p.setNamaLengkap(rs.getString("nama_lengkap"));
        p.setJenisKelamin(rs.getString("jenis_kelamin"));
        p.setTanggalLahir(rs.getDate("tanggal_lahir"));
        p.setAlamat(rs.getString("alamat"));
        p.setNoTelepon(rs.getString("no_telepon"));
        p.setStatusPernikahan(rs.getString("status_pernikahan"));
        p.setAgama(rs.getString("agama"));
        p.setGolonganDarah(rs.getString("golongan_darah"));
        p.setStatusRawat(rs.getString("status_rawat"));
        p.setTanggalMasuk(rs.getDate("tanggal_masuk"));
        p.setTanggalKeluar(rs.getDate("tanggal_keluar"));
        p.setIdPenanggungJawab((Integer) rs.getObject("id_penanggung_jawab"));
        p.setIdRuangan((Integer) rs.getObject("id_ruangan"));
        p.setIdTempatTidur((Integer) rs.getObject("id_tempat_tidur"));
        p.setCreatedAt(rs.getTimestamp("created_at"));

        p.setNamaPenanggungJawab(rs.getString("nama_pj"));
        p.setNamaRuangan(rs.getString("nama_ruangan"));
        p.setNomorBed(rs.getString("nomor_bed"));
        return p;
    }
}
