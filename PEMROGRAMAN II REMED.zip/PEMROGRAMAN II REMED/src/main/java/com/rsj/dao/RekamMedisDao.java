package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.RekamMedis;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RekamMedisDao {

    public List<RekamMedis> findAll() {
        List<RekamMedis> list = new ArrayList<>();
        String sql = "SELECT rm.*, p.no_rekam_medis as rm_pasien, p.nama_lengkap as nama_pasien, "
                   + "d.nama_lengkap as nama_dokter, pd.no_pendaftaran "
                   + "FROM rekam_medis rm "
                   + "JOIN pasien p ON rm.id_pasien = p.id "
                   + "JOIN dokter d ON rm.id_dokter = d.id "
                   + "JOIN pendaftaran pd ON rm.id_pendaftaran = pd.id "
                   + "ORDER BY rm.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[RekamMedisDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<RekamMedis> findByPasienId(int pasienId) {
        List<RekamMedis> list = new ArrayList<>();
        String sql = "SELECT rm.*, p.no_rekam_medis as rm_pasien, p.nama_lengkap as nama_pasien, "
                   + "d.nama_lengkap as nama_dokter, pd.no_pendaftaran "
                   + "FROM rekam_medis rm "
                   + "JOIN pasien p ON rm.id_pasien = p.id "
                   + "JOIN dokter d ON rm.id_dokter = d.id "
                   + "JOIN pendaftaran pd ON rm.id_pendaftaran = pd.id "
                   + "WHERE rm.id_pasien = ? "
                   + "ORDER BY rm.tanggal_periksa DESC, rm.id DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pasienId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[RekamMedisDao] findByPasienId error: " + e.getMessage());
        }
        return list;
    }

    public RekamMedis findById(int id) {
        String sql = "SELECT rm.*, p.no_rekam_medis as rm_pasien, p.nama_lengkap as nama_pasien, "
                   + "d.nama_lengkap as nama_dokter, pd.no_pendaftaran "
                   + "FROM rekam_medis rm "
                   + "JOIN pasien p ON rm.id_pasien = p.id "
                   + "JOIN dokter d ON rm.id_dokter = d.id "
                   + "JOIN pendaftaran pd ON rm.id_pendaftaran = pd.id "
                   + "WHERE rm.id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[RekamMedisDao] findById error: " + e.getMessage());
        }
        return null;
    }

    public RekamMedis findByPendaftaranId(int pendaftaranId) {
        String sql = "SELECT rm.*, p.no_rekam_medis as rm_pasien, p.nama_lengkap as nama_pasien, "
                   + "d.nama_lengkap as nama_dokter, pd.no_pendaftaran "
                   + "FROM rekam_medis rm "
                   + "JOIN pasien p ON rm.id_pasien = p.id "
                   + "JOIN dokter d ON rm.id_dokter = d.id "
                   + "JOIN pendaftaran pd ON rm.id_pendaftaran = pd.id "
                   + "WHERE rm.id_pendaftaran = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pendaftaranId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("[RekamMedisDao] findByPendaftaranId error: " + e.getMessage());
        }
        return null;
    }

    public boolean insert(RekamMedis rm) throws SQLException {
        String sql = "INSERT INTO rekam_medis (no_rekam_medis_visit, id_pendaftaran, id_pasien, id_dokter, tanggal_periksa, anamnesis, pemeriksaan_fisik, status_mental, catatan_psikiatri) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, rm.getNoRekamMedisVisit());
            ps.setInt(2, rm.getIdPendaftaran());
            ps.setInt(3, rm.getIdPasien());
            ps.setInt(4, rm.getIdDokter());
            ps.setDate(5, rm.getTanggalPeriksa());
            ps.setString(6, rm.getAnamnesis());
            ps.setString(7, rm.getPemeriksaanFisik());
            ps.setString(8, rm.getStatusMental());
            ps.setString(9, rm.getCatatanPsikiatri());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) rm.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(RekamMedis rm) throws SQLException {
        String sql = "UPDATE rekam_medis SET tanggal_periksa = ?, anamnesis = ?, pemeriksaan_fisik = ?, status_mental = ?, catatan_psikiatri = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, rm.getTanggalPeriksa());
            ps.setString(2, rm.getAnamnesis());
            ps.setString(3, rm.getPemeriksaanFisik());
            ps.setString(4, rm.getStatusMental());
            ps.setString(5, rm.getCatatanPsikiatri());
            ps.setInt(6, rm.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM rekam_medis WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    public String generateNextNoRMVisit() {
        String today = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd"));
        String sql = "SELECT COUNT(*) FROM rekam_medis WHERE tanggal_periksa = CURRENT_DATE";
        int count = 1;
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) count = rs.getInt(1) + 1;
        } catch (SQLException ignored) {}
        return String.format("RMV-%s-%03d", today, count);
    }

    private RekamMedis mapResultSet(ResultSet rs) throws SQLException {
        RekamMedis rm = new RekamMedis();
        rm.setId(rs.getInt("id"));
        rm.setNoRekamMedisVisit(rs.getString("no_rekam_medis_visit"));
        rm.setIdPendaftaran(rs.getInt("id_pendaftaran"));
        rm.setIdPasien(rs.getInt("id_pasien"));
        rm.setIdDokter(rs.getInt("id_dokter"));
        rm.setTanggalPeriksa(rs.getDate("tanggal_periksa"));
        rm.setAnamnesis(rs.getString("anamnesis"));
        rm.setPemeriksaanFisik(rs.getString("pemeriksaan_fisik"));
        rm.setStatusMental(rs.getString("status_mental"));
        rm.setCatatanPsikiatri(rs.getString("catatan_psikiatri"));
        rm.setCreatedAt(rs.getTimestamp("created_at"));

        rm.setNoRekamMedisPasien(rs.getString("rm_pasien"));
        rm.setNamaPasien(rs.getString("nama_pasien"));
        rm.setNamaDokter(rs.getString("nama_dokter"));
        rm.setNoPendaftaran(rs.getString("no_pendaftaran"));
        return rm;
    }
}
