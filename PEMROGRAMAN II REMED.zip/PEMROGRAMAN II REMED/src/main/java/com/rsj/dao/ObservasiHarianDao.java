package com.rsj.dao;

import com.rsj.config.DatabaseConfig;
import com.rsj.model.ObservasiHarian;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ObservasiHarianDao {

    public List<ObservasiHarian> findAll() {
        List<ObservasiHarian> list = new ArrayList<>();
        String sql = "SELECT o.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, pr.nama_lengkap as nama_perawat, b.nomor_bed "
                   + "FROM observasi_harian o "
                   + "JOIN pasien p ON o.id_pasien = p.id "
                   + "JOIN perawat pr ON o.id_perawat = pr.id "
                   + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
                   + "ORDER BY o.tanggal_observasi DESC, o.waktu_observasi DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException e) {
            System.err.println("[ObservasiHarianDao] findAll error: " + e.getMessage());
        }
        return list;
    }

    public List<ObservasiHarian> findByPasienId(int pasienId) {
        List<ObservasiHarian> list = new ArrayList<>();
        String sql = "SELECT o.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, pr.nama_lengkap as nama_perawat, b.nomor_bed "
                   + "FROM observasi_harian o "
                   + "JOIN pasien p ON o.id_pasien = p.id "
                   + "JOIN perawat pr ON o.id_perawat = pr.id "
                   + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
                   + "WHERE o.id_pasien = ? "
                   + "ORDER BY o.tanggal_observasi DESC, o.waktu_observasi DESC";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, pasienId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[ObservasiHarianDao] findByPasienId error: " + e.getMessage());
        }
        return list;
    }

    public List<ObservasiHarian> search(String keyword, String kondisiFilter) {
        List<ObservasiHarian> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT o.*, p.nama_lengkap as nama_pasien, p.no_rekam_medis, pr.nama_lengkap as nama_perawat, b.nomor_bed "
              + "FROM observasi_harian o "
              + "JOIN pasien p ON o.id_pasien = p.id "
              + "JOIN perawat pr ON o.id_perawat = pr.id "
              + "LEFT JOIN tempat_tidur b ON p.id_tempat_tidur = b.id "
              + "WHERE (p.nama_lengkap LIKE ? OR p.no_rekam_medis LIKE ? OR pr.nama_lengkap LIKE ?)"
        );
        if (kondisiFilter != null && !kondisiFilter.isEmpty() && !kondisiFilter.equalsIgnoreCase("SEMUA")) {
            sql.append(" AND o.status_kondisi = '").append(kondisiFilter).append("'");
        }
        sql.append(" ORDER BY o.tanggal_observasi DESC, o.waktu_observasi DESC");

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            String kw = "%" + (keyword != null ? keyword : "") + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("[ObservasiHarianDao] search error: " + e.getMessage());
        }
        return list;
    }

    public boolean insert(ObservasiHarian o) throws SQLException {
        String sql = "INSERT INTO observasi_harian (id_pasien, id_perawat, tanggal_observasi, waktu_observasi, tekanan_darah, denyut_nadi, suhu_tubuh, status_kondisi, status_mood, kualitas_tidur, kepatuhan_obat, nafsu_makan, catatan_perilaku) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, o.getIdPasien());
            ps.setInt(2, o.getIdPerawat());
            ps.setDate(3, o.getTanggalObservasi());
            ps.setTime(4, o.getWaktuObservasi());
            ps.setString(5, o.getTekananDarah());
            if (o.getDenyutNadi() != null) ps.setInt(6, o.getDenyutNadi()); else ps.setNull(6, java.sql.Types.INTEGER);
            ps.setBigDecimal(7, o.getSuhuTubuh());
            ps.setString(8, o.getStatusKondisi());
            ps.setString(9, o.getStatusMood());
            ps.setString(10, o.getKualitasTidur());
            ps.setString(11, o.getKepatuhanObat());
            ps.setString(12, o.getNafsuMakan());
            ps.setString(13, o.getCatatanPerilaku());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) o.setId(keys.getInt(1));
                }
                return true;
            }
        }
        return false;
    }

    public boolean update(ObservasiHarian o) throws SQLException {
        String sql = "UPDATE observasi_harian SET id_pasien = ?, id_perawat = ?, tanggal_observasi = ?, waktu_observasi = ?, tekanan_darah = ?, denyut_nadi = ?, suhu_tubuh = ?, status_kondisi = ?, status_mood = ?, kualitas_tidur = ?, kepatuhan_obat = ?, nafsu_makan = ?, catatan_perilaku = ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, o.getIdPasien());
            ps.setInt(2, o.getIdPerawat());
            ps.setDate(3, o.getTanggalObservasi());
            ps.setTime(4, o.getWaktuObservasi());
            ps.setString(5, o.getTekananDarah());
            if (o.getDenyutNadi() != null) ps.setInt(6, o.getDenyutNadi()); else ps.setNull(6, java.sql.Types.INTEGER);
            ps.setBigDecimal(7, o.getSuhuTubuh());
            ps.setString(8, o.getStatusKondisi());
            ps.setString(9, o.getStatusMood());
            ps.setString(10, o.getKualitasTidur());
            ps.setString(11, o.getKepatuhanObat());
            ps.setString(12, o.getNafsuMakan());
            ps.setString(13, o.getCatatanPerilaku());
            ps.setInt(14, o.getId());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM observasi_harian WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    private ObservasiHarian mapResultSet(ResultSet rs) throws SQLException {
        ObservasiHarian o = new ObservasiHarian();
        o.setId(rs.getInt("id"));
        o.setIdPasien(rs.getInt("id_pasien"));
        o.setIdPerawat(rs.getInt("id_perawat"));
        o.setTanggalObservasi(rs.getDate("tanggal_observasi"));
        o.setWaktuObservasi(rs.getTime("waktu_observasi"));
        o.setTekananDarah(rs.getString("tekanan_darah"));
        o.setDenyutNadi((Integer) rs.getObject("denyut_nadi"));
        o.setSuhuTubuh(rs.getBigDecimal("suhu_tubuh"));
        o.setStatusKondisi(rs.getString("status_kondisi"));
        o.setStatusMood(rs.getString("status_mood"));
        o.setKualitasTidur(rs.getString("kualitas_tidur"));
        o.setKepatuhanObat(rs.getString("kepatuhan_obat"));
        o.setNafsuMakan(rs.getString("nafsu_makan"));
        o.setCatatanPerilaku(rs.getString("catatan_perilaku"));

        o.setNamaPasien(rs.getString("nama_pasien"));
        o.setNoRekamMedis(rs.getString("no_rekam_medis"));
        o.setNamaPerawat(rs.getString("nama_perawat"));
        o.setNomorBed(rs.getString("nomor_bed"));
        return o;
    }
}
