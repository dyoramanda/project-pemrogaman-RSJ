package com.rsj.service;

import com.rsj.dao.DiagnosisDao;
import com.rsj.dao.PasienDao;
import com.rsj.dao.PendaftaranDao;
import com.rsj.dao.PenanggungJawabDao;
import com.rsj.dao.RekamMedisDao;
import com.rsj.dao.TempatTidurDao;
import com.rsj.model.Diagnosis;
import com.rsj.model.Pasien;
import com.rsj.model.Pendaftaran;
import com.rsj.model.PenanggungJawab;
import com.rsj.model.RekamMedis;
import com.rsj.util.SessionManager;
import java.util.List;

public class PelayananService {

    private final PasienDao pasienDao = new PasienDao();
    private final PenanggungJawabDao penanggungJawabDao = new PenanggungJawabDao();
    private final PendaftaranDao pendaftaranDao = new PendaftaranDao();
    private final TempatTidurDao tempatTidurDao = new TempatTidurDao();
    private final RekamMedisDao rekamMedisDao = new RekamMedisDao();
    private final DiagnosisDao diagnosisDao = new DiagnosisDao();

    // Pasien
    public List<Pasien> getAllPasien() { return pasienDao.findAll(); }
    public List<Pasien> searchPasien(String kw, String status) { return pasienDao.search(kw, status); }
    public Pasien getPasienById(int id) { return pasienDao.findById(id); }

    public void savePasien(Pasien p) throws Exception {
        if (p.getNamaLengkap() == null || p.getNamaLengkap().trim().isEmpty() ||
            p.getNik() == null || p.getNik().trim().isEmpty()) {
            throw new Exception("Nama Pasien dan NIK wajib diisi!");
        }

        if (p.getId() == 0) {
            p.setNoRekamMedis(pasienDao.generateNextNoRM());
            pasienDao.insert(p);
            SessionManager.logAction("TAMBAH", "PASIEN", "Tambah pasien baru: " + p.getNamaLengkap() + " (" + p.getNoRekamMedis() + ")");
        } else {
            pasienDao.update(p);
            SessionManager.logAction("UBAH", "PASIEN", "Update data pasien: " + p.getNamaLengkap() + " (" + p.getNoRekamMedis() + ")");
        }
    }

    public void deletePasien(int id) throws Exception {
        Pasien p = pasienDao.findById(id);
        pasienDao.delete(id);
        SessionManager.logAction("HAPUS", "PASIEN", "Hapus pasien: " + (p != null ? p.getNamaLengkap() : id));
    }

    // Penanggung Jawab
    public List<PenanggungJawab> getAllPenanggungJawab() { return penanggungJawabDao.findAll(); }
    public List<PenanggungJawab> searchPenanggungJawab(String kw) { return penanggungJawabDao.search(kw); }
    public PenanggungJawab getPenanggungJawabById(int id) { return penanggungJawabDao.findById(id); }

    public void savePenanggungJawab(PenanggungJawab pj) throws Exception {
        if (pj.getNamaLengkap() == null || pj.getNamaLengkap().trim().isEmpty()) {
            throw new Exception("Nama Penanggung Jawab wajib diisi!");
        }
        if (pj.getId() == 0) {
            penanggungJawabDao.insert(pj);
            SessionManager.logAction("TAMBAH", "PJ", "Tambah penanggung jawab: " + pj.getNamaLengkap());
        } else {
            penanggungJawabDao.update(pj);
            SessionManager.logAction("UBAH", "PJ", "Update penanggung jawab: " + pj.getNamaLengkap());
        }
    }

    public void deletePenanggungJawab(int id) throws Exception {
        penanggungJawabDao.delete(id);
        SessionManager.logAction("HAPUS", "PJ", "Hapus penanggung jawab ID: " + id);
    }

    // Pendaftaran Kunjungan
    public List<Pendaftaran> getAllPendaftaran() { return pendaftaranDao.findAll(); }
    public List<Pendaftaran> searchPendaftaran(String kw, String status, String jenis) { return pendaftaranDao.search(kw, status, jenis); }

    public void daftarKunjungan(Pendaftaran pd) throws Exception {
        if (pd.getIdPasien() <= 0) {
            throw new Exception("Pasien wajib dipilih!");
        }
        pd.setNoPendaftaran(pendaftaranDao.generateNextNoPendaftaran());
        pd.setStatusPendaftaran("MENUNGGU");
        if (SessionManager.getCurrentUser() != null) {
            pd.setCreatedBy(SessionManager.getCurrentUser().getId());
        }

        pendaftaranDao.insert(pd);

        // Update pasien status & bed jika rawat inap
        Pasien p = pasienDao.findById(pd.getIdPasien());
        if (p != null) {
            if ("RAWAT_INAP".equalsIgnoreCase(pd.getJenisKunjungan())) {
                p.setStatusRawat("RAWAT_INAP");
                p.setTanggalMasuk(pd.getTanggalDaftar());
                if (pd.getIdTempatTidur() != null) {
                    p.setIdTempatTidur(pd.getIdTempatTidur());
                    tempatTidurDao.updateStatus(pd.getIdTempatTidur(), "TERISI");
                }
                pasienDao.update(p);
            } else {
                p.setStatusRawat("RAWAT_JALAN");
                pasienDao.update(p);
            }
        }

        SessionManager.logAction("PENDAFTARAN", "PELAYANAN",
                "Pendaftaran baru " + pd.getNoPendaftaran() + " (" + pd.getJenisKunjungan() + ") untuk pasien ID: " + pd.getIdPasien());
    }

    public void daftarPasienBaruDanKunjungan(Pasien p, PenanggungJawab pj, Pendaftaran pd) throws Exception {
        if (p.getNamaLengkap() == null || p.getNamaLengkap().trim().isEmpty() ||
            p.getNik() == null || p.getNik().trim().isEmpty()) {
            throw new Exception("Nama Pasien dan NIK wajib diisi!");
        }

        // Simpan Penanggung Jawab jika ada
        if (pj != null) {
            if (pj.getId() == 0 && pj.getNamaLengkap() != null && !pj.getNamaLengkap().trim().isEmpty()) {
                penanggungJawabDao.insert(pj);
                p.setIdPenanggungJawab(pj.getId());
            } else if (pj.getId() > 0) {
                p.setIdPenanggungJawab(pj.getId());
            }
        }

        // Simpan Pasien Baru (generate No RM)
        p.setNoRekamMedis(pasienDao.generateNextNoRM());
        if ("RAWAT_INAP".equalsIgnoreCase(pd.getJenisKunjungan())) {
            p.setStatusRawat("RAWAT_INAP");
            p.setTanggalMasuk(pd.getTanggalDaftar());
            p.setIdTempatTidur(pd.getIdTempatTidur());
        } else {
            p.setStatusRawat("RAWAT_JALAN");
        }
        pasienDao.insert(p);
        SessionManager.logAction("TAMBAH", "PASIEN", "Tambah pasien baru saat pendaftaran: " + p.getNamaLengkap() + " (" + p.getNoRekamMedis() + ")");

        // Daftarkan Kunjungan
        pd.setIdPasien(p.getId());
        daftarKunjungan(pd);
    }

    public void updatePendaftaranStatus(int id, String newStatus) throws Exception {
        Pendaftaran pd = pendaftaranDao.findById(id);
        if (pd == null) throw new Exception("Data pendaftaran tidak ditemukan!");

        pendaftaranDao.updateStatus(id, newStatus);

        // Jika dibatalkan atau selesai dan punya tempat tidur, bebaskan bed jika perlu
        if ("DIBATALKAN".equalsIgnoreCase(newStatus) && pd.getIdTempatTidur() != null) {
            tempatTidurDao.updateStatus(pd.getIdTempatTidur(), "TERSEDIA");
        }

        SessionManager.logAction("UBAH", "PENDAFTARAN", "Ubah status pendaftaran " + pd.getNoPendaftaran() + " menjadi " + newStatus);
    }

    public void batalkanPendaftaran(int id) throws Exception {
        updatePendaftaranStatus(id, "DIBATALKAN");
    }

    // Rekam Medis & Pemeriksaan Dokter
    public List<RekamMedis> getAllRekamMedis() { return rekamMedisDao.findAll(); }
    public List<RekamMedis> getRekamMedisByPasien(int pasienId) { return rekamMedisDao.findByPasienId(pasienId); }
    public RekamMedis getRekamMedisById(int id) { return rekamMedisDao.findById(id); }

    public void simpanPemeriksaan(RekamMedis rm, List<Diagnosis> diagnosisList) throws Exception {
        if (rm.getIdPasien() <= 0 || rm.getIdDokter() <= 0) {
            throw new Exception("Data Pasien dan Dokter wajib valid!");
        }

        if (rm.getId() == 0) {
            rm.setNoRekamMedisVisit(rekamMedisDao.generateNextNoRMVisit());
            rekamMedisDao.insert(rm);
            // Update status pendaftaran menjadi DIPERIKSA / SELESAI
            pendaftaranDao.updateStatus(rm.getIdPendaftaran(), "SELESAI");
            SessionManager.logAction("TAMBAH", "REKAM_MEDIS", "Pemeriksaan medis baru: " + rm.getNoRekamMedisVisit());
        } else {
            rekamMedisDao.update(rm);
            SessionManager.logAction("UBAH", "REKAM_MEDIS", "Update pemeriksaan: " + rm.getNoRekamMedisVisit());
        }

        // Insert diagnosis
        if (diagnosisList != null) {
            for (Diagnosis d : diagnosisList) {
                d.setIdRekamMedis(rm.getId());
                diagnosisDao.insert(d);
            }
        }
    }

    public List<Diagnosis> getDiagnosisByRekamMedis(int rmId) {
        return diagnosisDao.findByRekamMedisId(rmId);
    }
}
