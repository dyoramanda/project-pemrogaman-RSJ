package com.rsj.service;

import com.rsj.dao.PenanggungJawabDao;
import com.rsj.dao.UserDao;
import com.rsj.model.PenanggungJawab;
import com.rsj.model.User;
import com.rsj.util.PasswordUtil;
import com.rsj.util.SessionManager;
import java.sql.SQLException;

public class AuthService {

    private final UserDao userDao = new UserDao();
    private final PenanggungJawabDao penanggungJawabDao = new PenanggungJawabDao();

    public User login(String username, String plainPassword) throws Exception {
        if (username == null || username.trim().isEmpty() || plainPassword == null || plainPassword.isEmpty()) {
            throw new Exception("Username dan Password wajib diisi!");
        }

        User user = userDao.findByUsername(username.trim());
        if (user == null) {
            throw new Exception("Username atau Password salah!");
        }

        if (!user.isStatusAktif()) {
            throw new Exception("Akun ini telah dinonaktifkan oleh Administrator. Hubungi pihak RSJ.");
        }

        if (!PasswordUtil.checkPassword(plainPassword, user.getPasswordHash())) {
            throw new Exception("Username atau Password salah!");
        }

        SessionManager.login(user);
        return user;
    }

    public void registerKeluarga(User user, PenanggungJawab pj, String plainPassword) throws Exception {
        if (user.getUsername() == null || user.getUsername().trim().isEmpty() ||
            plainPassword == null || plainPassword.trim().isEmpty() ||
            user.getNamaLengkap() == null || user.getNamaLengkap().trim().isEmpty()) {
            throw new Exception("Semua data wajib registrasi harus diisi!");
        }

        if (userDao.findByUsername(user.getUsername().trim()) != null) {
            throw new Exception("Username '" + user.getUsername() + "' sudah digunakan, silakan pilih yang lain.");
        }

        user.setRole("KELUARGA_PASIEN");
        user.setStatusAktif(true);
        user.setPasswordHash(PasswordUtil.hashPassword(plainPassword));

        boolean userCreated = userDao.insert(user);
        if (!userCreated) {
            throw new Exception("Gagal membuat akun pengguna keluarga.");
        }

        pj.setIdUser(user.getId());
        pj.setNamaLengkap(user.getNamaLengkap());
        if (pj.getNoTelepon() == null || pj.getNoTelepon().isEmpty()) {
            pj.setNoTelepon(user.getNoTelp());
        }
        penanggungJawabDao.insert(pj);

        SessionManager.logAction("REGISTER", "AUTH", "Pendaftaran akun baru keluarga pasien: " + user.getUsername());
    }

    public void changePassword(int userId, String oldPassword, String newPassword) throws Exception {
        if (newPassword == null || newPassword.length() < 6) {
            throw new Exception("Password baru minimal 6 karakter!");
        }

        User user = userDao.findById(userId);
        if (user == null) {
            throw new Exception("User tidak ditemukan.");
        }

        if (!PasswordUtil.checkPassword(oldPassword, user.getPasswordHash())) {
            throw new Exception("Password lama tidak sesuai!");
        }

        String newHash = PasswordUtil.hashPassword(newPassword);
        userDao.updatePassword(userId, newHash);
        SessionManager.logAction("UBAH_PASSWORD", "AUTH", "Pengguna " + user.getUsername() + " mengubah kata sandi.");
    }

    public void updateProfile(User user) throws Exception {
        userDao.update(user);
        SessionManager.logAction("UPDATE_PROFIL", "AUTH", "Profil diperbarui: " + user.getUsername());
    }
}
