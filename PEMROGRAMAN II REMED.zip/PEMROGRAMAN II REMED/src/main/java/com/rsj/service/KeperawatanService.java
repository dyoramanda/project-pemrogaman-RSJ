package com.rsj.service;

import com.rsj.dao.CatatanInsidenDao;
import com.rsj.dao.ObservasiHarianDao;
import com.rsj.dao.PasienDao;
import com.rsj.dao.TempatTidurDao;
import com.rsj.model.CatatanInsiden;
import com.rsj.model.ObservasiHarian;
import com.rsj.model.Pasien;
import com.rsj.model.TempatTidur;
import com.rsj.util.SessionManager;
import java.sql.Date;
import java.util.List;

public class KeperawatanService {

    private final ObservasiHarianDao observasiDao = new ObservasiHarianDao();
    private final CatatanInsidenDao insidenDao = new CatatanInsidenDao();
    private final TempatTidurDao tempatTidurDao = new TempatTidurDao();
    private final PasienDao pasienDao = new PasienDao();

    // Observasi Harian
    public List<ObservasiHarian> getAllObservasi() { return observasiDao.findAll(); }
    public List<ObservasiHarian> searchObservasi(String kw, String kondisi) { return observasiDao.search(kw, kondisi); }
    public List<ObservasiHarian> getObservasiByPasien(int pasienId) { return observasiDao.findByPasienId(pasienId); }

    public void saveObservasi(ObservasiHarian o) throws Exception {
        if (o.getIdPasien() <= 0 || o.getIdPerawat() <= 0) {
            throw new Exception("Pasien dan Perawat pelaksana wajib dipilih!");
        }
        if (o.getId() == 0) {
            observasiDao.insert(o);
            SessionManager.logAction("TAMBAH", "OBSERVASI", "Observasi baru pasien ID: " + o.getIdPasien() + " [" + o.getStatusKondisi() + "]");
        } else {
            observasiDao.update(o);
            SessionManager.logAction("UBAH", "OBSERVASI", "Update observasi ID: " + o.getId());
        }
    }

    public void deleteObservasi(int id) throws Exception {
        observasiDao.delete(id);
        SessionManager.logAction("HAPUS", "OBSERVASI", "Hapus observasi ID: " + id);
    }

    // Catatan Insiden
    public List<CatatanInsiden> getAllInsiden() { return insidenDao.findAll(); }
    public List<CatatanInsiden> searchInsiden(String kw, String jenis, String risiko) { return insidenDao.search(kw, jenis, risiko); }

    public void saveInsiden(CatatanInsiden ci) throws Exception {
        if (ci.getIdPasien() <= 0) {
            throw new Exception("Pasien terkait insiden wajib dipilih!");
        }
        if (SessionManager.getCurrentUser() != null) {
            ci.setIdPelapor(SessionManager.getCurrentUser().getId());
        }
        if (ci.getId() == 0) {
            insidenDao.insert(ci);
            SessionManager.logAction("TAMBAH", "INSIDEN", "Pelaporan insiden: " + ci.getJenisInsiden() + " (" + ci.getTingkatRisiko() + ")");
        } else {
            insidenDao.update(ci);
            SessionManager.logAction("UBAH", "INSIDEN", "Update insiden ID: " + ci.getId());
        }
    }

    public void deleteInsiden(int id) throws Exception {
        insidenDao.delete(id);
        SessionManager.logAction("HAPUS", "INSIDEN", "Hapus insiden ID: " + id);
    }

    // Manajemen Bed Rawat Inap
    public List<TempatTidur> getAllBeds() { return tempatTidurDao.findAll(); }
    public List<TempatTidur> getBedsByRuangan(int rId) { return tempatTidurDao.findByRuanganId(rId); }

    public void updateBedStatus(int bedId, String status) throws Exception {
        tempatTidurDao.updateStatus(bedId, status);
        SessionManager.logAction("STATUS_BED", "BED", "Update status bed ID: " + bedId + " -> " + status);
    }

    public void dischargePatient(int pasienId, int bedId) throws Exception {
        Pasien p = pasienDao.findById(pasienId);
        if (p != null) {
            p.setStatusRawat("SUDAH_PULANG");
            p.setTanggalKeluar(new Date(System.currentTimeMillis()));
            p.setIdTempatTidur(null);
            pasienDao.update(p);
        }
        tempatTidurDao.updateStatus(bedId, "DIBERSIHKAN");
        SessionManager.logAction("PULANG_PASIEN", "BED", "Pasien ID: " + pasienId + " telah dipulangkan, bed " + bedId + " dibersihkan.");
    }
}
