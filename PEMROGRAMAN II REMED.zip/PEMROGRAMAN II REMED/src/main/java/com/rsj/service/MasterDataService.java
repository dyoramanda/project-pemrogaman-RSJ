package com.rsj.service;

import com.rsj.dao.DokterDao;
import com.rsj.dao.JadwalDokterDao;
import com.rsj.dao.PerawatDao;
import com.rsj.dao.RuanganDao;
import com.rsj.dao.TempatTidurDao;
import com.rsj.dao.UserDao;
import com.rsj.model.Dokter;
import com.rsj.model.JadwalDokter;
import com.rsj.model.Perawat;
import com.rsj.model.Ruangan;
import com.rsj.model.TempatTidur;
import com.rsj.model.User;
import com.rsj.util.PasswordUtil;
import com.rsj.util.SessionManager;
import java.util.List;

public class MasterDataService {

    private final UserDao userDao = new UserDao();
    private final DokterDao dokterDao = new DokterDao();
    private final PerawatDao perawatDao = new PerawatDao();
    private final RuanganDao ruanganDao = new RuanganDao();
    private final TempatTidurDao tempatTidurDao = new TempatTidurDao();
    private final JadwalDokterDao jadwalDokterDao = new JadwalDokterDao();

    // User Operations
    public List<User> getAllUsers() { return userDao.findAll(); }
    public List<User> searchUsers(String kw, String role) { return userDao.search(kw, role); }

    public void createUser(User u, String plainPass) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak menambah User!");
        if (userDao.findByUsername(u.getUsername()) != null) throw new Exception("Username sudah terdaftar!");
        u.setPasswordHash(PasswordUtil.hashPassword(plainPass != null && !plainPass.isEmpty() ? plainPass : "123456"));
        userDao.insert(u);
        SessionManager.logAction("TAMBAH", "USER", "Tambah user baru: " + u.getUsername() + " (" + u.getRole() + ")");
    }

    public void updateUser(User u) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak mengedit User!");
        userDao.update(u);
        SessionManager.logAction("UBAH", "USER", "Update user: " + u.getUsername());
    }

    public void deleteUser(int id) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak menghapus User!");
        User u = userDao.findById(id);
        if (u != null && u.getId() == SessionManager.getCurrentUser().getId()) {
            throw new Exception("Anda tidak dapat menghapus akun Anda sendiri yang sedang aktif!");
        }
        userDao.delete(id);
        SessionManager.logAction("HAPUS", "USER", "Hapus user ID: " + id);
    }

    public void resetUserPassword(int userId, String newPass) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak me-reset Password!");
        userDao.updatePassword(userId, PasswordUtil.hashPassword(newPass));
        SessionManager.logAction("RESET_PASSWORD", "USER", "Reset password user ID: " + userId);
    }

    // Dokter Operations
    public List<Dokter> getAllDokter() { return dokterDao.findAll(); }
    public List<Dokter> searchDokter(String kw) { return dokterDao.search(kw); }
    public void saveDokter(Dokter d) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak mengelola data dokter!");
        if (d.getId() == 0) {
            dokterDao.insert(d);
            SessionManager.logAction("TAMBAH", "DOKTER", "Tambah dokter: " + d.getNamaLengkap());
        } else {
            dokterDao.update(d);
            SessionManager.logAction("UBAH", "DOKTER", "Update dokter: " + d.getNamaLengkap());
        }
    }
    public void deleteDokter(int id) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak!");
        dokterDao.delete(id);
        SessionManager.logAction("HAPUS", "DOKTER", "Hapus dokter ID: " + id);
    }

    // Perawat Operations
    public List<Perawat> getAllPerawat() { return perawatDao.findAll(); }
    public List<Perawat> searchPerawat(String kw) { return perawatDao.search(kw); }
    public void savePerawat(Perawat p) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak mengelola data perawat!");
        if (p.getId() == 0) {
            perawatDao.insert(p);
            SessionManager.logAction("TAMBAH", "PERAWAT", "Tambah perawat: " + p.getNamaLengkap());
        } else {
            perawatDao.update(p);
            SessionManager.logAction("UBAH", "PERAWAT", "Update perawat: " + p.getNamaLengkap());
        }
    }
    public void deletePerawat(int id) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak!");
        perawatDao.delete(id);
        SessionManager.logAction("HAPUS", "PERAWAT", "Hapus perawat ID: " + id);
    }

    // Ruangan Operations
    public List<Ruangan> getAllRuangan() { return ruanganDao.findAll(); }
    public void saveRuangan(Ruangan r) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak!");
        if (r.getId() == 0) {
            ruanganDao.insert(r);
            SessionManager.logAction("TAMBAH", "RUANGAN", "Tambah ruangan: " + r.getNamaRuangan());
        } else {
            ruanganDao.update(r);
            SessionManager.logAction("UBAH", "RUANGAN", "Update ruangan: " + r.getNamaRuangan());
        }
    }
    public void deleteRuangan(int id) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak!");
        ruanganDao.delete(id);
        SessionManager.logAction("HAPUS", "RUANGAN", "Hapus ruangan ID: " + id);
    }

    // Tempat Tidur Operations
    public List<TempatTidur> getAllTempatTidur() { return tempatTidurDao.findAll(); }
    public List<TempatTidur> getTempatTidurByRuangan(int rId) { return tempatTidurDao.findByRuanganId(rId); }
    public List<TempatTidur> getAvailableBeds() { return tempatTidurDao.findAvailableBeds(); }
    public void saveTempatTidur(TempatTidur b) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak!");
        if (b.getId() == 0) {
            tempatTidurDao.insert(b);
            SessionManager.logAction("TAMBAH", "BED", "Tambah bed: " + b.getNomorBed());
        } else {
            tempatTidurDao.update(b);
            SessionManager.logAction("UBAH", "BED", "Update bed: " + b.getNomorBed());
        }
    }
    public void deleteTempatTidur(int id) throws Exception {
        if (!SessionManager.isAdmin()) throw new Exception("Hanya Administrator yang berhak!");
        tempatTidurDao.delete(id);
        SessionManager.logAction("HAPUS", "BED", "Hapus bed ID: " + id);
    }

    // Jadwal Dokter Operations
    public List<JadwalDokter> getAllJadwalDokter() { return jadwalDokterDao.findAll(); }
    public List<JadwalDokter> getJadwalByDokterId(int dId) { return jadwalDokterDao.findByDokterId(dId); }
    public void saveJadwalDokter(JadwalDokter j) throws Exception {
        if (j.getId() == 0) {
            jadwalDokterDao.insert(j);
            SessionManager.logAction("TAMBAH", "JADWAL", "Tambah jadwal dokter hari " + j.getHari());
        } else {
            jadwalDokterDao.update(j);
            SessionManager.logAction("UBAH", "JADWAL", "Update jadwal dokter ID: " + j.getId());
        }
    }
    public void deleteJadwalDokter(int id) throws Exception {
        jadwalDokterDao.delete(id);
        SessionManager.logAction("HAPUS", "JADWAL", "Hapus jadwal dokter ID: " + id);
    }
}
