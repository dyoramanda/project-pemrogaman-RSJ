package com.rsj;

import com.formdev.flatlaf.FlatLightLaf;
import com.rsj.config.DatabaseConfig;
import com.rsj.config.DatabaseInitializer;
import com.rsj.ui.MainFrame;
import com.rsj.util.UiUtils;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {

    public static void main(String[] args) {
        // Step 1: Initialize Modern FlatLaf Look and Feel
        try {
            FlatLightLaf.setup();
            UIManager.put("Button.arc", 12);
            UIManager.put("Component.arc", 12);
            UIManager.put("ProgressBar.arc", 12);
            UIManager.put("TextComponent.arc", 12);
            UIManager.put("ScrollBar.showButtons", false);
            UIManager.put("ScrollBar.width", 10);
            UIManager.put("Table.selectionBackground", new Color(0xE0, 0xF2, 0xFE));
            UIManager.put("Table.selectionForeground", UiUtils.COLOR_TEXT_MAIN);
            UIManager.put("TableHeader.font", UiUtils.FONT_BOLD);
        } catch (Exception e) {
            System.err.println("[Main] Gagal inisialisasi FlatLaf, menggunakan LookAndFeel sistem: " + e.getMessage());
        }

        // Step 2: Initialize Database and Tables
        try {
            System.out.println("[Main] Memeriksa koneksi dan inisialisasi database MySQL...");
            DatabaseInitializer.initialize();
            System.out.println("[Main] Inisialisasi database berhasil!");
        } catch (Exception e) {
            System.err.println("[Main] Database belum aktif atau koneksi gagal: " + e.getMessage());
            // Show clear Indonesian dialog regarding MySQL status
            SwingUtilities.invokeLater(() -> DatabaseConfig.showConnectionErrorDialog(null, e));
        }

        // Step 3: Launch Main Application Window
        SwingUtilities.invokeLater(() -> {
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
                System.out.println("[Main] Aplikasi SIMRS Jiwa (ODGJ) siap digunakan.");
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
