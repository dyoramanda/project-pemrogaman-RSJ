package com.rsj.util;

import com.rsj.dao.AuditLogDao;
import com.rsj.model.User;

public class SessionManager {

    private static User currentUser = null;
    private static final AuditLogDao auditLogDao = new AuditLogDao();

    public static synchronized void login(User user) {
        currentUser = user;
        if (user != null) {
            auditLogDao.log(user.getId(), user.getUsername(), "LOGIN", "AUTH",
                    "Pengguna " + user.getNamaLengkap() + " (" + user.getRole() + ") berhasil masuk sistem.");
        }
    }

    public static synchronized void logout() {
        if (currentUser != null) {
            auditLogDao.log(currentUser.getId(), currentUser.getUsername(), "LOGOUT", "AUTH",
                    "Pengguna " + currentUser.getNamaLengkap() + " keluar dari sistem.");
        }
        currentUser = null;
    }

    public static synchronized User getCurrentUser() {
        return currentUser;
    }

    public static synchronized boolean isLoggedIn() {
        return currentUser != null;
    }

    public static synchronized boolean hasRole(String role) {
        return currentUser != null && currentUser.getRole().equalsIgnoreCase(role);
    }

    public static synchronized boolean isAdmin() {
        return hasRole("ADMIN");
    }

    public static synchronized void logAction(String aksi, String modul, String deskripsi) {
        if (currentUser != null) {
            auditLogDao.log(currentUser.getId(), currentUser.getUsername(), aksi, modul, deskripsi);
        } else {
            auditLogDao.log(null, "ANONYMOUS", aksi, modul, deskripsi);
        }
    }
}
