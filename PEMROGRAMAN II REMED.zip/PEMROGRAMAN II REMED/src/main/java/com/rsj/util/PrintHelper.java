package com.rsj.util;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import javax.swing.JOptionPane;

public class PrintHelper implements Printable {

    private final Component componentToBePrinted;

    public PrintHelper(Component component) {
        this.componentToBePrinted = component;
    }

    public static void printComponent(Component c) {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(new PrintHelper(c));
        boolean doPrint = job.printDialog();
        if (doPrint) {
            try {
                job.print();
                UiUtils.showSuccess(c, "Dokumen berhasil dikirim ke antrean cetak printer!");
            } catch (PrinterException e) {
                UiUtils.showError(c, "Gagal mencetak dokumen: " + e.getMessage());
            }
        }
    }

    @Override
    public int print(Graphics g, PageFormat pageFormat, int pageIndex) {
        if (pageIndex > 0) {
            return NO_SUCH_PAGE;
        }

        Graphics2D g2d = (Graphics2D) g;
        g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());

        // Fit width while maintaining aspect ratio
        double scaleX = pageFormat.getImageableWidth() / componentToBePrinted.getWidth();
        double scaleY = pageFormat.getImageableHeight() / componentToBePrinted.getHeight();
        double scale = Math.min(scaleX, scaleY);
        if (scale < 1.0) {
            g2d.scale(scale, scale);
        }

        componentToBePrinted.paint(g2d);
        return PAGE_EXISTS;
    }
}
