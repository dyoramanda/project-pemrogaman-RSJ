package com.rsj.model;

import java.math.BigDecimal;

public class Dokter {
    private int id;
    private Integer idUser;
    private String nip;
    private String namaLengkap;
    private String spesialisasi; // Spesialis Kedokteran Jiwa (Sp.KJ), Subspesialis Anak & Remaja, dll.
    private String noStr;
    private String noTelepon;
    private String email;
    private BigDecimal tarifKonsultasi;
    private boolean statusAktif;

    public Dokter() {}

    public Dokter(int id, Integer idUser, String nip, String namaLengkap, String spesialisasi, String noStr, String noTelepon, String email, BigDecimal tarifKonsultasi, boolean statusAktif) {
        this.id = id;
        this.idUser = idUser;
        this.nip = nip;
        this.namaLengkap = namaLengkap;
        this.spesialisasi = spesialisasi;
        this.noStr = noStr;
        this.noTelepon = noTelepon;
        this.email = email;
        this.tarifKonsultasi = tarifKonsultasi;
        this.statusAktif = statusAktif;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Integer getIdUser() { return idUser; }
    public void setIdUser(Integer idUser) { this.idUser = idUser; }

    public String getNip() { return nip; }
    public void setNip(String nip) { this.nip = nip; }

    public String getNamaLengkap() { return namaLengkap; }
    public void setNamaLengkap(String namaLengkap) { this.namaLengkap = namaLengkap; }

    public String getSpesialisasi() { return spesialisasi; }
    public void setSpesialisasi(String spesialisasi) { this.spesialisasi = spesialisasi; }

    public String getNoStr() { return noStr; }
    public void setNoStr(String noStr) { this.noStr = noStr; }

    public String getNoTelepon() { return noTelepon; }
    public void setNoTelepon(String noTelepon) { this.noTelepon = noTelepon; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public BigDecimal getTarifKonsultasi() { return tarifKonsultasi; }
    public void setTarifKonsultasi(BigDecimal tarifKonsultasi) { this.tarifKonsultasi = tarifKonsultasi; }

    public boolean isStatusAktif() { return statusAktif; }
    public void setStatusAktif(boolean statusAktif) { this.statusAktif = statusAktif; }

    @Override
    public String toString() {
        return namaLengkap + " (" + spesialisasi + ")";
    }
}
