package com.rsj.model;

public class Perawat {
    private int id;
    private Integer idUser;
    private String nip;
    private String namaLengkap;
    private String noStr;
    private String noTelepon;
    private String shiftDefault; // PAGI, SIANG, MALAM
    private boolean statusAktif;

    public Perawat() {}

    public Perawat(int id, Integer idUser, String nip, String namaLengkap, String noStr, String noTelepon, String shiftDefault, boolean statusAktif) {
        this.id = id;
        this.idUser = idUser;
        this.nip = nip;
        this.namaLengkap = namaLengkap;
        this.noStr = noStr;
        this.noTelepon = noTelepon;
        this.shiftDefault = shiftDefault;
        this.statusAktif = statusAktif;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Integer getIdUser() { return idUser; }
    public void setIdUser(Integer idUser) { this.idUser = idUser; }

    public String getNip() { return nip; }
    public void setNip(String nip) { this.nip = nip; }

    public String getNamaLengkap() { return namaLengkap; }
    public void setNamaLengkap(String namaLengkap) { this.namaLengkap = namaLengkap; }

    public String getNoStr() { return noStr; }
    public void setNoStr(String noStr) { this.noStr = noStr; }

    public String getNoTelepon() { return noTelepon; }
    public void setNoTelepon(String noTelepon) { this.noTelepon = noTelepon; }

    public String getShiftDefault() { return shiftDefault; }
    public void setShiftDefault(String shiftDefault) { this.shiftDefault = shiftDefault; }

    public boolean isStatusAktif() { return statusAktif; }
    public void setStatusAktif(boolean statusAktif) { this.statusAktif = statusAktif; }

    @Override
    public String toString() {
        return namaLengkap + " (" + shiftDefault + ")";
    }
}
