package com.rsj.model;

import java.sql.Date;
import java.sql.Timestamp;

public class RekamMedis {
    private int id;
    private String noRekamMedisVisit;
    private int idPendaftaran;
    private int idPasien;
    private int idDokter;
    private Date tanggalPeriksa;
    private String anamnesis; // Keluhan, riwayat penyakit sekarang & dahulu
    private String pemeriksaanFisik; // Tanda vital, status generalis
    private String statusMental; // Orientasi, Roman muka, Afek/Emosi, Persepsi, Bentuk/Isi Pikir, Psikomotor
    private String catatanPsikiatri; // Rencana terapi, psikoterapi, evaluasi risiko
    private Timestamp createdAt;

    // Joined fields
    private String noRekamMedisPasien;
    private String namaPasien;
    private String namaDokter;
    private String noPendaftaran;

    public RekamMedis() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNoRekamMedisVisit() { return noRekamMedisVisit; }
    public void setNoRekamMedisVisit(String noRekamMedisVisit) { this.noRekamMedisVisit = noRekamMedisVisit; }

    public int getIdPendaftaran() { return idPendaftaran; }
    public void setIdPendaftaran(int idPendaftaran) { this.idPendaftaran = idPendaftaran; }

    public int getIdPasien() { return idPasien; }
    public void setIdPasien(int idPasien) { this.idPasien = idPasien; }

    public int getIdDokter() { return idDokter; }
    public void setIdDokter(int idDokter) { this.idDokter = idDokter; }

    public Date getTanggalPeriksa() { return tanggalPeriksa; }
    public void setTanggalPeriksa(Date tanggalPeriksa) { this.tanggalPeriksa = tanggalPeriksa; }

    public String getAnamnesis() { return anamnesis; }
    public void setAnamnesis(String anamnesis) { this.anamnesis = anamnesis; }

    public String getPemeriksaanFisik() { return pemeriksaanFisik; }
    public void setPemeriksaanFisik(String pemeriksaanFisik) { this.pemeriksaanFisik = pemeriksaanFisik; }

    public String getStatusMental() { return statusMental; }
    public void setStatusMental(String statusMental) { this.statusMental = statusMental; }

    public String getCatatanPsikiatri() { return catatanPsikiatri; }
    public void setCatatanPsikiatri(String catatanPsikiatri) { this.catatanPsikiatri = catatanPsikiatri; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getNoRekamMedisPasien() { return noRekamMedisPasien; }
    public void setNoRekamMedisPasien(String noRekamMedisPasien) { this.noRekamMedisPasien = noRekamMedisPasien; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    public String getNamaDokter() { return namaDokter; }
    public void setNamaDokter(String namaDokter) { this.namaDokter = namaDokter; }

    public String getNoPendaftaran() { return noPendaftaran; }
    public void setNoPendaftaran(String noPendaftaran) { this.noPendaftaran = noPendaftaran; }

    @Override
    public String toString() {
        return noRekamMedisVisit + " (" + tanggalPeriksa + ") - " + namaPasien;
    }
}
