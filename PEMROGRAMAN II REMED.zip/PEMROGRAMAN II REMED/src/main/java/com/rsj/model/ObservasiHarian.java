package com.rsj.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;

public class ObservasiHarian {
    private int id;
    private int idPasien;
    private int idPerawat;
    private Date tanggalObservasi;
    private Time waktuObservasi;
    private String tekananDarah; // e.g. 120/80 mmHg
    private Integer denyutNadi; // bpm
    private BigDecimal suhuTubuh; // Celcius
    private String statusKondisi; // TENANG, GELISAH, AGRESIF, KOOPERATIF, DEPRESIF
    private String statusMood; // Eutimik, Disforik, Euforia, Iritabel, Cemas
    private String kualitasTidur; // NYENYAK, KURANG, SULIT_TIDUR, TIDAK_TIDUR
    private String kepatuhanObat; // PATUH, MENOLAK, PERLU_PENDAMPINGAN, DIBANTU
    private String nafsuMakan; // BAIK, CUKUP, MENURUN, MENOLAK_MAKAN
    private String catatanPerilaku; // Interaksi sosial, kebersihan diri, halusinasi tampak

    // Joined fields
    private String namaPasien;
    private String noRekamMedis;
    private String namaPerawat;
    private String nomorBed;

    public ObservasiHarian() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdPasien() { return idPasien; }
    public void setIdPasien(int idPasien) { this.idPasien = idPasien; }

    public int getIdPerawat() { return idPerawat; }
    public void setIdPerawat(int idPerawat) { this.idPerawat = idPerawat; }

    public Date getTanggalObservasi() { return tanggalObservasi; }
    public void setTanggalObservasi(Date tanggalObservasi) { this.tanggalObservasi = tanggalObservasi; }

    public Time getWaktuObservasi() { return waktuObservasi; }
    public void setWaktuObservasi(Time waktuObservasi) { this.waktuObservasi = waktuObservasi; }

    public String getTekananDarah() { return tekananDarah; }
    public void setTekananDarah(String tekananDarah) { this.tekananDarah = tekananDarah; }

    public Integer getDenyutNadi() { return denyutNadi; }
    public void setDenyutNadi(Integer denyutNadi) { this.denyutNadi = denyutNadi; }

    public BigDecimal getSuhuTubuh() { return suhuTubuh; }
    public void setSuhuTubuh(BigDecimal suhuTubuh) { this.suhuTubuh = suhuTubuh; }

    public String getStatusKondisi() { return statusKondisi; }
    public void setStatusKondisi(String statusKondisi) { this.statusKondisi = statusKondisi; }

    public String getStatusMood() { return statusMood; }
    public void setStatusMood(String statusMood) { this.statusMood = statusMood; }

    public String getKualitasTidur() { return kualitasTidur; }
    public void setKualitasTidur(String kualitasTidur) { this.kualitasTidur = kualitasTidur; }

    public String getKepatuhanObat() { return kepatuhanObat; }
    public void setKepatuhanObat(String kepatuhanObat) { this.kepatuhanObat = kepatuhanObat; }

    public String getNafsuMakan() { return nafsuMakan; }
    public void setNafsuMakan(String nafsuMakan) { this.nafsuMakan = nafsuMakan; }

    public String getCatatanPerilaku() { return catatanPerilaku; }
    public void setCatatanPerilaku(String catatanPerilaku) { this.catatanPerilaku = catatanPerilaku; }

    public String getNamaPasien() { return namaPasien; }
    public void setNamaPasien(String namaPasien) { this.namaPasien = namaPasien; }

    public String getNoRekamMedis() { return noRekamMedis; }
    public void setNoRekamMedis(String noRekamMedis) { this.noRekamMedis = noRekamMedis; }

    public String getNamaPerawat() { return namaPerawat; }
    public void setNamaPerawat(String namaPerawat) { this.namaPerawat = namaPerawat; }

    public String getNomorBed() { return nomorBed; }
    public void setNomorBed(String nomorBed) { this.nomorBed = nomorBed; }

    @Override
    public String toString() {
        return tanggalObservasi + " " + waktuObservasi + " - " + namaPasien + " [" + statusKondisi + "]";
    }
}
