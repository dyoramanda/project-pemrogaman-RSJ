# Sistem Informasi Manajemen Rumah Sakit Jiwa & ODGJ (SIMRS Jiwa)
### RSJ Sehat Jiwa - Berbasis Java Swing Modern (FlatLaf) & MySQL JDBC

Aplikasi Desktop lengkap untuk manajemen rumah sakit jiwa dan kesehatan mental (ODGJ), dibangun dengan bahasa murni **Java 17**, arsitektur berlapis (Model-DAO-Service-UI), tampilan antarmuka modern menggunakan **FlatLaf Look and Feel**, serta integrasi database relasional **MySQL**.

---

## 1. Fitur Utama & 30 Layar / Halaman

Aplikasi ini mencakup **30 modul layar lengkap** sesuai kebutuhan operasional rumah sakit jiwa:

### Umum (Public)
1. **Layar Welcome / Beranda**: Halaman landing bergaya medis modern (Navbar, Hero dengan CTA Masuk, Layanan Jiwa Unggulan, Profil Tim Psikiater, Prinsip Pemulihan Nirkekerasan, Footer Kontak 24 Jam).
2. **Layar Login**: Formulir masuk akun terenkripsi SHA-256 + cryptographic Salt, pendeteksian role dinamis, pintasan 1-klik akun demo, dan link registrasi keluarga.
3. **Registrasi Akun Keluarga Pasien**: Formulir pendaftaran mandiri keluarga / penanggung jawab pasien.
4. **Dialog Akses Ditolak**: Proteksi hak akses berbasis role (RBAC) dengan dialog interaktif.

### Administrator
5. **Dashboard Admin**: Kartu statistik (Total Pasien, Rawat Inap Aktif, Okupansi Bed, Pendapatan Bulan Ini), grafik batang tren kunjungan 6 bulan (Java2D), diagram distribusi bangsal, dan tabel audit log aktivitas.
6. **Manajemen Pengguna (User)**: CRUD User, filter role, reset kata sandi, aktivasi/nonaktif akun.
7. **Kelola Dokter & Perawat**: CRUD data psikiater (NIP, STR, spesialisasi, tarif konsultasi) dan perawat jiwa (shift kerja, STR).
8. **Manajemen Ruangan & Bed**: CRUD bangsal/ruangan (Sakura, Melati, Teratai) dan manajemen nomor bed serta tarif per hari.
9. **Laporan & Cetak Rekapitulasi**: Rekapitulasi kunjungan, pendapatan kasir, dan okupansi tempat tidur + fitur cetak resmi (`java.awt.print.Printable`).

### Petugas Pendaftaran
10. **Dashboard Petugas**: Metrik antrean hari ini dan ketersediaan tempat tidur rawat inap.
11. **Data Pasien Jiwa**: CRUD data pasien (No. RM otomatis, NIK, tanggal lahir, kontak, hubungan penanggung jawab).
12. **Data Penanggung Jawab**: CRUD keluarga pasien dan integrasi akun user keluarga.
13. **Pendaftaran Kunjungan**: Pendaftaran rawat jalan/rawat inap, penentuan dokter psikiater dan alokasi bed, serta cetak bukti antrean pendaftaran.

### Dokter (Psikiater)
14. **Dashboard Dokter**: Antrean pasien menunggu dan selesai diperiksa hari ini.
15. **Jadwal Praktik Dokter**: Kelola hari praktik, jam mulai, jam selesai, dan kuota pasien.
16. **Pemeriksaan & Rekam Medis**: Anamnesis psikiatri, pemeriksaan fisik/vital sign, evaluasi status mental jiwa (afek, mood, persepsi/halusinasi, arus pikir, tilikan), dan cetak lembar rekam medis.
17. **Diagnosis & Resep Obat**: Input diagnosis ICD-10 dan pembuatan resep psikofarmaka terhubung langsung ke Apotek.

### Perawat Jiwa
18. **Dashboard Asuhan Keperawatan**: Monitor pasien rawat inap dan status keamanan bangsal.
19. **Observasi Harian Pasien**: Pencatatan tanda vital (TD, nadi, suhu), status kondisi (Tenang, Kooperatif, Gelisah, Agresif, Depresif), kualitas tidur, kepatuhan obat, nafsu makan, dan interaksi sosial.
20. **Manajemen Bed Rawat Inap (Visual Bed Matrix)**: Visualisasi warna keterisian bed (Hijau = Siap, Merah = Terisi, Kuning = Sterilisasi), fitur pulangkan pasien (discharge), dan pembaruan status bed.
21. **Catatan Insiden Pasien**: Pelaporan insiden keselamatan psikiatri (agresi fisik/verbal, percobaan kabur, jatuh, penolakan medikasi, self-harm) dengan tingkat risiko dan dokumentasi tindakan de-eskalasi terapeutik.

### Apoteker (Farmasi)
22. **Dashboard Farmasi**: Notifikasi stok obat kritis (< 150 unit) dan antrean resep masuk.
23. **Data Master Obat & Stok**: Katalog obat jiwa (Antipsikotik, Antidepresan, Anksiolitik, Mood Stabilizer, Sedatif), bentuk sediaan, dosis, harga, dan fitur tambah stok (restock).
24. **Telaah Resep & Penyerahan Obat**: Validasi resep dokter, pengurangan otomatis stok obat saat diserahkan, dan cetak etiket aturan pakai obat.

### Kasir
25. **Manajemen Tagihan**: Rincian tagihan transparan (biaya kamar inap, dokter, obat, tindakan/askep), hitung otomatis tagihan pendaftaran, status pelunasan.
26. **Pembayaran & Cetak Struk**: Proses pembayaran (Tunai, Transfer, Debit, BPJS), hitung otomatis kembalian, update status Lunas, dan cetak struk pembayaran resmi RSJ.

### Keluarga Pasien
27. **Dashboard Keluarga**: Informasi ringkas pasien yang diasuh, ruangan/bed, dan status pengajuan kunjungan.
28. **Catatan Pemulihan Pasien**: Laporan perkembangan harian (read-only) dengan bahasa yang ramah, transparan, dan bebas stigma.
29. **Booking Jadwal Kunjungan (Bezuk)**: Pengajuan jadwal kunjungan keluarga (pilih tanggal, sesi pagi/siang/sore, jumlah anggota keluarga).
30. **Tagihan Saya**: Salinan rincian biaya perawatan pasien keluarga dan cetak invoice.

---

## 2. Akun Demo Default (7 Role)

Saat aplikasi pertama kali dijalankan, sistem secara otomatis membuat database `rsj_odgj_db` dan menyematkan akun demo berikut:

| No | Role | Username | Password | Nama Lengkap |
|---|---|---|---|---|
| 1 | **ADMIN** | `admin` | `admin123` | Dr. Ir. Hendra Saputra, M.Kes |
| 2 | **PETUGAS_PENDAFTARAN** | `petugas` | `petugas123` | Siti Nurhaliza, A.Md.RMIK |
| 3 | **DOKTER** | `dokter` | `dokter123` | dr. Budi Santoso, Sp.KJ |
| 4 | **PERAWAT** | `perawat` | `perawat123` | Ns. Ratna Dewi, S.Kep |
| 5 | **APOTEKER** | `apoteker` | `apoteker123` | apt. Fajar Prasetyo, S.Farm |
| 6 | **KASIR** | `kasir` | `kasir123` | Dian Anggraini, S.E |
| 7 | **KELUARGA_PASIEN** | `keluarga` | `keluarga123` | Gunawan Wibisono (Wali Keluarga) |

> **Catatan**: Di layar Login, tersedia tombol pintasan **"Pilih Cepat Akun Demo" (1-Click Login)** untuk kemudahan evaluasi dan pengujian setiap role secara instan.

---

## 3. Persyaratan Sistem & Tech Stack

- **Java Development Kit (JDK)**: Java 17 atau lebih baru (Java 21 didukung penuh).
- **Build Tool**: Apache Maven (sudah menyertakan `pom.xml` standar).
- **GUI Toolkit**: Java Swing + [FlatLaf 3.2.5](https://www.formdev.com/flatlaf/).
- **Database**: MySQL Server (XAMPP / standalone MySQL di port 3306).
- **Konektor**: MySQL Connector/J 8.0.30 (sudah di-bundle ke dalam executable JAR via `maven-shade-plugin`).
- **Enkripsi**: SHA-256 dengan 16-byte cryptographic Salt (`java.security.SecureRandom` & `java.security.MessageDigest`).

---

## 4. Panduan Menjalankan Aplikasi

### Persiapan Database MySQL
1. Buka **XAMPP Control Panel** dan klik tombol **Start** pada modul **MySQL** (pastikan port 3306 aktif).
2. Anda **tidak perlu mengimpor file SQL manual**. Kelas `DatabaseInitializer.java` akan otomatis membuat database `rsj_odgj_db`, seluruh 20 tabel relasional, serta data awal (seed) ketika aplikasi dibuka pertama kali.
3. Jika password root MySQL Anda bukan kosong (default XAMPP kosong), Anda dapat menyesuaikannya di kelas:
   `src/main/java/com/rsj/config/DatabaseConfig.java`

---

### Cara 1: Jalankan Langsung Lewat `run_app.bat` (Termudah di Windows)
Cukup klik ganda (double click) file:
```bat
run_app.bat
```
Script batch ini akan:
1. Memeriksa apakah MySQL aktif di port 3306 (jika belum, akan otomatis menyalakan mysqld XAMPP).
2. Menjalankan file executable JAR `target/rsj-odgj-sim-1.0.0.jar`.

---

### Cara 2: Menjalankan di Apache NetBeans
1. Buka **Apache NetBeans** (NetBeans 17 / 18 / 19 / 20 / 21+).
2. Pilih menu **File** -> **Open Project...**
3. Arahkan ke folder project ini (`c:\PEMROGRAMAN II REMED`), NetBeans akan otomatis mengenalinya sebagai Maven Project (ditandai ikon kubus Maven).
4. Klik kanan pada nama project di panel Projects -> pilih **Run** (atau tekan tombol **F6**).
5. NetBeans akan mengompilasi dan membuka jendela utama aplikasi.

---

### Cara 3: Menjalankan di Visual Studio Code
1. Buka **Visual Studio Code**.
2. Pilih menu **File** -> **Open Folder...** -> pilih folder `c:\PEMROGRAMAN II REMED`.
3. Pastikan ekstensi **Extension Pack for Java** telah terpasang.
4. Buka file `src/main/java/com/rsj/Main.java`, lalu klik tombol **Run** atau **Debug** di pojok kanan atas editor.
5. Atau melalui Terminal VS Code:
   ```bash
   mvn compile exec:java
   ```

---

### Cara 4: Menjalankan via Command Line (Maven / JAR)
- **Mengompilasi dan menjalankan langsung dengan Maven**:
  ```bash
  mvn compile exec:java
  ```
- **Mengemas dan menjalankan file JAR standalone**:
  ```bash
  mvn package -DskipTests
  java -jar target/rsj-odgj-sim-1.0.0.jar
  ```

---

## 5. Struktur Direktori Proyek

```
c:\PEMROGRAMAN II REMED
│   pom.xml                          <- Konfigurasi build Maven
│   run_app.bat                      <- Script peluncur 1-klik di Windows
│   README.md                        <- Dokumentasi lengkap aplikasi
│
└───src
    └───main
        ├───java
        │   └───com
        │       └───rsj
        │           │   Main.java    <- Titik masuk (entry point) aplikasi
        │           │
        │           ├───config       <- DatabaseConfig.java & DatabaseInitializer.java
        │           ├───model        <- 20 Model Entity Data (User, Pasien, Resep, dll)
        │           ├───dao          <- 20 Kelas DAO (JDBC PreparedStatement)
        │           ├───service      <- Logika Bisnis & Validasi Layanan
        │           ├───util         <- PasswordUtil, SessionManager, UiUtils, PrintHelper
        │           └───ui           <- Antarmuka Swing Modern
        │               ├───common   <- WelcomePanel, LoginPanel, TopBar, Sidebar, dll
        │               ├───admin    <- Layanan Administrator (Dashboard, User, Bed, Laporan)
        │               ├───pendaftaran <- Loket Registrasi Pasien & Kunjungan
        │               ├───dokter   <- Rekam Medis, Jadwal, Resep Psikiatri
        │               ├───perawat  <- Observasi, Matrix Bed Inap, Catatan Insiden
        │               ├───apoteker <- Master Obat, Stok, Telaah & Serah Resep
        │               ├───kasir    <- Penerbitan Tagihan & Struk Pembayaran
        │               └───keluarga <- Portal Monitoring Pasien & Booking Kunjungan
        └───resources
```

---

## 6. Keamanan & Kebijakan Etika Data Kesehatan Mental

1. **Role-Based Access Control (RBAC)**: Setiap layar dan operasi menu diproteksi oleh pengecekan hak akses di lapisan UI dan Service. Menu yang bukan haknya tidak akan ditampilkan pada sidebar.
2. **Anti SQL Injection**: 100% interaksi query database menggunakan `PreparedStatement` dengan parameter binding terisolasi.
3. **Password Security**: Password tidak pernah disimpan dalam bentuk teks polos (plain text), melainkan di-hash menggunakan algoritma SHA-256 yang diperkuat salt acak 16-byte kriptografis.
4. **Audit Trail Logging**: Seluruh aktivitas penting (login, logout, registrasi kunjungan, mutasi rekam medis, pembuatan resep, penerbitan tagihan, dan pembayaran) tercatat rapi pada tabel `audit_log`.
5. **Bahasa Humanis & Bebas Stigma**: Mengedepankan istilah medis ramah seperti "Pasien Jiwa", "Bangsal Pemulihan", "Tindakan De-eskalasi", dan "Kemandirian Sosial".
