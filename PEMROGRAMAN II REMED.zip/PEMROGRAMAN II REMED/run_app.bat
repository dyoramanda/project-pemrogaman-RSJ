@echo off
title RSJ SEHAT JIWA - Sistem Informasi Manajemen Rumah Sakit Jiwa & ODGJ
cd /d "%~dp0"

echo ==============================================================================
echo     RSJ SEHAT JIWA - SISTEM INFORMASI MANAJEMEN RUMAH SAKIT JIWA & ODGJ
echo ==============================================================================
echo [1/3] Memeriksa status port MySQL 3306...

powershell -Command "if (-not (Test-NetConnection -ComputerName localhost -Port 3306 -WarningAction SilentlyContinue).TcpTestSucceeded) { if (Test-Path 'C:\xampp\mysql\bin\mysqld.exe') { Write-Host 'Memulai MySQL Server dari XAMPP...'; Start-Process 'C:\xampp\mysql\bin\mysqld.exe' -ArgumentList '--defaults-file=C:\xampp\mysql\bin\my.ini --standalone' -WindowStyle Hidden; Start-Sleep -Seconds 2; Write-Host 'MySQL siap digunakan!' } else { Write-Host 'Pastikan service MySQL / XAMPP sudah berjalan di port 3306.' } }"

echo [2/3] Menjalankan aplikasi Desktop Java Swing...
if exist target\rsj-odgj-sim-1.0.0.jar (
    java -jar target\rsj-odgj-sim-1.0.0.jar
) else (
    echo Mengompilasi project terlebih dahulu...
    mvn compile exec:java
)

pause
